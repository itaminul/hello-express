import React, { useContext, useEffect, useState } from 'react'
import { NavLink } from 'react-router-dom'
import './Sidebar.css'
import MenuContext from '../../contexts/MenuContext'
import { IoIosArrowDown, IoIosArrowUp } from 'react-icons/io'

function Sidebar() {

    const [expanded, setExpanded] = useState(JSON.parse(localStorage.getItem('expanded')) || false);
    const [expandedApplication, setExpandedApplication] = useState(JSON.parse(localStorage.getItem('expandedApplication')) || false);
    const [expandedScuritny, setExpandedScuritny] = useState(JSON.parse(localStorage.getItem('expandedScuritny')) || false);

    function expand() {
        if (expanded != true) {
            localStorage.setItem('expanded', JSON.stringify(true));
            localStorage.setItem('expandedApplication', JSON.stringify(false));
            localStorage.setItem('expandedScuritny', JSON.stringify(false))
            setExpanded(true);
            setExpandedApplication(false)
            setExpandedScuritny(false)
        } else {
            setExpanded(false);
            localStorage.setItem('expanded', JSON.stringify(false));
        }
    }

    function expandApplication() {
        if (expandedApplication != true) {
            localStorage.setItem('expandedApplication', JSON.stringify(true));
            localStorage.setItem('expanded', JSON.stringify(false));
            localStorage.setItem('expandedScuritny', JSON.stringify(false))
            setExpandedApplication(true)
            setExpanded(false)
            setExpandedScuritny(false)
        } else {
            setExpandedApplication(false)
            localStorage.setItem('expandedApplication', JSON.stringify(false));
        }
    }

    function expandScuritny() {
        if(expandedScuritny != true){
            localStorage.setItem('expandedScuritny', JSON.stringify(true))
            localStorage.setItem('expandedApplication', JSON.stringify(false));
            localStorage.setItem('expanded', JSON.stringify(false));  
            setExpandedScuritny(true)
            setExpandedApplication(false)
            setExpanded(false)
        }else{
            setExpandedScuritny(false)
            localStorage.setItem('expandedScuritny', JSON.stringify(false))
        }

    }

    useEffect(() => {
        localStorage.setItem('expanded', JSON.stringify(expanded));
    }, [expanded]);

    useEffect(() => {
        localStorage.setItem('expandedApplication', JSON.stringify(expandedApplication));
    }, [expandedApplication]);

    useEffect(() => {
        localStorage.setItem('expandedScuritny', JSON.stringify(expandedScuritny));
    }, [expandedScuritny])


    const { toggle } = useContext(MenuContext);

    return (
        <div className={'sidebar-container' + (toggle ? " toggle" : "")}>
            <div className='logo-container'>
                <img src={`${process.env.PUBLIC_URL}/assets/images/logo.png`} alt="" />
            </div>
            <ul className='option-container'>
                <NavLink to="/"> <li> Dashboard </li> </NavLink>
                <li onClick={expandScuritny}>
                    Scrutiny <span> {expandScuritny ? <IoIosArrowUp /> : <IoIosArrowUp /> } </span>
                </li>
                <ul className='suboption-container'
                style={expandedScuritny ? {display: "block"} : {display: "none"}}
                >
                    <NavLink to='/feesStructure'>Fees Structure</NavLink>
                </ul>
                <li onClick={expand}>
                    Setup <span> {expanded ? <IoIosArrowUp /> : <IoIosArrowDown />} </span>
                </li>
                <ul className='suboption-container'
                    style={expanded ? { display: "block" } : { display: "none" }}>
                    <NavLink to="/batch"> <li> Batch Settings </li> </NavLink>
                    <NavLink to="/session"> <li> Session Settings </li> </NavLink>
                    <NavLink to="/nationality"> <li>  Nationalities Settings </li> </NavLink>
                    <NavLink to="/district"> <li> District Settings </li> </NavLink>
                    <NavLink to="/bloodgroup"> <li> Blood Group </li> </NavLink>
                </ul>
                <li onClick={expandApplication}>
                    Applications  {expandedApplication ? <IoIosArrowUp /> : <IoIosArrowDown />}
                </li>
                <ul className='suboption-container'
                    style={expandedApplication ? { display: "block" } : { display: "none" }}>
                    <NavLink to="/verifypayment"> <li>Verify Payment</li>  </NavLink>
                    <NavLink to="/totalapplicant"> <li>Total Applicant</li>  </NavLink>
                    <NavLink to="/approvedlist"> <li>Approved List</li>  </NavLink>
                    <NavLink to="/offerLetterList"> <li>Offer Letter</li>  </NavLink>
                </ul>
            </ul>
        </div >
    )
}

export default Sidebar
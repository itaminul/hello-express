import React from 'react'
import LoginPage from './pages/LoginPage'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css'
import { MenuProvider } from './contexts/MenuContext';
import { ModalProvider } from './contexts/ModalContext';
import BatchSettingPage from './pages/BatchSettingPage';
import BatchFilterPage from './pages/BatchFilterPage';
import DistrictSettingPage from './pages/DistrictSettingPage';
import NationalitiesSettingPage from './pages/NationalitiesSettingPage';
import SessionSettingPage from './pages/SessionSettingPage';
import BloodGroupSettingPage from './pages/BloodGroupSettingPage';
import TotalApplicantPage from './pages/TotalApplicantPage';
import VerifyPaymentPage from './components/application/verifyPayment/VerifyPaymentPage';
import ApprovedListPage from './pages/ApprovedListPage';
import RejectedListIndex from './components/application/rejectedList/RejectedListIndex';
import OfferLetterPage from './pages/OfferLetterPage';
import FreeStructureList from './pages/FreeStructureList';
function App() {
  return (
    <div>
      <MenuProvider>
        <ModalProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<LoginPage />}></Route>
              <Route path="/batch" element={<BatchSettingPage />}></Route>
              <Route path="/session" element={<SessionSettingPage />}></Route>
              <Route path="/nationality" element={<NationalitiesSettingPage />}></Route>
              <Route path="/district" element={<DistrictSettingPage />}></Route>
              <Route path="/batchfilter" element={<BatchFilterPage />}></Route>
              <Route path="/bloodgroup" element={<BloodGroupSettingPage />}></Route>
              <Route path="/verifypayment" element={<VerifyPaymentPage />}></Route>
              <Route path="/totalapplicant" element={<TotalApplicantPage />}></Route>
              <Route path="/approvedlist" element={<ApprovedListPage />}></Route>
              <Route path="/rejectedlist" element={<RejectedListIndex />}></Route>
              <Route path="/offerLetterList" element={<OfferLetterPage />}></Route>
              <Route path="/feesStructure" element={<FreeStructureList />}></Route>
            </Routes>
          </BrowserRouter>
        </ModalProvider>
      </MenuProvider>
    </div>
  )
}

export default App
import React from 'react'
import TopNav from '../layout/navbar/TopNav'
import Sidebar from '../layout/sidebar/Sidebar'
import '../components/settings/Table.css'
import NationalitiesIndex from '../components/settings/nationalities/NationalitiesIndex'

function NationalitiesSettingPage() {
    return (
        <div>
            <Sidebar />
            <TopNav />
            <div className='content' >
                <NationalitiesIndex />
            </div>
        </div>
    )
}

export default NationalitiesSettingPage
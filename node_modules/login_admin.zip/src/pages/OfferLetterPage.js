import React from 'react'
import TopNav from '../layout/navbar/TopNav'
import Sidebar from '../layout/sidebar/Sidebar'
import '../components/settings/Table.css'
import OfferLetterIndex from '../components/application/offerLetter/OfferLetterIndex'
function OfferLetterPage() {
    return (
        <div>
            <Sidebar />
            <TopNav />
            <div className='content' >
                <OfferLetterIndex />
            </div>
        </div>
    )
}

export default OfferLetterPage

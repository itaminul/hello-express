import React, { useEffect, useState } from 'react'
import Login from '../components/login/Login';
import DashboardPage from './DashboardPage';

function LoginPage() {

    const [isLoggedIn, setIsLoggedIn] = useState(false)

    useEffect(() => {
        const storeUserLoggedInInformation = localStorage.getItem('isLoggedIn');
        if (storeUserLoggedInInformation === '1') {
            setIsLoggedIn(true)
        }
    }, [])

    const loginHandler = (email, password) => {
        localStorage.setItem('isLoggedIn', '1')
        setIsLoggedIn(true)
    }

    const logoutHandler = () => {
        localStorage.removeItem('isLoggedIn')
        setIsLoggedIn(false)
    }

    return (
        <div className="App">
            {!isLoggedIn && <Login onLogin={loginHandler} />}
            {isLoggedIn && <DashboardPage onLogout={logoutHandler} />}

        </div>
    )
}

export default LoginPage
import React from 'react'
import TopNav from '../layout/navbar/TopNav'
import Sidebar from '../layout/sidebar/Sidebar'
import '../components/settings/Table.css'
import ApprovedListIndex from '../components/application/approvedList/ApprovedListIndex'

function ApprovedListPage() {
    return (
        <div>
            <Sidebar />
            <TopNav />
            <div className='content' >
                <ApprovedListIndex />
            </div>
        </div>
    )
}

export default ApprovedListPage
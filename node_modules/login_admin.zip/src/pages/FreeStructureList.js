import React from 'react'
import Sidebar from '../layout/sidebar/Sidebar'
import TopNav from '../layout/navbar/TopNav'
import FeesStructureIndex from '../components/scrutiny/FeesStructureIndex'
function FreeStructureList() {
  return (
    <div>
        <Sidebar />
        <TopNav />
        <div className='content' >
        <FeesStructureIndex />      
        </div>
    </div>
  )
}

export default FreeStructureList

import React, { useContext, useEffect, useState } from 'react'
import { Button, Form, InputGroup, Stack } from 'react-bootstrap'
import ModalContext from '../../../contexts/ModalContext'
import useAdd from '../../../hooks/useAdd';

function SessionAddForm() {

    const { handleCloseAdd } = useContext(ModalContext)
    const [value, setValue] = useState({});
    const handleInputChange = (e) => {
        e.preventDefault()
        setValue({ ...value, [e.target.name]: e.target.value })
    }

    const [maxId, setMaxId] = useState()
    useEffect(() => {
        fetch("http://192.168.0.84:4004/api/session/maxid")  //API of MaxId
            .then(response => response.json())
            .then(data => setMaxId(data))
            .then(setValue(prev => ({ ...prev, sessionId: maxId })))
        console.log(value);
    }, [maxId, value.sessionId])

    const { addData } = useAdd('http://192.168.0.84:4004/api/session/create', {
        // batchId: maxId,
        sessionId: maxId,
        session: value.session
    })

    const handleSubmit = () => {
        addData();
        handleCloseAdd();
        window.location = "/session";
    }

    return (
        <div>
            <Form>
                <Form.Group className="mb-3">
                    <Form.Label>Session ID</Form.Label>
                    <Form.Control
                        readOnly
                        placeholder="Session ID"
                        aria-label="Session ID"
                        aria-describedby=""
                        name="sessionId"
                        onChange={handleInputChange}
                        defaultValue={maxId}
                    // onChange={handleInputChange}
                    />
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label>Session</Form.Label>
                    <Form.Control
                        placeholder="Session"
                        aria-label="Session"
                        aria-describedby=""
                        name="session"
                        onChange={handleInputChange}
                    // value={val.first_name}
                    // onChange={handleInputChange}
                    />
                </Form.Group>
                <Stack direction="horizontal" gap={3} >
                    <Button variant="secondary" className="ms-auto" onClick={handleCloseAdd}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={handleSubmit} >Submit</Button>
                </Stack>
            </Form>
        </div>
    )
}

export default SessionAddForm
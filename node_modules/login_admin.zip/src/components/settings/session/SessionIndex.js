import React, { useEffect, useState, useMemo, useContext, useRef } from 'react'
import { Badge, Button, Dropdown, Table } from 'react-bootstrap'
import { IoIosArrowDown, IoIosArrowUp } from 'react-icons/io'
import { BiDownload } from 'react-icons/bi'
import { FiEdit } from 'react-icons/fi'
import { BsFillSkipStartFill, BsFillSkipEndFill, BsFillSkipBackwardFill, BsFillSkipForwardFill } from 'react-icons/bs'
import { HiRefresh } from 'react-icons/hi'
import GlobalFilter from '../../settings/GlobalFilter'
import csvDownload from 'json-to-csv-export'
import jsPDF from "jspdf";
import autoTable from 'jspdf-autotable';
import { useTable, useSortBy, useGlobalFilter, usePagination, useResizeColumns, useRowSelect } from 'react-table'
import ColumnFilter from '../../settings/ColumnFilter'
import { MdOutlineKeyboardArrowUp, MdOutlineKeyboardArrowDown } from 'react-icons/md'
import "../../settings/Table.css"
import { Checkbox } from '../../settings/CheckBox'
import EditModal from '../../modals/EditModal'
import ModalContext from '../../../contexts/ModalContext'
import AddModal from '../../modals/AddModal'
import useOutsideClick from '../../../hooks/useOutsideClick'
import SessionAddForm from './SessionAddForm'
import SessionEditForm from './SessionEditForm'
import useFetch from '../../../hooks/useFetch'
import { PuffLoader } from 'react-spinners'

function SessionIndex() {

    const { handleShowEdit, setVal } = useContext(ModalContext)
    const [dropdownShow, setDropdownShow] = useState(false);
    const impactRef = useRef();
    useOutsideClick(impactRef, () => setDropdownShow(false))

    // ##### Function to add row data and show modal ##### 

    function handleEdit(row) {
        setVal(row);
        handleShowEdit();
    }

    // ##### Columns of the table  ##### 

    const COLUMNS = [
        {
            Header: 'Session ID',
            accessor: 'sessionId',
            Filter: ColumnFilter
        },
        {
            Header: 'Session',
            accessor: 'session',
            Filter: ColumnFilter
        },
        {
            Header: 'Active Status',
            accessor: 'activeStatus',
            Filter: ColumnFilter,
            Cell: (e) => {
                return (e.value == 1) ?
                    (
                        <Badge tooltip="Here's the tooltip!" bg="dark">Active</Badge>
                    ) :
                    (<Badge bg="secondary">Inactive</Badge>)
            }
        },
        {
            Header: 'Action',
            accessor: 'action',
            Filter: ColumnFilter,
            Cell: row => (
                <div className='edit-button'>
                    <Button size="sm" onClick={e => handleEdit(row.row.original)}> {<FiEdit />} </Button>
                </div>
            ),
            disableFilters: true
        }
    ]

    // ##### Fetching Data from Database  ##### 

    const [data, setData] = useState([]);
    const { database, loading, refetch } = useFetch("http://192.168.0.84:4004/api/session/getAll");

    useEffect(() => {
        setData(database);
    }, [database])

    // ##### Declaring UseTable props ##### 

    const columns = useMemo(() => COLUMNS, [])
    const tableData = useMemo(() => data, [])
    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        rows,
        page,
        nextPage,
        previousPage,
        canNextPage,
        canPreviousPage,
        pageOptions,
        gotoPage,
        pageCount,
        setPageSize,
        prepareRow,
        selectedFlatRows,
        allColumns,
        getToggleHideAllColumnsProps,
        state,
        setGlobalFilter
    } = useTable({
        columns,
        data
    }, useGlobalFilter, useResizeColumns, useSortBy, usePagination, useRowSelect,
    )

    const { globalFilter, pageIndex, pageSize } = state;

    // ##### PDF Download Function ##### 

    const doc = new jsPDF()
    autoTable(doc, { html: '#data-table' }, {
        styles: {
            minCellHeight: 9,
            halign: "center",
            valign: "center",
            fontSize: 18,
        },
    })

    return (
        <div>
            {/* ##### Hidden Modal For Editing ##### */}

            <div className='modal-button-hide'>
                <EditModal>
                    <SessionEditForm />
                </EditModal>
            </div>

            <div className='title-container'>

                {/* ##### Title ##### */}

                <p> Session Setting </p>

                {/* ##### Column Selection ##### */}

                <div ref={impactRef} className='column-selection'>
                    <div className='select-column-title' onClick={() => setDropdownShow(!dropdownShow)} >
                        Column Visibility {"   "} {dropdownShow ? < MdOutlineKeyboardArrowUp /> : <MdOutlineKeyboardArrowDown />}   </div>
                    <div className='column-list'
                        style={dropdownShow ? { display: "block" } : { display: "none" }} >
                        <div>
                            <Checkbox {...getToggleHideAllColumnsProps()} /> Check All
                        </div>
                        {
                            allColumns.map(column => (
                                <div key={column.id}>
                                    <label>
                                        <input type='checkbox' {...column.getToggleHiddenProps()} />
                                        {" " + column.Header}
                                    </label>
                                </div>
                            ))
                        }
                    </div>
                </div>

                {/* ##### Add New Data ##### */}

                <div className='add-new' >
                    <AddModal>
                        <SessionAddForm />
                    </AddModal>
                </div>
            </div>

            {/* ##### Row Per Page, Download and Search ##### */}


            <div className='search-container'>
                <div className='row-and-download'>
                    <div className='row-per-page'>
                        <label> Row per page </label>
                        <select name='pagesize' value={pageSize}
                            onChange={e => setPageSize(Number(e.target.value))}>
                            <option value={10} > 10 </option>
                            <option value={20} > 20 </option>
                            <option value={30} > 30 </option>
                        </select>
                    </div>

                    {/* ##### Download Options ##### */}

                    <Dropdown>
                        <Dropdown.Toggle id="dropdown-basic" className='download'>
                            < BiDownload />
                        </Dropdown.Toggle>
                        <Dropdown.Menu>
                            <Dropdown.Item onClick={() => csvDownload(data, "Data Table.csv")}>
                                Excel
                            </Dropdown.Item>
                            <Dropdown.Item onClick={() => doc.save('Data Table.pdf')}>
                                PDF
                            </Dropdown.Item>
                            <Dropdown.Item onClick={() => window.print()}>
                                Print
                            </Dropdown.Item>
                        </Dropdown.Menu>
                    </Dropdown>
                </div>

                <div>
                    <GlobalFilter filter={globalFilter} setFilter={setGlobalFilter} />
                    <button className='reload-button' onClick={refetch}>
                        <HiRefresh />
                    </button>
                </div>
            </div>

            {/* ##### Table Starts ##### */}

            <Table {...getTableProps()} className="data-table" id='data-table' striped bordered hover responsive>
                <thead>
                    {
                        headerGroups.map(headerGroup => (
                            <tr {...headerGroup.getHeaderGroupProps()} className="table-head" >
                                {
                                    headerGroup.headers.map((column) => (

                                        <th{...column.getHeaderProps(column.getSortByToggleProps())}>
                                            {column.render('Header')}
                                            <span className='arrow'>
                                                {column.isSorted ? (column.isSortedDesc ? <IoIosArrowDown /> : <IoIosArrowUp />) : ""}
                                            </span>
                                        </th>
                                    ))}
                            </tr>
                        ))}
                </thead>
                <tbody {...getTableBodyProps()} >
                    {
                        page.map(row => {
                            prepareRow(row)
                            return (
                                <tr {...row.getRowProps()}>
                                    {
                                        row.cells.map((cell) => {
                                            return <td {...cell.getCellProps()}> {cell.render('Cell')} </td>

                                        })}
                                </tr>
                            )
                        })}
                </tbody>
            </Table>

            {/* ##### Table Ends ##### */}

            {/* ##### Spinner ##### */}

            <div className='spinner-container'>
                <PuffLoader loading={loading} size={100} />
            </div>

            {/* ##### Pagination Starts ##### */}

            <div className='pagination-container'>
                <div> Showing {page.length} out of {rows.length} entries </div>
                <div className='page-number'>
                    <span> Page {pageIndex + 1} of {pageOptions.length} </span>
                    <span>  Go to Page: {"   "}
                        <input type="number"
                            defaultValue={pageIndex + 1}
                            onChange={e => {
                                const pageNumber = e.target.value ? Number(e.target.value) - 1 : 0
                                gotoPage(pageNumber)
                            }} />
                    </span>
                </div>
                <div className='page-buttons'>
                    <button onClick={() => gotoPage(0)} disabled={!canPreviousPage} > {<BsFillSkipBackwardFill />} </button>
                    <button onClick={() => previousPage()} disabled={!canPreviousPage} > {<BsFillSkipStartFill />} </button>
                    <button onClick={() => nextPage()} disabled={!canNextPage} > {<BsFillSkipEndFill />} </button>
                    <button onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage} > {<BsFillSkipForwardFill />} </button>
                </div>
            </div>

            {/* ##### Pagination Ends ##### */}

        </div>
    )
}
export default SessionIndex
import React from 'react'

function ColumnFilter({ column }) {
    const { filterValue, setFilter } = column;
    return (
        <div>
            <input className='column-filter form-control'
                value={filterValue || ""}
                onChange={e => setFilter(e.target.value)} />
        </div>

    )
}

export default ColumnFilter
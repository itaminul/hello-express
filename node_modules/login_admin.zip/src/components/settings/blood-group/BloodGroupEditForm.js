import React, { useState, useContext } from 'react'
import { Button, Form, InputGroup, Stack, Container, Row, Col, FormSelect } from 'react-bootstrap'
// import Select from 'react-select';
import ModalContext from '../../../contexts/ModalContext'
import useEdit from '../../../hooks/useEdit'

function BloodGroupEditForm() {
  const data = [
    {
      value: 1,
      label: "Active"
    },
    {
      value: 2,
      label: "Inactive"
    }
  ];
  const [bloodgroupId, setBloodGroupID] = useState()
  const [bloodgroup, setBloodGroup] = useState()
  // set value for default selection
  const { val, handleCloseEdit } = useContext(ModalContext)
  const [activeStatus, setSelectedValue] = useState();
  const { editData } = useEdit(`http://192.168.0.84:4004/api/bloodgroup/update/${val._id}`, {
    bloodgroup: bloodgroup,
    activeStatus: activeStatus
  })

  const onUpdate = (e) => {
    e.preventDefault();
    editData();
    handleCloseEdit()
    window.location = "/bloodgroup";
  }

  // handle onChange event of the dropdown
  const handleChange = e => {
    console.log(e.target.value)
    setSelectedValue(e.target.value);
  }

  return (
    <div>
      <Container>
        <Form>
          <Row>
            <Col xs={12} md={12}>
              <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Blood Group ID</Form.Label>
                <Form.Control
                  placeholder="Blood Group ID"
                  aria-label="Blood Group ID"
                  readOnly
                  aria-describedby=""
                  name="bloodgroupId"
                  defaultValue={val.bloodgroupId}
                  onChange={(e) => setBloodGroupID(e.target.value)}
                />
              </Form.Group>
              <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Blood Group</Form.Label>
                <Form.Control
                  required
                  placeholder="Blood Group"
                  aria-label="Blood Group"
                  aria-describedby=""
                  name="bloodgroup"
                  defaultValue={val.bloodgroup}
                  onChange={(e) => setBloodGroup(e.target.value)}
                />
              </Form.Group>
              <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Active Status</Form.Label>
                <Form.Select className="mb-3" aria-label="Gender"
                  defaultValue={val.activeStatus}
                  onChange={handleChange}
                >
                  {data.map((bgv) => (
                    <option value={bgv.value}>{bgv.label}</option>

                  ))}
                </Form.Select>
              </Form.Group>
              <Stack direction="horizontal" gap={3} >
                <Button variant="secondary" className="ms-auto" onClick={handleCloseEdit}>
                  Close
                </Button>
                <Button variant="primary" onClick
                  ={onUpdate}>Submit</Button>
              </Stack>

            </Col>
          </Row>
        </Form>
      </Container>
    </div>
  )
}

export default BloodGroupEditForm
import React, { useContext, useEffect, useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom'
import { Form, InputGroup, Stack } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import axios from 'axios';
import ModalContext from '../../../contexts/ModalContext';
import useAdd from '../../../hooks/useAdd';
import useFetch from '../../../hooks/useFetch';
// import useAdd from '../../../hooks/UseAdd';



function BloodGroupAddForm() {

    const { handleCloseAdd } = useContext(ModalContext)
    const navigate = useNavigate();


    const initialValues = {
        bloodGroupID: "",
        bloodgroup: ""
    };

    const [values, setValues] = useState(initialValues)
    const [bloodgroupId, setBloodGroupID] = useState('')
    const [bloodgroup, setBloodGroup] = useState('')

    const { refetch } = useFetch("http://localhost:4004/api/bloodgroup/getAll");

    const { addData } = useAdd('http://localhost:4004/api/bloodgroup/create', {
        bloodgroupId: bloodgroupId,
        bloodgroup: bloodgroup
    })

    // const onSubmitForm = async (e) => {
    //     // e.preventDefault()
    //     // await axios.post('http://localhost:4004/api/bloodgroup/create', {
    //     //     bloodgroupId: bloodgroupId,
    //     //     bloodgroup: bloodgroup
    //     // })
    //     //     .then(response => {
    //     //         console.log(response)
    //     //     })
    //     //     .catch(error => {
    //     //         console.log(error.response)
    //     //     });
    //     // navigate.push("/");
    //     // setShow(false);
    //     addData();
    //     handleCloseAdd();
    // }


    const onSubmitForm = () => {
        addData()
        handleCloseAdd();
        window.location = "/bloodgroup";
    }

    // .then(refetch)

    return (
        <div>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Blood Group ID</Form.Label>
                <Form.Control
                    type="text"
                    placeholder=""
                    name="bloodgroupId"
                    value={bloodgroupId}
                    onChange={(e) => setBloodGroupID(e.target.value)}
                />
            </Form.Group>
            <Form.Group
                className="mb-3"
                controlId="exampleForm.ControlTextarea1"
            >
                <Form.Label>Blood Group</Form.Label>
                <Form.Control
                    type="text"
                    name="bloodgroup"
                    value={bloodgroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                />
            </Form.Group>

            <Stack direction="horizontal" gap={3} >
                <Button variant="secondary" className="ms-auto" onClick={handleCloseAdd}>
                    Close
                </Button>
                <Button variant="primary" onClick={onSubmitForm}>Submit</Button>
            </Stack>
        </div>
    )
}

export default BloodGroupAddForm
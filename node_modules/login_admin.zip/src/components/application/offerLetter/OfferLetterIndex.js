import React, { useEffect, useState, useMemo, useContext, useRef } from 'react'
import { Form, Badge, Button, Dropdown, Table, Card, ListGroup, Row, Col, Container } from 'react-bootstrap'
import EditModal from '../../modals/EditModal'
import ModalContext from '../../../contexts/ModalContext';
import useOutsideClick from '../../../hooks/useOutsideClick';


function OfferLetterIndex() {
    const { handleShowEdit, setVal } = useContext(ModalContext)
    const [dropdownShow, setDropdownShow] = useState(false);
    const impactRef = useRef();
    useOutsideClick(impactRef, () => setDropdownShow(false))

    const [sessions, setSession] = useState([])
    const [batches, setBatches] = useState([])

     // ##### Function to add row data and show modal ##### 

     function handleEdit(row) {
        setVal(row);
        handleShowEdit();
    }



    const getSession = (req, res) => {
        fetch('http://192.168.0.84:4004/api/session/getAll')
        .then((res) => res.json())
        .then((res) => {
            setSession(res)
        })
    }

    useEffect(() => {
        getSession()
    }, [])

    const getBatch = (req, res) => {
        fetch('http://192.168.0.84:4004/api/batch/getAll')
        .then((response) => response.json())
        .then((response) => {
            console.log(response)
            setBatches(response)
        })

    }
    //batchesNo

    useEffect(() => {
        getBatch()
    }, [])


    const agents = [
        {
            value: 1,
            label: 'Price Educare'
        },
        {
            value: 2,
            label: 'Smile Educare'
        }
    ]

    const courseTypes = [
        {
            value: 1,
            label: 'MBBS'
        },
        {
            value: 2,
            label: 'MDS'
        }
    ]

    return (
        <div>
            {/* ##### Hidden Modal For Editing ##### */}

            <div className='modal-button-hide'>
                <EditModal size="md">
                    {/* <TotalApplicantEditFrom /> */}
                </EditModal>
            </div>
            <div className='title-container'>

                {/* ##### Title ##### */}

                <p> Offer Letter </p>              

                <div className='add-new' >
                   
                </div>
            </div>

            <div className='search-container'>

            <Container>
                <Row>
                    <Col>
                    <Card style={{ width: '15rem' }}>
                        <Card.Header>History</Card.Header>
                        <ListGroup variant="flush">
                            <ListGroup.Item>
                            <Form.Select size="sm" aria-label="Default select example">
                            <option>--Select Agent--</option>
                            {agents.map((agent) => 
                                <option value="1">{agent.label}</option>
                            )}
                            </Form.Select>
                            </ListGroup.Item>
                            <ListGroup.Item>

                            <Form.Select aria-label="Default select example">
                            <option>--Select Type--</option>
                            {courseTypes.map((courseType) => 
                            <option value={courseType.value}>{courseType.label}</option>
                             )}
                            </Form.Select>
                            </ListGroup.Item>

                            <ListGroup.Item>
                            <Form.Select aria-label="Default select example">
                            <option>--Select Sessoin--</option>
                            {sessions.map((session) => 
                                <option value={session.sessionId}>{session.session}</option>                            
                            )}
                            </Form.Select>
                            </ListGroup.Item>

                            <ListGroup.Item>
                            <Form.Select aria-label="Default select example" search>
                            <option>--Select Batch--</option>
                            {batches.map((batche) => 
                            <option value={batche.batchesId}>{batche.batchesNo}</option>                            
                            )}
                            </Form.Select>
                            </ListGroup.Item>

                        </ListGroup>
                        </Card>
                        </Col>

                    <Col>
                    
                    <Card style={{ width: '44rem' }}>
                        <Card.Header>Free Structure </Card.Header>
                        <Card.Body>
                            <div className='container'>
                                <div className='row'>
                                    <div className='col-6'>                                  
                                        <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>During Admission US$*</Form.Label>
                                            <Form.Control type="email" placeholder="" />
                                           </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>2nd Installment US$*</Form.Label>
                                            <Form.Control type="text" placeholder="" />
                                        </Form.Group>

                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>3nd Installment US$*</Form.Label>
                                            <Form.Control type="text" placeholder="" />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>Final Installment US$*</Form.Label>
                                            <Form.Control type="text" placeholder="" />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>Extra Tuition Fees US$*</Form.Label>
                                            <Form.Control type="text" placeholder="" />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>Grand Total US$*</Form.Label>
                                            <Form.Control type="text" placeholder="" />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>Grand Total in words*</Form.Label>
                                            <Form.Control type="text" placeholder="" />
                                        </Form.Group>                                   
                                    </div>
                                    <div className='col-6'>
                                    <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Last Day of Admission Payment*</Form.Label>
                                            <Form.Control type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>2nd Installment Date*</Form.Label>
                                            <Form.Control type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>3nd Installment Date*</Form.Label>
                                            <Form.Control type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Final Installment Date*</Form.Label>
                                            <Form.Control type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Hostel Fees US$*</Form.Label>
                                            <Form.Control type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Food Cost *</Form.Label>
                                            <Form.Control type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Internship Fees Payment US$*</Form.Label>
                                            <Form.Control type="email" placeholder=" " />
                                           </Form.Group>                                           
                                    </div>
                                    <div className='col-12'>  

                                    <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Student's Name</Form.Label>
                                            <Form.Control type="email" placeholder=" " />
                                           </Form.Group>   
                                 
                                    <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Father's Name</Form.Label>
                                            <Form.Control type="email" placeholder=" " />
                                           </Form.Group>   
                                    
                                    <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Mother's Name</Form.Label>
                                            <Form.Control type="email" placeholder=" " />
                                           </Form.Group>  

                                    <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Address</Form.Label>
                                            <Form.Control as="textarea"  placeholder=" " />
                                           </Form.Group> 
                                           
                                    <ListGroup.Item>
                                            <Form.Select aria-label="Default select example">
                                            <option>--select--</option>
                                            <option value="1">One</option>
                                            <option value="2">Two</option>
                                            <option value="3">Three</option>
                                            </Form.Select>
                                            </ListGroup.Item>
                                            <br />

                                           </div>
                                       
                                    <Button variant="primary" type="submit">
                                            Submit
                                        </Button>    

                                </div>
                            </div>                            
                        </Card.Body>
                        </Card>                        
                        </Col>
                </Row>
                </Container>
            </div> 
        </div>
    )
}

export default OfferLetterIndex

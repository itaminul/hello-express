import React from 'react'
import Sidebar from '../../../layout/sidebar/Sidebar'
import TopNav from '../../../layout/navbar/TopNav'
import VerifyPaymentIndex from './VerifyPaymentIndex'
function VerifyPaymentPage() {
  return (
    <div>
        <div>
            <Sidebar />
            <TopNav />
            <div className='content' >
                <VerifyPaymentIndex />
            </div>
        </div>
      
    </div>
  )
}

export default VerifyPaymentPage

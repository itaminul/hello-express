import React, { useEffect, useState, useMemo, useContext, useRef } from 'react'
import { Badge, Button, Dropdown, Table } from 'react-bootstrap'
import { IoIosArrowDown, IoIosArrowUp } from 'react-icons/io'
import { BiDownload } from 'react-icons/bi'
import { FiEdit } from 'react-icons/fi'
import { BsFillSkipStartFill, BsFillSkipEndFill, BsFillSkipBackwardFill, BsFillSkipForwardFill } from 'react-icons/bs'
import GlobalFilter from '../../settings/GlobalFilter'
import csvDownload from 'json-to-csv-export'
import jsPDF from "jspdf";
import autoTable from 'jspdf-autotable';
import { useTable, useSortBy, useGlobalFilter, usePagination, useResizeColumns, useRowSelect } from 'react-table'
import ColumnFilter from '../../settings/ColumnFilter'
import { MdOutlineKeyboardArrowUp, MdOutlineKeyboardArrowDown } from 'react-icons/md'
import ModalContext from '../../../contexts/ModalContext'
import useOutsideClick from '../../../hooks/useOutsideClick'
import { Checkbox } from '../../settings/CheckBox'
import "../../settings/Table.css"
import EditModal from '../../modals/EditModal'
import AddModal from '../../modals/AddModal'
import VerifyPaymentEditForm from './VerifyPaymentEditForm'
import useFetch from '../../../hooks/useFetch'
function VerifyPaymentIndex() {
  const { handleShowEdit, setVal } = useContext(ModalContext)
  const [dropdownShow, setDropdownShow] = useState(false);
  const impactRef = useRef();
  useOutsideClick(impactRef, () => setDropdownShow(false))

  // ##### Function to add row data and show modal ##### 

  function handleEdit(row) {
      setVal(row);
      handleShowEdit();
  }

  // ##### Columns of the table  ##### 

  const COLUMNS = [
    {
        Header: 'ID',
        accessor: 'applicationId',
        Filter: ColumnFilter
    },
    {
        Header: `Applicants's Name`,
        accessor: 'fullName',
        Filter: ColumnFilter
    },
    {
        Header: 'College Code',
        accessor: 'collegeCode',
        Filter: ColumnFilter
    },
    {
        Header: 'Serial No',
        accessor: 'serialNumber',
        Filter: ColumnFilter
    },
    {
        Header: 'Roll No',
        accessor: 'rollNumber',
        Filter: ColumnFilter
    },
    {
        Header: 'Merit Score',
        accessor: 'meritSchore',
        Filter: ColumnFilter
    },
    {
        Header: 'National Merit Position',
        accessor: 'merintPosition',
        Filter: ColumnFilter
    },
    {
        Header: 'Mobile Number',
        accessor: 'mobileNumber',
        Filter: ColumnFilter
    },
    {
        Header: 'Transaction ID / Money Receipt No.',
        accessor: 'transaction_id',
        Filter: ColumnFilter
    },
    {
        Header: 'Payment Mobile No. / Amount',
        accessor: 'moneySenderMob',
        Filter: ColumnFilter
    },
    {
        Header: 'Payment Status',
        accessor: 'appliPaymentStatus',
        Cell: (e) => {

            if(e.value === 1){
                return(
                    <Badge bg="warning">Pending</Badge>
                   )
            }
            if(e.value === 2){
                return(
                    <Badge bg="success">Success</Badge>
                   )
            }
            if(e.value === 3){
               return(
                <Badge bg="danger">Cancel</Badge>
               )
            }
        }
    },
    
    {
        Header: 'Remarks',
        accessor: 'remarksAfterPayment',
        Filter: ColumnFilter
    },
    {
        Header: 'Action',
        accessor: '',
        Filter: ColumnFilter,
        Cell: row => (
            <div className='edit-button'>
                <Button size="sm" onClick={e => handleEdit(row.row.original)}> {<FiEdit />} </Button>
                </div>
        )
    }


    ]
    

    // ##### Fetching Data from Database  ##### 

    const [data, setData] = useState([]);
    const { database, loading, refetch } = useFetch("http://192.168.0.84:4004/api/verifypayment/getAll");
    useEffect(() => {
        setData(database);
    }, [database])

    // ##### Declaring UseTable props ##### 

    const columns = useMemo(() => COLUMNS, [])
    const tableData = useMemo(() => data, [])
    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        rows,
        page,
        nextPage,
        previousPage,
        canNextPage,
        canPreviousPage,
        pageOptions,
        gotoPage,
        pageCount,
        setPageSize,
        prepareRow,
        selectedFlatRows,
        allColumns,
        getToggleHideAllColumnsProps,
        state,
        setGlobalFilter
    } = useTable({
        columns,
        data
    }, useGlobalFilter, useResizeColumns, useSortBy, usePagination, useRowSelect,
    )

    const { globalFilter, pageIndex, pageSize } = state;

    // ##### PDF Download Function ##### 

    const doc = new jsPDF()
    autoTable(doc, { html: '#data-table' }, {
        styles: {
            minCellHeight: 9,
            halign: "center",
            valign: "center",
            fontSize: 18,
        },
    })

    return (
        <div>
            {/* ##### Hidden Modal For Editing ##### */}

            <div className='modal-button-hide'>
                <EditModal size="lg">
                    <VerifyPaymentEditForm />
                </EditModal>

            </div>

            <div className='title-container'>

                {/* ##### Title ##### */}

                <p> Payment Verify </p>

                {/* ##### Column Selection ##### */}

                <div ref={impactRef} className='column-selection'>
                    <div className='select-column-title' onClick={() => setDropdownShow(!dropdownShow)} >
                        Column Visibility {"   "} {dropdownShow ? < MdOutlineKeyboardArrowUp /> : <MdOutlineKeyboardArrowDown />}   </div>
                    <div className='column-list'
                        style={dropdownShow ? { display: "block" } : { display: "none" }} >
                        <div>
                            <Checkbox {...getToggleHideAllColumnsProps()} /> Check All
                        </div>
                        {
                            allColumns.map(column => (
                                <div key={column.id}>
                                    <label>
                                        <input type='checkbox' {...column.getToggleHiddenProps()} />
                                        {" " + column.Header}
                                    </label>
                                </div>
                            ))
                        }
                    </div>
                </div>

                {/* ##### Add New Data ##### */}

                <div className='add-new' >
                    {/* <AddModal>
                     
                  </AddModal> */}
                </div>
            </div>

            {/* ##### Row Per Page, Download and Search ##### */}


            <div className='search-container'>
                <div className='row-and-download'>
                    <div className='row-per-page'>
                        <label> Row per page </label>
                        <select name='pagesize' value={pageSize}
                            onChange={e => setPageSize(Number(e.target.value))}>
                            <option value={10} > 10 </option>
                            <option value={20} > 20 </option>
                            <option value={30} > 30 </option>
                        </select>
                    </div>

                    {/* ##### Download Options ##### */}

                    <Dropdown>
                        <Dropdown.Toggle id="dropdown-basic" className='download'>
                            < BiDownload />
                        </Dropdown.Toggle>
                        <Dropdown.Menu>
                            <Dropdown.Item onClick={() => csvDownload(data, "Data Table.csv")}>
                                Excel
                            </Dropdown.Item>
                            <Dropdown.Item onClick={() => doc.save('Data Table.pdf')}>
                                PDF
                            </Dropdown.Item>
                            <Dropdown.Item onClick={() => window.print()}>
                                Print
                            </Dropdown.Item>
                        </Dropdown.Menu>
                    </Dropdown>
                </div>

                <GlobalFilter filter={globalFilter} setFilter={setGlobalFilter} />
            </div>

            {/* ##### Table Starts ##### */}

            <Table {...getTableProps()} className="data-table" id='data-table' striped bordered hover responsive="sm">
                <thead>
                    {
                        headerGroups.map(headerGroup => (
                            <tr {...headerGroup.getHeaderGroupProps()} className="table-head" >
                                {
                                    headerGroup.headers.map((column) => (

                                        <th{...column.getHeaderProps(column.getSortByToggleProps())}>
                                            {column.render('Header')}
                                            <span className='arrow'>
                                                {column.isSorted ? (column.isSortedDesc ? <IoIosArrowDown /> : <IoIosArrowUp />) : ""}
                                            </span>
                                        </th>
                                    ))}
                            </tr>
                        ))}
                </thead>
                <tbody {...getTableBodyProps()} >
                    {
                        page.map(row => {
                            prepareRow(row)
                            return (
                                <tr {...row.getRowProps()}>
                                    {
                                        row.cells.map((cell) => {
                                            return <td {...cell.getCellProps()}> {cell.render('Cell')} </td>

                                        })}
                                </tr>
                            )
                        })}
                </tbody>
            </Table>

            {/* ##### Table Ends ##### */}

            {/* ##### Pagination Starts ##### */}

            <div className='pagination-container'>
                <div> Showing {page.length} out of {rows.length} entries </div>
                <div className='page-number'>
                    <span> Page {pageIndex + 1} of {pageOptions.length} </span>
                    <span>  Go to Page: {"   "}
                        <input type="number"
                            defaultValue={pageIndex + 1}
                            onChange={e => {
                                const pageNumber = e.target.value ? Number(e.target.value) - 1 : 0
                                gotoPage(pageNumber)
                            }} />
                    </span>
                </div>
                <div className='page-buttons'>
                    <button onClick={() => gotoPage(0)} disabled={!canPreviousPage} > {<BsFillSkipBackwardFill />} </button>
                    <button onClick={() => previousPage()} disabled={!canPreviousPage} > {<BsFillSkipStartFill />} </button>
                    <button onClick={() => nextPage()} disabled={!canNextPage} > {<BsFillSkipEndFill />} </button>
                    <button onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage} > {<BsFillSkipForwardFill />} </button>
                </div>
            </div>

            {/* ##### Pagination Ends ##### */}

        </div>
    )
}

export default VerifyPaymentIndex

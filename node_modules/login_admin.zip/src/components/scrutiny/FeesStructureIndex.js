import React, { useEffect, useState, useMemo, useContext, useRef } from 'react'
import { Form, Badge, Button, Dropdown, Table, Card, ListGroup, Row, Col, Container } from 'react-bootstrap'
import useAdd from '../../hooks/useAdd'
import FreeStructureList from '../../pages/FreeStructureList'
import EditModal from '../modals/EditModal'
import ModalContext from '../../contexts/ModalContext'
function FeesStructure() {
    // const { val, handleCloseEdit } = useContext(ModalContext)

    const [values, setValue] = useState('')


    useEffect(() => {
        fetch('http://192.168.0.84:4004/api/freeStructure/getAll')
        .then((response) => response.json())
        .then((actualData) => console.log(actualData));
    }, [])

    const handlerChange = (e) => {
        setValue({ ...values, [e.target.name]: e.target.value})
    }

    const {addData} = useAdd('http://192.168.0.84:4004/api/freeStructure/create', {
        duringAdmissionUS:values.duringAdmissionUS,
        secondInstallmentUS:values.secondInstallmentUS
    })

    const handleSubmit = (event) => {
        event.preventDefault()
        addData()       

    }
    const [ val, setValuea ] = useState([])

    useEffect(() => {
        fetch("http://192.168.0.84:4004/api/freeStructure/getById/1")  //API of MaxId
            .then(responsea => responsea.json())
            .then(data => setValuea(data))
         console.log(val);
    }, [])


  return (
    <div>
            {/* ##### Hidden Modal For Editing ##### */}

            <div className='modal-button-hide'>
                <EditModal size="md">
                    {/* <TotalApplicantEditFrom /> */}
                </EditModal>
            </div>
            <div className='title-container'>

                {/* ##### Title ##### */}

                <p> Offer Letter </p>              

                <div className='add-new' >
                   
                </div>
            </div>

            <div className='search-container'>

            <Container>
                <Row> 
                    <Col>                    
                    <Card>
                        <Card.Header>Free Structure </Card.Header>
                        <Card.Body>
                            <div className='container'>
                                <div className='row'>
                                    <div className='col-6'>                                  
                                        <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>During Admission US$*</Form.Label>
                                            <Form.Control 
                                            name="duringAdmissionUS"
                                            // value={val.duringAdmissionUS}
                                            onChange={handlerChange}
                                            type="text" 
                                            placeholder="" 
                                            />
                                           </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>2nd Installment US$*</Form.Label>
                                            <Form.Control 
                                            name="secondInstallmentUS"
                                            // value={val.secondInstallmentUS}
                                            onChange={handlerChange}                                            
                                            type="text"
                                             placeholder="" />
                                        </Form.Group>

                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>3nd Installment US$*</Form.Label>
                                            <Form.Control
                                             name="thirdInstallmentUS"
                                            //  value={val.thirdInstallmentUS}
                                             onChange={handlerChange}
                                              type="text" placeholder="" />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>Final Installment US$*</Form.Label>
                                            <Form.Control
                                             name="finalInstallmentUS"
                                            //  value={val.finalInstallmentUS}
                                             onChange={handlerChange}
                                              type="text" placeholder="" />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>Extra Tuition Fees US$*</Form.Label>
                                            <Form.Control
                                             name="extraTuitionFeesUS"
                                            //  value={val.extraTuitionFeesUS}
                                             onChange={handlerChange}
                                              type="text" placeholder="" />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>Grand Total US$*</Form.Label>
                                            <Form.Control
                                             name="grandTotalUS"
                                            //  value={val.grandTotalUS}
                                             onChange={handlerChange}
                                              type="text" placeholder="" />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>Grand Total in words*</Form.Label>
                                            <Form.Control 
                                             name="grandTotalinWords"
                                            //  value={val.grandTotalinWords}
                                             onChange={handlerChange}
                                             type="text" placeholder="" />
                                        </Form.Group>   
                                        <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>Bank Account*</Form.Label>
                                            <Form.Control
                                             name="bankAccountNo"
                                            //  value={val.bankAccountNo}
                                             onChange={handlerChange}
                                              type="text" placeholder="" />
                                        </Form.Group>                                   
                                    </div>
                                    <div className='col-6'>
                                    <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Last Day of Admission Payment*</Form.Label>
                                            <Form.Control 
                                             name="lastDayofAdmissionPayment"
                                            //  value={val.lastDayofAdmissionPayment}
                                             onChange={handlerChange}
                                             type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>2nd Installment Date*</Form.Label>
                                            <Form.Control 
                                             name="secondInstallmentDate"
                                            //  value={val.secondInstallmentDate}
                                             onChange={handlerChange}
                                             type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>3nd Installment Date*</Form.Label>
                                            <Form.Control 
                                             name="thirdInstallmentDate"
                                            //  value={val.thirdInstallmentDate}
                                             onChange={handlerChange}
                                             type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Final Installment Date*</Form.Label>
                                            <Form.Control 
                                             name="finalInstallmentDate"
                                            //  value={val.finalInstallmentDate}
                                             onChange={handlerChange}
                                             type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Hostel Fees US$*</Form.Label>
                                            <Form.Control 
                                             name="hostelFeesUS"
                                            //  value={val.hostelFeesUS}
                                             onChange={handlerChange}
                                             type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Food Cost *</Form.Label>
                                            <Form.Control 
                                             name="foodCost"
                                            //  value={val.foodCost}
                                             onChange={handlerChange}
                                             type="email" placeholder=" " />
                                           </Form.Group>

                                           <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Internship Fees Payment US$*</Form.Label>
                                            <Form.Control 
                                             name="internshipFeesPaymentUS"
                                            //  value={val.internshipFeesPaymentUS}
                                             onChange={handlerChange}
                                             type="email" placeholder=" " />
                                           </Form.Group>    

                                           <Form.Group className="mb-3" controlId="formBasicPassword">
                                            <Form.Label>Bank Address*</Form.Label>
                                            <Form.Control 
                                            name="bankAddress"
                                            // value={val.bankAddress}
                                            onChange={handlerChange}
                                            
                                            type="text" placeholder="" />
                                        </Form.Group>                                          
                                    </div>
                                    <div className='col-12'>  
                                           </div>                                       
                                    <Button onClick={handleSubmit} variant="primary" type="submit">
                                            Submit
                                        </Button>   
                                </div>
                            </div>                            
                        </Card.Body>
                        </Card>                        
                        </Col>
                </Row>
                </Container>
            </div> 
        </div>
    )
  
}

export default FeesStructure

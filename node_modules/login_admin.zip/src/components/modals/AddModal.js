import React, { useContext, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { BiPlusMedical } from 'react-icons/bi'
import ModalContext from '../../contexts/ModalContext';
import "./modal.css"

function AddModal({ size, children }) {


    const { showAdd, handleShowAdd, handleCloseAdd } = useContext(ModalContext)

    return (
        <>
            <Button variant="primary" onClick={handleShowAdd} className="add-modal-button" >
                <BiPlusMedical />
            </Button>

            <Modal
                size={size}
                show={showAdd}
                onHide={handleCloseAdd}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Header closeButton>
                    <Modal.Title>Add</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {children}
                </Modal.Body>

            </Modal>
        </>
    );
}

export default AddModal;

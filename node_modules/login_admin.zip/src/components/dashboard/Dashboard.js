import React from 'react'
import { CircularProgressbar } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import './Dashboard.css'

function Dashboard() {
    return (
        <div>
            Dashboard
            {/* <div className='dashboard-container'>
                <div className='applicant-container'>
                    <h5> Total Applicant </h5>
                    <div className='progressbar-container'>
                        <CircularProgressbar
                            value={100}
                            text="900"
                        />
                    </div>
                </div>
                <div className='applicant-container'>
                    <h5> Total Pending List </h5>
                    <div className='progressbar-container'>
                        <CircularProgressbar
                            value={23}
                            text="250"
                        />
                    </div>
                </div>
                <div className='applicant-container'>
                    <h5> Approved Applicant </h5>
                    <div className='progressbar-container'>
                        <CircularProgressbar
                            value={45}
                            text="500"
                        />
                    </div>
                </div>
                <div className='applicant-container'>
                    <h5> Rejected Applicant </h5>
                    <div className='progressbar-container'>
                        <CircularProgressbar
                            value={20}
                            text="150"
                        />
                    </div>
                </div>


            </div> */}
        </div>
    )
}

export default Dashboard
import React, { useState } from 'react'
import './Login.css'
function Login(props) {


    const initialState = {
        email: '',
        password: '',
        isMember: true
    }

    const [values, setValues] = useState(initialState)

    const handlerChange = (e) => {
        e.preventDefault();
        setValues({ ...values, [e.target.name]: e.target.value})

    }
    const submitHandler = (e) => {
        e.preventDefault();
        const { email, password, isMember } = values;
        if(!email || !password || (!isMember)) {
            // console.log('rrrr')
            return
        }
        
       props.onLogin(values)
    }

  return (
    <div className='login'>
        <form onSubmit={submitHandler}>
            <label>User Name</label>
            <input type="text"
             name="email"
             id="Uname"
             value={values.email}
             onChange={handlerChange}
             />            
             <label>User Name</label>
            <input type="password"
             name="password"
             id="Pass"
             value={values.password}
             onChange={handlerChange}
             />
             <br/>
             <br/>
             <button type='submit'>Submit</button>
        </form>
      
    </div>
  )
}

export default Login

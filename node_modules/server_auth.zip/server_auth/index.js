const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
require("dotenv").config();
const cors = require("cors");
// import jsonwebtoken

const PORT = process.env.PORT || 4003;

const app = express();
app.use(cors());

mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("DB successfully connected new!");
  })
  .catch((err) => {
    console.error("Connection error", err);
  });

const jwt = require("jsonwebtoken");

jsonwebtoken = require("jsonwebtoken");

const userRoutes = require("./src/routes/userRoute");
const users = require("./src/routes/userRoute");
const menuRoutes = require("./src/routes/menuRoute");
const presRouter = require("./src/routes/prescriptionRoute")
const setComplaintsRouter = require('./src/routes/setComplantsRoute')
const setMedicineRouter = require('./src/routes/setMedicineRoute')
const setExaminationRouter = require('./src/routes/setExaminationRoute')
const setDiaRouter = require('./src/routes/diagnosisRoute')
const setInvestigationRouter = require('./src/routes/investigationRoute')
const setAdviceRouter = require("./src/routes/setAdviceRoute")
const doctorInfoRouter = require("./src/routes/doctorInfoRoute")
const presSearchRouter = require("./src/routes/prescriptionSearchRoute")

const refressTokenRouter = require("./src/routes/refreshToken")
const authRoute = require("./src/routes/authRoute")
const fileUpload = require("express-fileupload");

const { default: helmet } = require("helmet");
// const PORT = 4002;

app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: false,
  })
);

app.use("/public", express.static("public"));

app.use(helmet());
app.use(fileUpload());

// DB connection
//mongodb+srv://<username>:<password>@invdb.odnqz.mongodb.net/?retryWrites=true&w=majority
//mongodb+srv://<username>:<password>@invdb.odnqz.mongodb.net/test
//mongodb://localhost:27017/inv_ecommerce
//mongodb+srv://invdb:invdb@invdb.odnqz.mongodb.net/?retryWrites=true&w=majority/inv_ecommerce

// mongoose.connect(`mongodb+srv://invdb:invdb@invdb.odnqz.mongodb.net/inv_ecommerce`)
// .then((_) => {
//   console.log('DB successfully connected!');
// })
// .catch((err) => {
//   console.error(err);
// });

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get("/test", function () {
  console.log("test");
});

app.get("/", (req, res) => {
  res.send("Hello World! ttt");
});

// Token Verification
app.use((req, res, next) => {
  if (
    req.headers &&
    req.headers.authorization &&
    req.headers.authorization.split(" ")[0] === "JWT"
  ) {
    jwt.verify(
      req.headers.authorization.split(" ")[1],
      "RESTfulAPIs",
      (err, decode) => {
        if (err) req.user = undefined;
        req.user = decode;
        next();
      }
    );
  } else {
    req.user = undefined;
    next();
  }
});

app.use("/api/auth", users);
app.use("/api/auth", userRoutes);
app.use("/api/menu", menuRoutes);
app.use("/api/prescription", presRouter);
app.use("/api/complaints", setComplaintsRouter);
app.use("/api/setMedicine", setMedicineRouter)
app.use("/api/setExa", setExaminationRouter)
app.use("/api/diag", setDiaRouter)
app.use("/api/investigation", setInvestigationRouter )
app.use("/api/advice", setAdviceRouter )
app.use("/api/doctorinfo", doctorInfoRouter )
app.use("/api/presSearch", presSearchRouter)
app.use("/api/refreshToken", refressTokenRouter)
app.use("/api/authnew",  authRoute )


app.get("/ping", (req, res) => {
  return res.send({
    error: false,
    message: "Server is healthy",
  });
});
app.listen(PORT, () => {
  console.log(`serve running ${PORT}`);
});

const mongoose = require('mongoose')

const examinationSchema = new mongoose.Schema({
    examinationId: {
        type: Number,
        require: true
    },
    examinationName: {
        type: String,
        require: true
    },
    activeStatus: {
        type: Number
    },
    createdy: {
        type: Number
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
        
    },
    updatedDate: {
        type: Date,
        default: Date.now
    }
})

module.exports= mongoose.model('SetExamination', examinationSchema)
const mongoose = require('mongoose')

const adviceSchema = new mongoose.Schema({
    adviceId: {
        type: Number,
        require: true
    },
    adviceName: {
        type: String,
        require: true
    },
    activeStatus: {
        type: Number
    },
    createdy: {
        type: Number
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
        
    },
    updatedDate: {
        type: Date,
        default: Date.now
    }
})

module.exports= mongoose.model('SetAdviceSchema', adviceSchema)
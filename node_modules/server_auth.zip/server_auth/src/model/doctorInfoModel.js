const mongoose = require('mongoose')

const doctorInfoSchema = new mongoose.Schema({
    doctorId: {
        type: Number,
        require: true
    },
    doctorNameEng: {
        type: String,
        require: true
    },
    doctorNameBan: {
        type: String,
        require: true
    },
    majorDegEng: {
        type: String,
        require: true
    },
    majorDegBan: {
        type: String,
        require: true
    },
    minorDegEng: {
        type: String,
        require: true
    },
    minorDegBan: {
        type: String,
        require: true
    },
    trainingEng: {
        type: String,
        require: true
    },
    trainingBan: {
        type: String,
        require: true
    },
    specialistEng: {
        type: String,
        require: true
    },
    specialistBan: {
        type: String,
        require: true
    },
    designationEng: {
        type: String,
        require: true
    },
    designationBan: {
        type: String,
        require: true
    },
    hosNameEng: {
        type: String,
        require: true
    },
    hosNameBan: {
        type: String,
        require: true
    },
    activeStatus: {
        type: Number
    },
    createdy: {
        type: Number
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
        
    },
    updatedDate: {
        type: Date,
        default: Date.now
    }
})

module.exports= mongoose.model('DoctorInfo', doctorInfoSchema)
const mongoose = require('mongoose')

const investigationSchema = new mongoose.Schema({
    investigationId: {
        type: Number,
        require: true
    },
    investigationName: {
        type: String,
        require: true
    },
    activeStatus: {
        type: Number
    },
    createdy: {
        type: Number
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
        
    },
    updatedDate: {
        type: Date,
        default: Date.now
    }
})

module.exports= mongoose.model('SetInvestigation', investigationSchema)
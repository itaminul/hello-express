const mongoose = require('mongoose')
const prescription = new mongoose.Schema({
    prescriptionId: {
        type: Number,
        unique: true
    },
    patientName: {
        type: String
    },
    age: {
        type: Number
    },
    gender: {
        type: Number
    },
    mobileNumber: {
        type: Number
    },
    activeStatus: {
        type: Number
    },
    createdy: {
        type: Number
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
        
    },
    updatedDate: {
        type: Date,
        default: Date.now
    }

})

module.exports = mongoose.model('Prescription', prescription);

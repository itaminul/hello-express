const mongoose = require('mongoose')

const diagnosisSchema = new mongoose.Schema({
    diagnosisId: {
        type: Number,
        require: true
    },
    diagnosisName: {
        type: String,
        require: true
    },
    activeStatus: {
        type: Number
    },
    createdy: {
        type: Number
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
        
    },
    updatedDate: {
        type: Date,
        default: Date.now
    }
})

module.exports= mongoose.model('SetDiagnosis', diagnosisSchema)
const mongoose = require('mongoose')

const medicine = new mongoose.Schema({
    medicineId: {
        type: Number,
        require: true
    },
    medicineName: {
        type: String,
        require: true
    },
    genericName: {
        type: String
    },
    brandName: {
        type: String
    },
    activeStatus: {
        type: Number
    },
    createdy: {
        type: Number
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
        
    },
    updatedDate: {
        type: Date,
        default: Date.now
    }
})

module.exports= mongoose.model('SetMedicine', medicine)
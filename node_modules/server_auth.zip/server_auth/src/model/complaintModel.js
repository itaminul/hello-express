const mongoose = require('mongoose')
const compaints = new mongoose.Schema({
    prescriptionId: {
        type: Number
    },
    complaintsName: {
        type: String
    },
    activeStatus: {
        type: Number,
        default: 1
    },
    createdy: {
        type: Number
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
        
    },
    updatedDate: {
        type: Date,
        default: Date.now
    }

})

module.exports = mongoose.model('Complaints', compaints);

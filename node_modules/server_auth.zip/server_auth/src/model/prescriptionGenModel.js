const mongoose = require('mongoose')
const prescriptionGen = new mongoose.Schema({
    prescriptionId: {
        type: Number
    },
    madicineId: {
        type: Number
    },
    dosages: {
        type: String
    },
    contin: {
        type: String
    },
    duration: {
        type: Number
    },
    remarks: {
      type: String
    },
    activeStatus: {
        type: Number
    },
    createdy: {
        type: Number
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
        
    },
    updatedDate: {
        type: Date,
        default: Date.now
    }

})

module.exports = mongoose.model('PrescriptionGen', prescriptionGen);

const mongoose = require('mongoose')
const advices = new mongoose.Schema({
    prescriptionId: {
        type: Number
    },
    doctorAdvice: {
        type: String
    },
    activeStatus: {
        type: Number
    },
    createdy: {
        type: Number
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
        
    },
    updatedDate: {
        type: Date,
        default: Date.now
    }

})

module.exports = mongoose.model('Advices', advices);

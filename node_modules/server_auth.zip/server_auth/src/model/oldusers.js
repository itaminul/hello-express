const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const dataSchema = new mongoose.Schema({
  userId: {
    type: Number,
    unique: true
  },
  name: {
    required: true,
    type: String,
  },

  phone: {
    type: String,
    required: true,
  },

  email: {
    type: String,
    required: true,
  },

  password: {
    type: String,
    required: true,
    minlength: 4,
  },
  //   hash_password: {
  //     type: String,
  //     required: true,
  //     minlength: 6,
  //     select: true,
  //   },
  //   accessToken: {
  //     type: String,
  //     default: null,
  //   },
  tokens: [
    {
      token: {
        type: String,
        required: true,
      },
    },
  ],

  createdOn: {
    type: Date,
    default: Date.now,
  },
});

dataSchema.pre("save", async function (next) {
  console.log("hi from");
  if (this.isModified("password")) {
    this.password = await bcrypt.hash(this.password, 12);
    // this.confirmPassword = await bcrypt.hash(this.confirmPassword, 12);
  }
  next();
});

dataSchema.methods.genrateAuthToken = async function () {
  try {
    let token = jwt.sign({ _id: this._id }, process.env.SECRET_KEY, {
      // expiresIn: "3h",
    });

    this.tokens = this.tokens.concat({ token: token });
    await this.save();
    return token;
  } catch (error) {
    console.log(error);
  }
};

//Create a Schema method to compare password

dataSchema.methods.createJWT = function () {
  return jwt.sign({ userId: this._id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_LIFETIME,
  });
};

module.exports = mongoose.model("User", dataSchema);

module.exports.hashPassword = async (password) => {
  try {
    const salt = await bcrypt.genSalt(10);
    return await bcrypt.hash(password, salt);
  } catch (error) {
    throw new Error("Hashing failed", error);
  }
};

module.exports.comparePasswords = async (inputPassword, hashedPassword) => {
  bcrypt.compare(password, this.password, function (error, isMatch) {
    if (error) {
      return callback(error);
    }

    return callback(null, isMatch);
  });
};

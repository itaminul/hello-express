const complaintsModel = require('../model/setComplaintModel')
exports.create= (req, res) => {
    try {
        let data = new complaintsModel({
            complaintsId: req.body.complaintsId,
            complaintsName: req.body.complaintsName,
            activeStatus:1
        })
        data.save()
        res.status(200).json({message: "Save Successfully"});
    
    } catch (error) {
        res.send('Not Insert')
        
    }

}

exports.getAll = async(req, res) => {
    try {
        const result = await complaintsModel.find() 
        res. send(result);    
    } catch (error) {
        res.send('Not Insert')
        
    }
}
const menuModel = require('../model/menuModel')
exports.createMeun = async(req, res) => {
    const menuData = new menuModel({
        menuName: req.body.menuName,
        menuType: req.body.menuType,
        menuPosition: req.body.menuPosition,
        activeStatus: req.body.activeStatus,
        orgId: req.body.orgId,
        companyId: req.body.companyId,
        entryDate: req.body.entryDate,
        entryBy: req.body.entryBy
    })
    try {
        const dataSave = await menuData.save();
        res.status(200).json({message: "Save Successfully"});
    }
    catch(error){
        res.status(500).json({error: 'an error occurred'});

    }
}

exports.getAll  = async(req, res) => {
    try{
        const data = await menuModel.find();
        res.json(data)
    }
    catch(error){
        res.status(500).json({message: error.message})
    }

}

exports.updateMenu = async(req, res) => {
    try{
    const dataSave = await menuModel.findOneAndUpdate(
        {_id:req.params.id},
        { 
            menuName: req.body.menuName,
            menuType: req.body.menuType,
            menuPosition: req.body.menuPosition,
            activeStatus: req.body.activeStatus,
            orgId: req.body.orgId,
            companyId: req.body.companyId,
            entryDate: req.body.entryDate,
            entryBy: req.body.entryBy
         }
        );
        res.status(200).json({message: "Update Successfully"});
    } catch(error){
        error.status(400).json({message: error.message})

    }
}

    
exports.deleteMenu = async(req, res) => {
    try{
    const dataSave = await menuModel.findByIdAndRemove(
        {_id:req.params.id}
        );
        res.status(200).json({message: "Delete Successfully"});
    } catch(error){
        error.status(400).json({message: error.message})

    }

}
const invesModel = require('../model/setInvesticationModel')
exports.create = async(req, res) => {

    try {
        const data = await new invesModel({
            investigationId: req.body.investigationId,
            investigationName: req.body.investigationName,
            activeStatus:1
        })
        
        data.save()
        res.status(200).json({message: "Save Successfully"});
    
    } catch (error) {
        res.send('Not Insert')
        
    }
}

exports.getAll = async(req, res) => {
    try {
        const result = await invesModel.find() 
        res. send(result);    
    } catch (error) {
        res.send('Not Insert')
        
    }
}

const compaintsModel = require('../model/setMedicineModel')
exports.create= (req, res) => {
    try {
        let data = new compaintsModel({
            medicineId: req.body.medicineId,
            medicineName: req.body.medicineName,
            genericName:req.body.genericName,
            brandName: req.body.brandName,
            activeStatus:1
        })
        data.save()
        res.status(200).json({message: "Save Successfully"});
    
    } catch (error) {
        res.send('Not Insert')
        
    }
    
}


exports.getAll = async(req, res) => {
    try {
        const result = await compaintsModel.find() 
        res. send(result);    
    } catch (error) {
        res.send('Not Insert')
        
    }
}
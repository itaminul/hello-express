const prescriptionModel = require("../model/prescriptionModel")
const presGenerate = require("../model/prescriptionGenModel")
exports.presSearch = async(req, res) => {
    let searchText = Number(req.params.keywords)
    // res.send(searchText)
     prescriptionModel.aggregate([
        { $match : { mobileNumber : searchText } } ,      
      {
        $lookup: {
            from: "prescriptiongens",
            localField: "prescriptionId",
            foreignField: "prescriptionId",
            as: 'rx'
        }
      },
      {
        $unwind: "$rx"
      },
      {
        $lookup: {
            from: "complaints",
            localField: "prescriptionId",
            foreignField: "prescriptionId",
            as: 'complaints'
        }
      },
      {
        $unwind: "$complaints"
      },
      {
        $lookup: {
            from: "investigations",
            localField: "prescriptionId",
            foreignField: "prescriptionId",
            as: 'investigation'
        }
      },
      {
        $unwind: "$investigation"
      },
      {
        $lookup: {
            from: "examinations",
            localField: "prescriptionId",
            foreignField: "prescriptionId",
            as: 'examinations'
        }
      },
      {
        $unwind: "$examinations"
      },
      {
        $lookup: {
            from: "advices",
            localField: "prescriptionId",
            foreignField: "prescriptionId",
            as: 'advices'
        }
      },
      {
        $unwind: "$advices"
      },

      { $project: { _id:1,patientName:1,age:1, gender:1, mobileNumber:1,
         'rx.madicineId':1, 'rx.dosages':1, 'rx.contin':1, 
      'rx.duration':1, 'rx.remarks':1,'complaints.complaintsName':1,'investigation.investigationName':1,
      'examinations.examinationName':1,'advices.doctorAdvice':1}}  
    ])
    .then((result) => {
        res.send(result)
    })
    .catch((error) => {
        res.send(error)
    })


}
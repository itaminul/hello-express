const doctorInfoModel = require('../model/doctorInfoModel')
exports.create = async(req, res) => {

    try {
        const data = await new doctorInfoModel({
            doctorId: req.body.doctorId,
            doctorNameEng: req.body.doctorNameEng,
            doctorNameBan: req.body.doctorNameBan,
            majorDegEng: req.body.majorDegEng,
            majorDegBan: req.body.majorDegBan,
            minorDegEng: req.body.minorDegEng,
            minorDegBan: req.body.minorDegBan,
            trainingEng: req.body.trainingEng,
            trainingBan: req.body.trainingBan,
            specialistEng: req.body.specialistEng,
            specialistBan: req.body.specialistBan,
            designationEng: req.body.designationEng,
            designationBan: req.body.designationBan,
            hosNameEng: req.body.hosNameEng,
            hosNameBan: req.body.hosNameBan,
            activeStatus:1
        })

        data.save()
        res.status(200).json({message: "Save Successfully"});
    
    } catch (error) {
        res.send('Not Insert')
        
    }
}

exports.getAll = async(req, res) => {
    try {
        const result = await doctorInfoModel.find() 
        res. send(result);    
    } catch (error) {
        res.send('Not Insert')
        
    }
}

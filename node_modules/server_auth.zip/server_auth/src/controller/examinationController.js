const setExaminationModel = require('../model/setExaminationModel')
exports.create = async(req, res) => {

    try {
        const data = await new setExaminationModel({
            examinationId: req.body.examinationId,
            examinationName: req.body.examinationName,
            activeStatus:1
        })

        data.save()
        res.status(200).json({message: "Save Successfully"});
    
    } catch (error) {
        res.send('Not Insert')
        
    }
}

exports.getAll = async(req, res) => {
    try {
        const result = await setExaminationModel.find() 
        res. send(result);    
    } catch (error) {
        res.send('Not Insert')
        
    }
}

const diagModel = require('../model/setDiagnosisModel')
exports.create = async(req, res) => {

    try {
        const data = await new diagModel({
            diagnosisId: req.body.diagnosisId,
            diagnosisName: req.body.diagnosisName,
            activeStatus:1
        })
        
        data.save()
        res.status(200).json({message: "Save Successfully"});
    
    } catch (error) {
        res.send('Not Insert')
        
    }
}

exports.getAll = async(req, res) => {
    try {
        const result = await diagModel.find() 
        res. send(result);    
    } catch (error) {
        res.send('Not Insert')
        
    }
}

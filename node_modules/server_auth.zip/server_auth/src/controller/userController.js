//import jwt
// https://buddy.works/tutorials/securing-node-and-express-restful-api-with-json-web-token
//https://dev.to/cyberwolve/jwt-authentication-with-access-tokens-refresh-tokens-in-node-js-5aa9
//https://codeforgeek.com/refresh-token-jwt-nodejs-authentication/

const usersModel = require("../model/Usern")
// import jsonwebtoken
const jwt = require("jsonwebtoken");

// import bcryptjs - hashing function
const bcrypt = require("bcryptjs");
// const becrypt = require("bcryptjs");
const { json } = require("express/lib/response");

const generateJwt = "../users/helpers/generateJwt";

exports.createUsers = async (req, res) => {
  const { name, phone, email, password } = req.body;
  const maxValue = await usersModel.find().sort({ userId: -1 }).limit(1);
  const userId = maxValue[0].userId + 1;
  try {
    const userExist = await usersModel.findOne({ email: email });
    if (userExist) {
      return res.status(409).json({ error: "Email already Exist" });
    } else {
      const user = new usersModel({userId,name, phone, email, password });
      await user.save();
      const accessToken = await user.genrateAuthToken();
      console.log(accessToken);
      res.send({
        success: true,
        accessToken: accessToken,
        userId: userId,
        email: email,
        name: name,
        phone: phone,
      });

      // return res.status(201).json({ message: "successful" });
    }
  } catch (error) {
    console.log(error);
  }
};

exports.getUserById = async(req, res) => {
  let id= req.params.userId;
  let user = await usersModel.find({userId: id})
  // let user = await usersModel.find({userId: id},{name:1, userId:1, phone:1, email:1 })
  res.send(user)

}

// exports.createUsers = async (req, res) => {
//   const { name, phone, email, password } = req.body;
//   console.log(name);

//   if (!name || !phone || !email || !password) {
//     return res.status(422).json({ error: "please filled properly" });
//   } else if (password.length < 4) {
//     return res.status(200).json({ error: "password atlest 4 digit" });
//   }

//   try {
//     const userExist = await usersModel.findOne({ email: email });

//     if (userExist) {
//       return res.status(409).json({ error: "Email already Exist" });
//     } else {
//       const user = new usersModel({ name, phone, email, password });
//       await user.save();
//       res.status(201).json({ message: "successful" });
//     }
//   } catch (error) {
//     console.log(error);
//   }
// };
// {
//   const data = new usersModel({
//     name: req.body.name,
//     email: req.body.email,
//     hash_password: req.body.hash_password,
//   });
//   try {
//     const dataToSave = await data.save();
//     const token = data.createJWT();
//     // console.log(dataToSave);
//     res.status(200).json(dataToSave, token);
//   } catch (error) {
//     res.status(400).json({ message: error.message });
//   }
// };

exports.singIn = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await usersModel.findOne({ email: email });
    if (!user) {
      return res.status(550).send({ message: "error" });
    }
    console.log(email);
    if (user) {
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(400).send({ message: "error" });
      }
      const accessToken = await user.genrateAuthToken();
      const name = await user.name;
      const phone = await user.phone;
      // console.log(name);
      // const accessToken = jwt.sign(
      //   {
      //     email: user.email,
      //     password: user.password,
      //   },
      //   process.env.SECRET_KEY,
      //   { expiresIn: "3h" }
      // );
      console.log(accessToken);
      // const name = await user.name;
      // const accessToken = jwt.sign(
      //   {
      //     email: user.email,
      //     password: user.password,
      //   },
      //   process.env.SECRET_KEY,
      //   { expiresIn: "3h" }
      // );
      console.log(accessToken);

      res.send({
        success: true,
        accessToken: accessToken,
        userId:user.userId,
        email: email,
        name: name,
        phone: phone,
      });
    } else {
      return res.status(401).send({ message: "unauthorized" });
    }
  } catch (error) {
    console.log(error);
  }
};

exports.Users = async (req, res) => {
  try {
    const user = await usersModel.find({});
    res.json(user);
  } catch (error) {
    console.log(error);
  }
};
//usersModel
//     .findOne({ email: req.body.email })
//     .then((user) => {
//       if (!user) {
//         return res.status(401).json({ msg: "Email address not found!" });
//       }
//       becrypt
//         .compare(req.body.hash_password, user.hash_password)
//         .then((valid) => {
//           if (!valid) {
//             return res.status(401).json({ msg: "Incorrect password" });
//           }
//           res.status(200).json({ msg: "Login success" });
//         })
//         .catch((error) => {
//           res.status(500).json({ msg: "No loing please try another" });
//         });
//     })
//     .catch((error) => {
//       res.status(500).json({ msg: "No loing please try another" });
//     });
// };

//right login

// exports.singIn = async(req, res) => {
// const email = req.body.email
// const hash_password = req.body.hash_password
// //find user exist or not
// usersModel.findOne({ email })
// .then(user => {
//     //if user not exist than return status 400
//     if (!user) return res.status(400).json({ msg: "User not exist" })

//     //if user exist than compare password
//     //password comes from the user
//     //user.password comes from the database
//     bcrypt.compare(hash_password, user.hash_password, (err, data) => {
//         //if error than throw error
//         if (err) throw err

//         //if both match than you can do anything
//         if (data) {
//             return res.status(200).json({ msg: "Login success" })
//         } else {
//             return res.status(401).json({ msg: "Invalid credencial" })
//         }

//     })

// })
// }

// exports.singIn = async(req, res) => {

//     usersModel.findOne({
//         email: req.body.email
//         }, (err, user) => {
//             if (err) throw err;
//                 if (!user) {
//         res.status(401).json({ message: 'Authentication failed. User not found.' });
//         }     else if (user) {
//                 if (!user(req.body.password)) {
//     res.status(401).json({ message: 'Authentication failed. Wrong password.' });
//     } else {
//                 res.json({ token: jwt.sign({ email: user.email, fullName: user.fullName, _id: user._id }, 'RESTfulAPIs')
//                     });
//                 }
//            }
//         });

// }

//running
// exports.singIn = function(req, res) {
//     User.findOne({
//       email: req.body.email
//     }, function(err, user) {
//       if (err) throw err;
//       if (!user || !user.comparePassword(req.body.password)) {
//         return res.status(401).json({ message: 'Authentication failed. Invalid user or password.' });
//       }
//       return res.json({ token: jwt.sign({ email: user.email, fullName: user.fullName, _id: user._id }, 'RESTFULAPIs') });
//     });
//   };

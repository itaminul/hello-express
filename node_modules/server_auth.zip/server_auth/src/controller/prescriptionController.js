const { model } = require('mongoose');
const prescriptionModel = require('../model/prescriptionModel')
const complaintsModel = require('../model/complaintModel')
const examinModel = require('../model/examinationModel')
const diagnosisModel = require('../model/diagnosisModel')
const investigationModel = require('../model/investigation')
const adviceModel = require('../model/adviceModel')
const presGeneModel = require('../model/prescriptionGenModel')
const patinInfoDate = require('../model/patientInfoDate')
exports.create = async(req, res) => {
try {
    // res.send(req.body)
    prescriptionModel.findOne().select('prescriptionId').sort('-prescriptionId').exec(function(err, item) {
    let getMaxValue = item.prescriptionId+1;
    //console.log(getMaxValue)
    //res.send(getMaxValue)
    
       let presData = new prescriptionModel({
        prescriptionId: getMaxValue,
        patientName: req.body.patientName,
        age: req.body.age,
        gender: req.body.gender,
        mobileNumber: req.body.mobileNumber,
        activeStatus:1
    })
    //save in the master table
    presData.save();


    //complaint table
    let comp = req.body.comppaintsObj
    if(comp){
         let compLength = comp.length
         
         for(let i=0 ; i<compLength; i++){
            let comValue = new complaintsModel({
            prescriptionId:getMaxValue,
            complaintsName:comp[i].complaintsName,
            activeStatus:1
            })
            comValue.save();
         }
   }

    //examin table insert
    let examin = req.body.examinationObj
    if(examin){
    let examinLength = examin.length
    
    for(let j=0 ; j<examinLength; j++){
       let examinValue = new examinModel({
        prescriptionId:getMaxValue,
        examinationName:examin[j].examinationName,
        activeStatus:1
       })
       examinValue.save();
    }
   }

        //diagnosis table insert
        let diagnosis = req.body.diagnosisValueObj

        if(diagnosis){
        let diagnosisLength = diagnosis.length
        
        for(let k=0 ; k<diagnosisLength; k++){
           let diagnosisalue = new diagnosisModel({
            prescriptionId:getMaxValue,
            diagnosisName:diagnosis[k].diagnosisName,
            activeStatus:1
           })
           diagnosisalue.save();
        }
      }
        //investigation table insert
        let investigation = req.body.investigationVaObj
        if(investigation){
        let investigationLength = investigation.length
        
        for(let m=0 ; m<investigationLength; m++){
           let investigationValue = new investigationModel({
            prescriptionId:getMaxValue,
            investigationName:investigation[m].investigationName,
            activeStatus:1
           })
           investigationValue.save();
        }
      }
         //advice table insert
         let adv = req.body.adviceObj
         if(adv){
         let adviceLength = adv.length
         
         for(let n=0 ; n<adviceLength; n++){
            let adviceLengthValue = new adviceModel({
             prescriptionId:getMaxValue,
             doctorAdvice:adv[n].doctorAdvice,
             activeStatus:1
            })
            adviceLengthValue.save();
         }
      }

            //prescription generate table insert
            let pgen = req.body.presGenerateObj
            if(pgen){
            let pgenLength = pgen.length
            
            for(let p=0 ; p<pgenLength; p++){
               let pgenLengthValue = new presGeneModel({
                prescriptionId:getMaxValue,
                madicineId:pgen[p].madicineId,
                dosages:pgen[p].dosages,
                contin:pgen[p].contin,
                duration:pgen[p].duration,
                remarks:pgen[p].remarks,
                activeStatus:1
               })
               pgenLengthValue.save();
            }   
         }

         let patinetInDate = new patinInfoDate({
            prescriptionId: getMaxValue,           
            presDate: req.body.presDate,
            folowUpDate : req.body.folowUpDate,
            activeStatus:1
        })
     
        patinetInDate.save();

})
res.status(200).json({message: "Save Successfully"});
    
} catch (error) {
    res.send('Not Insert')
    
}

}

exports.getAll = async(req, res) => {
    try {
        const result = await prescriptionModel.find() 
        res. send(result);    
    } catch (error) {
        res.send('Not Insert')
        
    }
}

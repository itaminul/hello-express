const adviceModel = require('../model/setAdviceModel')
exports.create= (req, res) => {
    try {
        let data = new adviceModel({
            adviceId: req.body.adviceId,
            adviceName: req.body.adviceName,
            activeStatus:1
        })
        data.save()
        res.status(200).json({message: "Save Successfully"});
    
    } catch (error) {
        res.send('Not Insert')
        
    }

}

exports.getAll = async(req, res) => {
    try {
        const result = await adviceModel.find() 
        res. send(result);    
    } catch (error) {
        res.send('Not Insert')
        
    }
}
const express = require('express')
const router = express.Router()
const setInvesController = require('../controller/investigationController')
router.get('/getAll', setInvesController.getAll)
router.post('/create', setInvesController.create)
module.exports= router
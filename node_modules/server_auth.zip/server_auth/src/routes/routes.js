const express = require('express');
const router = express.Router();
const cors = require('cors');
const Model = require('../model/users')

router.post('/post', async(req, res) => {
    
    const data = new Model({
        name: req.body.name,
        age:req.body.age
    })
   

    try {
        const dataToSave = await data.save();
        console.log(dataToSave);
        res.status(200).json(dataToSave)
    }
    catch (error) {
        res.status(400).json({message: error.message})
    }
})
module.exports=router;
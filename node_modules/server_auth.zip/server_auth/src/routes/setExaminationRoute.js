const express = require('express')
const router = express.Router()
const setExaminationController = require('../controller/examinationController')
router.get('/getAll', setExaminationController.getAll)
router.post('/create', setExaminationController.create)
module.exports= router
const express = require("express");
const router = express.Router();
const UserController = require("../controller/userController");
const cleanBody = require("../middlewares/cleanbody");
router.get("/users", UserController.Users);
router.get("/getUserById/:userId", UserController.getUserById);
// router.post('/register', cleanBody, UserController.createUsers)
router.post("/register", UserController.createUsers);
router.post("/login", UserController.singIn);

module.exports = router;

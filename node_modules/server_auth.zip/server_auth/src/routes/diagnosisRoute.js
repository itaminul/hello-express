const express = require('express')
const router = express.Router()
const setDiaController = require('../controller/diagnosisController')
router.get('/getAll', setDiaController.getAll)
router.post('/create', setDiaController.create)
module.exports= router
const express = require('express')
const router = express.Router()
const setCompController = require('../controller/complaintsController')
router.get('/getAll', setCompController.getAll)
router.post('/create', setCompController.create)
module.exports= router
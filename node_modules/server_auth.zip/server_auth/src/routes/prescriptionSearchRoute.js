const express = require('express')
const router = express.Router()
const preSearchController = require('../controller/prescriptionSearch')
router.get('/search/:keywords', preSearchController.presSearch)
module.exports= router
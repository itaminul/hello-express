const express = require('express')
const router = express.Router()
const setAdviceController = require('../controller/setAdviceController')
router.get('/getAll', setAdviceController.getAll)
router.post('/create', setAdviceController.create)
module.exports= router
const express = require('express')
const router = express.Router()
const prescriptionController = require('../controller/prescriptionController')
router.get('/getAll', prescriptionController.getAll)
router.post('/create', prescriptionController.create)
module.exports= router
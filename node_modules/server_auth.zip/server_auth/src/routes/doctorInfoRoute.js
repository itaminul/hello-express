const express = require('express')
const router = express.Router()
const auth = require("../middlewares/auth")
const doctorInfoController = require('../controller/doctorInfoController')
router.get('/getAll', auth, doctorInfoController.getAll)
router.post('/create', doctorInfoController.create)
module.exports= router
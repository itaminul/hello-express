npm i express-fileupload

npm install express mongoose jsonwebtoken dotenv bcrypt joi joi-password-complexity 

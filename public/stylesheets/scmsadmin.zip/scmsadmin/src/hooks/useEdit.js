import axios from 'axios'
import React, { useEffect, useState } from 'react'

const useEdit = (url, data) => {
    const [error, setError] = useState("")
    const [loader, setLoader] = useState(false)

    useEffect(() => {
        axios.patch(url, data)
        .then(response => {
            console.log(data)
            console.log(response)
        })
        .catch(error => {
            console.log(error.response)
        })
    }, [url])

    function editData() {
        axios.patch(url, data)
        .then(response => {
            console.log(data)
            console.log(response)
        })
        .catch(error => {
            console.log(error.response)
        })
    } 

    return {error, loader, editData};
 
}

export default useEdit

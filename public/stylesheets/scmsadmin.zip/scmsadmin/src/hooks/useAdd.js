import axios from "axios";
import { useEffect, useState } from "react";

const useAdd = (url, data) => {

    // const [database, setDatabase] = useState(null);
    const [error, setError] = useState("");
    const [loaded, setLoaded] = useState(false);

    useEffect(() => {
        axios.post(url, data)
            .then(response => {
                console.log(response)
            })
            .catch(error => {
                console.log(error.response)
            });
    }, [url]);

    function addData() {
        axios.post(url, data)
            .then(response => {
                console.log(data)
                console.log(response)
            })
            .catch(error => {
                console.log(error.response)
            });
    }

    return { error, loaded, addData };
}

export default useAdd;
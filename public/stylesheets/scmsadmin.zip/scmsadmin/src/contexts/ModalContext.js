import React, { createContext, useState } from 'react'

const ModalContext = createContext();

export const ModalProvider = ({ children }) => {

    const [showEdit, setShowEdit] = useState(false);
    const [showAdd, setShowAdd] = useState(false);
    const [val, setVal] = useState({});

    const handleCloseEdit = () => setShowEdit(false);
    const handleShowEdit = () => setShowEdit(true);

    const handleCloseAdd = () => setShowAdd(false);
    const handleShowAdd = () => setShowAdd(true);

    return (
        <ModalContext.Provider value={{
            showEdit, setShowEdit, handleCloseEdit,
            handleShowEdit, showAdd, setShowAdd, handleCloseAdd, handleShowAdd, val, setVal
        }}>
            {children}
        </ModalContext.Provider>
    )
}

export default ModalContext;
import React, { createContext, useState } from 'react'

const MenuContext = createContext();

export const MenuProvider = ({ children }) => {

    const [toggle, setToggle] = useState(false);

    const handleToggle = () => {
        setToggle(!toggle)
        console.log(toggle);
    }

    return (
        <MenuContext.Provider value={{ toggle, handleToggle }}>
            {children}
        </MenuContext.Provider>
    )
}

export default MenuContext;
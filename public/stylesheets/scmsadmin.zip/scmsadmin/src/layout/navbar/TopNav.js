import React, { useContext } from 'react'
import './TopNav.css'
import { GiHamburgerMenu } from 'react-icons/gi'
import { IoClose } from 'react-icons/io5'
import MenuContext from '../../contexts/MenuContext';

function TopNav() {

    const { toggle, handleToggle } = useContext(MenuContext);

    return (
        <div className='nav-container'>
            <div className='nav-option-container'>
                <div className='logout-container'>
                    Logout
                </div>
                <div className='hamburger' onClick={handleToggle}>
                    {toggle ? < GiHamburgerMenu /> : <IoClose />}
                </div>
            </div>

        </div>
    )
}

export default TopNav




import React, { useContext, useEffect, useState } from 'react'
import { Button, Form, InputGroup, Stack } from 'react-bootstrap'
import ModalContext from '../../../contexts/ModalContext'
import useAdd from '../../../hooks/useAdd';

function BatchAddForm() {

    const { handleCloseAdd } = useContext(ModalContext)
    const [value, setValue] = useState({});
    const handleInputChange = (e) => {
        e.preventDefault()
        setValue({ ...value, [e.target.name]: e.target.value })
    }

    const [maxId, setMaxId] = useState()
    useEffect(() => {
        fetch("http://192.168.0.84:4004/api/batch/maxid")  //API of MaxId
            .then(response => response.json())
            .then(data => setMaxId(data))
            .then(setValue(prev => ({ ...prev, batchId: maxId })))
        console.log(value);
    }, [maxId, value.batchId])

    const { addData } = useAdd('http://192.168.0.84:4004/api/batch/create', {
        batchId: maxId,
        batchesNo: value.batchesNo
    })

    const handleSubmit = () => {
        addData();
        handleCloseAdd();
        window.location = "/batch";
    }


    return (
        <div>
            <Form>
                <Form.Group className="mb-3">
                    <Form.Label>Batch ID</Form.Label>
                    <Form.Control
                        readOnly
                        placeholder="Batch ID"
                        aria-label="Batch ID"
                        aria-describedby=""
                        name="batchId"
                        onChange={handleInputChange}
                        defaultValue={maxId}
                    // onChange={handleInputChange}
                    />
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label>Batch No</Form.Label>
                    <Form.Control
                        placeholder="Batch No"
                        aria-label="Batch No"
                        aria-describedby=""
                        name="batchesNo"
                        onChange={handleInputChange}
                    // value={val.first_name}
                    // onChange={handleInputChange}
                    />
                </Form.Group>
                <Stack direction="horizontal" gap={3} >
                    <Button variant="secondary" className="ms-auto" onClick={handleCloseAdd}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={handleSubmit} >Submit</Button>
                </Stack>
            </Form>
        </div>
    )
}

export default BatchAddForm
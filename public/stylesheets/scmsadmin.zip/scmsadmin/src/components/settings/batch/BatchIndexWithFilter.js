import React, { useEffect, useState, useMemo, useContext, useRef } from 'react'
import { Button, Dropdown, Table } from 'react-bootstrap'
import { IoIosArrowDown, IoIosArrowUp } from 'react-icons/io'
import { BiDownload } from 'react-icons/bi'
import { FiEdit } from 'react-icons/fi'
import { BsFillSkipBackwardFill, BsFillSkipForwardFill } from 'react-icons/bs'
import GlobalFilter from '../../settings/GlobalFilter'
import csvDownload from 'json-to-csv-export'
import jsPDF from "jspdf";
import autoTable from 'jspdf-autotable';
import {
    useTable, useSortBy, useGlobalFilter, useFilters, usePagination,
    useResizeColumns, useRowSelect
} from 'react-table'
import ColumnFilter from '../ColumnFilter'
import { MdOutlineKeyboardArrowUp, MdOutlineKeyboardArrowDown } from 'react-icons/md'
import "../../settings/Table.css"
import { Checkbox } from '../../settings/CheckBox'
import EditModal from '../../modals/EditModal'
import ModalContext from '../../../contexts/ModalContext'
import AddModal from '../../modals/AddModal'
import useOutsideClick from '../../../hooks/useOutsideClick'
import BatchEditForm from './BatchEditForm'
import BatchAddForm from './BatchAddForm'


function BatchIndexWithFilter() {

    const { handleShowEdit, setVal } = useContext(ModalContext)
    const [dropdownShow, setDropdownShow] = useState(false);
    const impactRef = useRef();
    useOutsideClick(impactRef, () => setDropdownShow(false))

    // ##### Function to add row data and show modal ##### 

    function handleEdit(row) {
        setVal(row);
        handleShowEdit();
    }

    // ##### Columns of the table  ##### 

    const COLUMNS = [
        {
            Header: 'ID',
            accessor: 'id',
            Filter: ColumnFilter
        },
        {
            Header: 'First Name',
            accessor: 'first_name',
            Filter: ColumnFilter
        },
        {
            Header: 'Last Name',
            accessor: 'last_name',
            Filter: ColumnFilter
        },
        {
            Header: 'Email',
            accessor: 'email',
            Filter: ColumnFilter
        },
        {
            Header: 'Gender',
            accessor: 'gender',
            Filter: ColumnFilter
        },
        {
            Header: 'Date of Birth',
            accessor: 'date_of_birth',
            Filter: ColumnFilter
        },
        {
            Header: 'Contact Number',
            accessor: 'mobile_number',
            Filter: ColumnFilter
        },
        {
            Header: 'Action',
            accessor: 'action',
            Filter: ColumnFilter,
            Cell: row => (
                <div className='edit-button'>
                    <Button size="sm" onClick={e => handleEdit(row.row.original)}> {<FiEdit />} </Button>
                </div>
            ),
            disableFilters: true
        }
    ]

    // ### Fetching Data from Databse ### 

    const [data, setData] = useState([]);

    useEffect(() => {
        fetch("./assets/dummy data/MOCK_DATA.json", {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        })
            .then((res) => res.json())
            .then((data) => setData(data));

    }, []);

    const columns = useMemo(() => COLUMNS, [])
    const tableData = useMemo(() => data, [])
    const defaultColumn = useMemo(() => ({ Filter: ColumnFilter }), [])

    // ### Spreading Variables for useTables ###

    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        rows,
        page,
        nextPage,
        previousPage,
        canNextPage,
        canPreviousPage,
        pageOptions,
        gotoPage,
        pageCount,
        setPageSize,
        prepareRow,
        selectedFlatRows,
        allColumns,
        getToggleHideAllColumnsProps,
        state,
        setGlobalFilter
    } = useTable({
        columns,
        data,
        defaultColumn
    }, useFilters, useGlobalFilter, useResizeColumns, useSortBy, usePagination, useRowSelect,

        // ##### ROW SELECTION #####

        (hooks) => {
            hooks.visibleColumns.push((columns) => {
                return [
                    {
                        id: "selection",
                        Header: ({ getToggleAllRowsSelectedProps }) => (
                            <Checkbox {...getToggleAllRowsSelectedProps()} />
                        ),
                        Cell: ({ row }) => (
                            <Checkbox {...row.getToggleRowSelectedProps()} />
                        )
                    },
                    ...columns
                ]
            })
        }

        //     ##### ROW SELECTION #####
    )

    const { globalFilter, pageIndex, pageSize } = state;

    // ##### PDF Download Function ##### 

    const doc = new jsPDF()
    autoTable(doc, { html: '#data-table' }, {
        styles: {
            minCellHeight: 9,
            halign: "center",
            valign: "center",
            fontSize: 18,
        },
    })

    return (
        <div>

            <div className='modal-button-hide'>
                <EditModal>
                    <BatchEditForm />
                </EditModal>
            </div>

            <div className='title-container'>

                {/* ##### Title ##### */}

                <p> Batch Setting </p>

                {/* ##### Column Selection ##### */}

                <div ref={impactRef} className='column-selection'>
                    <div className='select-column-title' onClick={() => setDropdownShow(!dropdownShow)} >
                        Column Visibility {"   "} {dropdownShow ? < MdOutlineKeyboardArrowUp /> : <MdOutlineKeyboardArrowDown />}   </div>
                    <div className='column-list'
                        style={dropdownShow ? { display: "block" } : { display: "none" }} >
                        <div>
                            <Checkbox {...getToggleHideAllColumnsProps()} /> Check All
                        </div>
                        {
                            allColumns.map(column => (
                                <div key={column.id}>
                                    <label>
                                        <input type='checkbox' {...column.getToggleHiddenProps()} />
                                        {" " + column.Header}
                                    </label>
                                </div>
                            ))
                        }
                    </div>
                </div>

                {/* ##### Add New Data ##### */}

                <div className='add-new' >
                    <AddModal>
                        <BatchAddForm />
                    </AddModal>
                </div>
            </div>


            {/* ##### Row Per Page, Download and Search ##### */}


            <div className='search-container'>
                <div className='row-and-download'>
                    <div className='row-per-page'>
                        <label> Row per page </label>
                        <select name='pagesize' value={pageSize}
                            onChange={e => setPageSize(Number(e.target.value))}>
                            <option value={10} > 10 </option>
                            <option value={20} > 20 </option>
                            <option value={30} > 30 </option>
                        </select>
                    </div>

                    {/* ##### Download Options ##### */}

                    <Dropdown>
                        <Dropdown.Toggle id="dropdown-basic" className='download'>
                            < BiDownload />
                        </Dropdown.Toggle>
                        <Dropdown.Menu>
                            <Dropdown.Item onClick={() => csvDownload(data, "Data Table.csv")}>
                                Excel
                            </Dropdown.Item>
                            <Dropdown.Item onClick={() => doc.save('Data Table.pdf')}>
                                PDF
                            </Dropdown.Item>
                            <Dropdown.Item onClick={() => window.print()}>
                                Print
                            </Dropdown.Item>
                        </Dropdown.Menu>
                    </Dropdown>
                </div>

                <GlobalFilter filter={globalFilter} setFilter={setGlobalFilter} />
            </div>

            {/* ### Table Starts ###  */}

            <Table {...getTableProps()} className="data-table" id='data-table' striped bordered hover responsive="lg">
                <thead>
                    {
                        headerGroups.map(headerGroup => (
                            <tr {...headerGroup.getHeaderGroupProps()} className="table-head" >
                                {
                                    headerGroup.headers.map((column) => (
                                        <th{...column.getHeaderProps()}>

                                            <div {...column.getSortByToggleProps()}>
                                                {column.render('Header')}
                                                <span className='arrow'>
                                                    {column.isSorted ? (column.isSortedDesc ? <IoIosArrowDown /> : <IoIosArrowUp />) : ""}
                                                </span>
                                            </div>

                                            <div> {column.canFilter ? column.render('Filter') : null} </div>
                                        </th>
                                    ))}
                            </tr>
                        ))}
                </thead>

                <tbody {...getTableBodyProps()} >
                    {
                        page.map(row => {
                            prepareRow(row)
                            return (
                                <tr {...row.getRowProps()}>
                                    {
                                        row.cells.map((cell) => {
                                            return <td {...cell.getCellProps()}> {cell.render('Cell')} </td>

                                        })}
                                </tr>
                            )
                        })}
                </tbody>
            </Table>

            {/* ### Table Ends ###  */}

            {/* ##### Pagination Starts ##### */}

            <div className='pagination-container'>
                <div> Showing {page.length} out of {rows.length} entries </div>
                <div className='page-number'>
                    <span> Page {pageIndex + 1} of {pageOptions.length} </span>
                    <span>  Go to Page: {"   "}
                        <input type="number"
                            defaultValue={pageIndex + 1}
                            onChange={e => {
                                const pageNumber = e.target.value ? Number(e.target.value) - 1 : 0
                                gotoPage(pageNumber)
                            }} />
                    </span>
                </div>
                <div className='page-buttons'>
                    <button onClick={() => gotoPage(0)} disabled={!canPreviousPage} > {<BsFillSkipBackwardFill />} </button>
                    <button onClick={() => previousPage()} disabled={!canPreviousPage} > Previous </button>
                    <button onClick={() => nextPage()} disabled={!canNextPage} > Next </button>
                    <button onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage} > {<BsFillSkipForwardFill />} </button>
                </div>
            </div>

            {/* ##### Pagination Ends ##### */}

            <pre>
                <code>
                    {JSON.stringify(
                        {
                            selectedFlatRows: selectedFlatRows.map((row) => row.original),
                        },
                        null,
                        2
                    )}
                </code>
            </pre>
        </div >
    )
}
export default BatchIndexWithFilter
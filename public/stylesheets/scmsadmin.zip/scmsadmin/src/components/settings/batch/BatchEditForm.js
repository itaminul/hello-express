import React, { useContext, useState } from 'react'
import { Button, Form, InputGroup, Stack } from 'react-bootstrap'
import ModalContext from '../../../contexts/ModalContext'
import useEdit from '../../../hooks/useEdit'

function BatchEditForm() {
    const data = [
        {
            value: 1,
            label: "Active"
        },
        {
            value: 2,
            label: "Inactive"
        }
    ];

    const { val, handleCloseEdit } = useContext(ModalContext)
    const [activeStatus, setActiveStatus] = useState();

    const [value, setValue] = useState({});
    const handleInputChange = (e) => {
        e.preventDefault()
        setValue({ ...value, [e.target.name]: e.target.value })
    }

    const { editData } = useEdit(`http://192.168.0.84:4004/api/batch/update/${val._id}`, {
        batchesNo: value.batchesNo,
        activeStatus: activeStatus
    })

    // handle onChange event of the dropdown
    const handleActiveStatus = e => {
        console.log(e.target.value)
        setActiveStatus(e.target.value);
    }

    const handleSubmit = () => {
        console.log(value);
        editData();
        handleCloseEdit()
        window.location = "/batch";
    }

    return (
        <div>
            <Form>
                <Form.Group className="mb-3">
                    <Form.Label>Batch ID</Form.Label>
                    <Form.Control
                        readOnly
                        placeholder="Batch ID"
                        aria-label="Batch ID"
                        aria-describedby=""
                        name="batchId"
                        defaultValue={val.batchId}
                        onChange={handleInputChange}
                    />
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label>Batch No</Form.Label>
                    <Form.Control
                        placeholder="Batch No"
                        aria-label="Batch No"
                        aria-describedby=""
                        name="batchesNo"
                        defaultValue={val.batchesNo}
                        onChange={handleInputChange}
                    />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Label>Active Status</Form.Label>
                    <Form.Select className="mb-3" aria-label="Active Status"
                        defaultValue={val.activeStatus}
                        onChange={handleActiveStatus}
                    >
                        {data.map((bgv) => (
                            <option value={bgv.value}>{bgv.label}</option>

                        ))}
                    </Form.Select>
                </Form.Group>
                <Stack direction="horizontal" gap={3} >
                    <Button variant="secondary" className="ms-auto" onClick={handleCloseEdit}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={handleSubmit}>Submit</Button>
                </Stack>
            </Form>
        </div>
    )
}

export default BatchEditForm
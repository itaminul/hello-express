import React, { useContext, useState } from 'react'
import { Button, Form, InputGroup, Stack } from 'react-bootstrap'
import ModalContext from '../../../contexts/ModalContext'
import useEdit from '../../../hooks/useEdit'
const statusDatas = [
    {
        value: 1,
        label: 'Active'
    },
    {
        value: 2,
        label: 'Inactive'
    }
]

function DistrictEditForm() {
    const { val, handleCloseEdit } = useContext(ModalContext)
    const [districtValue, setDistrict] = useState([]);

    const handlerChange = (e) => {
        e.preventDefault()
        setDistrict({...districtValue, [e.target.name] : e.target.value})
    }

   const { editData } =  useEdit(`http://192.168.0.84:4004/api/districts/update/${val._id}`, {
    districts: districtValue.districts,
    districtsDescription:districtValue.districtsDescription,
    activeStatus:districtValue.activeStatus
   });

    const formSubmit = () => {
        editData()
        handleCloseEdit();
        window.location = "/district";  
    }

    return (
        <div>
            <Form.Group className="mb-3">
                <Form.Label>District ID</Form.Label>
                <Form.Control
                    readOnly
                    placeholder=""
                    aria-label="ID"
                    aria-describedby=""
                    name="districtId"
                    value={val.districtId}
                    onChange={handlerChange}
                />
            </Form.Group>            
            <Form.Group className="mb-3">
                <Form.Label>District Name</Form.Label>
                <Form.Control
                    placeholder=""
                    aria-label="ID"
                    aria-districts=""
                    name="districts"
                    defaultValue={val.districts}
                    onChange={handlerChange}
                />
            </Form.Group>
            <Form.Group className="mb-3">
                <Form.Label>District Description</Form.Label>
                <Form.Control
                    placeholder=""
                    aria-label="ID"
                    aria-describedby=""
                    name="districtsDescription"
                    defaultValue={val.districtsDescription}
                    onChange={handlerChange}
                />
            </Form.Group>
            <Form.Group className="mb-3">
                <Form.Label>Active Status</Form.Label>
                <Form.Select                  
                    placeholder="ID"
                    aria-label="ID"
                    aria-describedby=""
                    name="activeStatus"
                    defaultValue={val.activeStatus}
                    onChange={handlerChange}
                >
                    {statusDatas.map(statusData => (
                         <option value={statusData.value}>{statusData.label}</option>
                    ))}
                   
                </Form.Select>
            </Form.Group>
            <Stack direction="horizontal" gap={3} >
                <Button variant="secondary" className="ms-auto" onClick={handleCloseEdit}>
                    Close
                </Button>
                <Button variant="primary" onClick={formSubmit}>Submit</Button>
            </Stack>
        </div>
    )
}

export default DistrictEditForm
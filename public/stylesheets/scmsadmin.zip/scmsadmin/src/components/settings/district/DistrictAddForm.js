import React, { useState, useEffect, useContext } from 'react'
import { Button, Form, Stack } from 'react-bootstrap'
import ModalContext from '../../../contexts/ModalContext'
import useAdd from '../../../hooks/useAdd'

function DistrictAddForm() {
    const { val, handleCloseAdd } = useContext(ModalContext)
    const [value, setValue] = useState([]);
    const handleInputChange = (e) => {
        e.preventDefault()
        setValue({ ...value, [e.target.name]: e.target.value })
    }
    const [maxId, setMaxDisId] = useState()
    useEffect(() => {
        fetch("http://192.168.0.84:4004/api/districts/maxid")  //API of MaxId
            .then(response => response.json())
            .then(data => setMaxDisId(data))
            .then(setValue(prev => ({ ...prev, districtId: maxId })))
        console.log(value);
    }, [maxId, value.districtId])

    const { addData } = useAdd('http://192.168.0.84:4004/api/districts/create', {
        districtId: maxId,
        districts: value.districtName,
        districtsDescription: value.districtsDescription
    })

    const handleSubmit = () => {
        addData()
        handleCloseAdd();
        window.location = "/district";
    };
    return (
        <div>
            <Form>
                <Form.Group className="mb-3">
                    <Form.Label>District ID</Form.Label>
                    <Form.Control
                        readOnly
                        placeholder="ID"
                        aria-label="ID"
                        aria-describedby=""
                        name="districtId"
                        defaultValue={maxId}
                        onChange={handleInputChange}
                    />
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label>District name</Form.Label>
                    <Form.Control
                        placeholder="First Name"
                        aria-label="First Name"
                        aria-describedby=""
                        name="districtName"
                        // value={val.first_name}
                        onChange={handleInputChange}
                    />
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label>District Description</Form.Label>
                    <Form.Control
                        placeholder="Last Name"
                        aria-label="Last Name"
                        aria-describedby=""
                        name="districtsDescription"
                        // value={val.last_name}
                        onChange={handleInputChange}
                    />
                </Form.Group>
                <Stack direction="horizontal" gap={3} >
                    <Button variant="secondary" className="ms-auto" onClick={handleCloseAdd}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={handleSubmit}>Submit</Button>
                </Stack>
            </Form>
        </div>
    )
}

export default DistrictAddForm
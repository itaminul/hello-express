import React, { useContext, useState } from 'react'
import { Button, Form, InputGroup, Stack } from 'react-bootstrap'
import ModalContext from '../../../contexts/ModalContext'
import useEdit from '../../../hooks/useEdit';

function SessionEditForm() {
    const data = [
        {
            value: 1,
            label: "Active"
        },
        {
            value: 2,
            label: "Inactive"
        }
    ];

    const { val, handleCloseEdit } = useContext(ModalContext)
    const [activeStatus, setActiveStatus] = useState();

    const [value, setValue] = useState({});
    const handleInputChange = (e) => {
        e.preventDefault()
        setValue({ ...value, [e.target.name]: e.target.value })
    }

    const { editData } = useEdit(`http://192.168.0.84:4004/api/session/update/${val._id}`, {
        session: value.session,
        activeStatus: activeStatus
    })

    // handle onChange event of the dropdown
    const handleActiveStatus = e => {
        console.log(e.target.value)
        setActiveStatus(e.target.value);
    }

    const handleSubmit = () => {
        console.log(value);
        editData();
        handleCloseEdit()
        window.location = "/session";
    }

    return (
        <div>
            <Form>
                <Form.Group className="mb-3">
                    <Form.Label>Session ID</Form.Label>
                    <Form.Control
                        readOnly
                        placeholder="Session ID"
                        aria-label="Session ID"
                        aria-describedby=""
                        name="sessionId"
                        defaultValue={val.sessionId}
                        onChange={handleInputChange}
                    />
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label>Session</Form.Label>
                    <Form.Control
                        placeholder="Session"
                        aria-label="Session"
                        aria-describedby=""
                        name="session"
                        defaultValue={val.session}
                        onChange={handleInputChange}
                    />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Label>Active Status</Form.Label>
                    <Form.Select className="mb-3" aria-label="Active Status"
                        defaultValue={val.activeStatus}
                        onChange={handleActiveStatus}
                    >
                        {data.map((bgv) => (
                            <option value={bgv.value}>{bgv.label}</option>
                        ))}
                    </Form.Select>
                </Form.Group>
                <Stack direction="horizontal" gap={3} >
                    <Button variant="secondary" className="ms-auto" onClick={handleCloseEdit}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={handleSubmit}>Submit</Button>
                </Stack>
            </Form>
        </div>
    )
}

export default SessionEditForm
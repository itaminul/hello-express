import React, { useContext, useEffect, useState } from 'react'
import { Button, Form, InputGroup, Stack } from 'react-bootstrap'
import ModalContext from '../../../contexts/ModalContext'
import useAdd from '../../../hooks/useAdd';

function NationalitiesAddForm() {

    const { val, handleCloseAdd } = useContext(ModalContext)
    const [value, setValue] = useState([]);
    const handleInputChange = (e) => {
        e.preventDefault()
        setValue({ ...value, [e.target.name]: e.target.value })
    }
    const [maxId, setMaxId] = useState()
    useEffect(() => {
        fetch("http://192.168.0.84:4004/api/nationality/maxid")  //API of MaxId
            .then(response => response.json())
            .then(data => setMaxId(data))
            .then(setValue(prev => ({ ...prev, nationalityId: maxId })))
    }, [maxId, value.nationalityId])

    const { addData } = useAdd('http://192.168.0.84:4004/api/nationality/create', {
        nationalityId: maxId,
        nationality: value.nationality,
    })

    const handleSubmit = () => {
        addData()
        handleCloseAdd();
        window.location = "/nationality";
    };

    return (
        <div>
            <Form>
                <Form.Group className="mb-3">
                    <Form.Label>Nationality Id</Form.Label>
                    <Form.Control
                        readOnly
                        placeholder="Nationality Id"
                        aria-label="Nationality Id"
                        aria-describedby=""
                        name="nationalityId"
                        defaultValue={maxId}
                        onChange={handleInputChange}
                    />
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label>Nationality</Form.Label>
                    <Form.Control
                        placeholder="Nationality"
                        aria-label="Nationality"
                        aria-describedby=""
                        name="nationality"
                        // value={val.first_name}
                        onChange={handleInputChange}
                    />
                </Form.Group>
                <Stack direction="horizontal" gap={3} >
                    <Button variant="secondary" className="ms-auto" onClick={handleCloseAdd}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={handleSubmit}>Submit</Button>
                </Stack>
            </Form>
        </div>
    )
}

export default NationalitiesAddForm
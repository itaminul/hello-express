import React, { useContext, useState } from 'react'
import { Button, Form, InputGroup, Stack, Row, Col, FormLabel, Table } from 'react-bootstrap'
import ModalContext from '../../../contexts/ModalContext'
import useEdit from '../../../hooks/useEdit'

function TotalApplicantEditFrom() {

    const { val, handleCloseEdit } = useContext(ModalContext)
    const [value, setValue] = useState('')

    const handlerChange = (e) => {
        setValue({ ...value, [e.target.name]: e.target.value })
    }

    const { editData } = useEdit(`http://192.168.0.84:4004/api/verifypayment/update/${val._id}`, {
        appliConfirmStatus: value.appliConfirmStatus,
        remarksAfterApproved: value.remarksAfterApproved
    })

    const onSubmitForm = () => {
        editData();
        handleCloseEdit();
        window.location = "/totalapplicant";
    }

    const TableStyle = {
        textAlign: "center",
        fontSize: "0.825rem"
    }

    return (
        <>
            <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Applicant Name</Form.Label>
                <Form.Control type="text"
                    readOnly
                    placeholder="Applicant Name"
                    defaultValue={val.fullName} />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>National Merit</Form.Label>
                <Form.Control type="number"
                    readOnly
                    placeholder="National Merit"
                    defaultValue={val.merintPosition} />
            </Form.Group>

            <Row className="mb-3">
                <Col>
                    <FormLabel> Status : </FormLabel>
                    <InputGroup >
                        <Form.Check inline type="radio"
                            label="Approve for Merit List"
                            value="2"
                            name="appliConfirmStatus"
                            onChange={handlerChange}
                        />
                        <Form.Check inline type="radio"
                            label="Approve for Waiting List"
                            value="3"
                            name="appliConfirmStatus"
                            onChange={handlerChange}
                        />
                        <Form.Check inline type="radio"
                            label="Reject Candidate"
                            value="4"
                            name="appliConfirmStatus"
                            onChange={handlerChange}
                        />
                    </InputGroup>
                </Col>

                <Col>
                    <Table bordered style={TableStyle} >
                        <thead>
                            <tr>
                                <th>Total Merit</th>
                                <th>Unfilled Seats</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td> 1 </td>
                                <td> 40 </td>
                            </tr>
                        </tbody>
                    </Table>
                </Col>
            </Row>

            <Form.Group
                className="mb-3"
                controlId="exampleForm.ControlTextarea1"
            >
                <Form.Label>Remarks</Form.Label>
                <Form.Control
                    name='remarksAfterApproved'
                    type="text"
                    autoFocus
                    defaultValue={val.remarksAfterApproved}
                    onChange={handlerChange}
                />
            </Form.Group>

            <Stack direction="horizontal" gap={3} >
                <Button variant="secondary" className="ms-auto" onClick={handleCloseEdit}>
                    Close
                </Button>
                <Button variant="primary" onClick={onSubmitForm}>Submit</Button>
            </Stack>
        </>
    )
}

export default TotalApplicantEditFrom
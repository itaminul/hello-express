import React, { useContext, useState } from 'react'
import { Form, Container,Row, Col, Stack, Button } from 'react-bootstrap'
import ModalContext from '../../../contexts/ModalContext'
import useEdit from '../../../hooks/useEdit';
function VerifyPaymentEditForm() {
  const {val, handleCloseEdit, handleCloseAdd} = useContext(ModalContext);
  const[value, setValue] = useState('')

  const handlerChange = (e) => {
    setValue({ ...value, [e.target.name] : e.target.value})
  }


  const{editData} = useEdit(`http://192.168.0.84:4004/api/verifypayment/update/${val._id}`,{
    appliPaymentStatus: value.appliPaymentStatus,
    remarksAfterPayment: value.remarksAfterPayment
  })
  
  const onSubmitForm = () => {
    editData()
    handleCloseEdit();
    window.location = "/verifypayment"; 

  }
  
  return (
    <div>
      <Container>
        <Form>
          <Row>
            <Col xs={6} md={6}>           
           
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Transaction ID</Form.Label>
              <Form.Control
              readOnly
                name="transationId"
                type="text"
                autoFocus
                defaultValue={val.transationId}
              />
            </Form.Group>

            <Form.Group
              className="mb-3"
              controlId="exampleForm.ControlTextarea1"
            >
              <Form.Label>Status</Form.Label>
              <Form.Check 
              label="Approve Payment" 
               value="2"
               name="appliPaymentStatus" 
               type="radio" 
               aria-label="radio 1" 
               onChange={handlerChange}
               />
              <Form.Check 
              label="Reject Payment" 
                value="3"
                name="appliPaymentStatus" 
                type="radio" 
                aria-label="radio 1" 
                onChange={handlerChange}
                />
              </Form.Group>
              </Col>            

            <Col xs={6} md={6}>          

            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Payment Mobile No.</Form.Label>
                <Form.Control
                readOnly
                  name='moneySenderMob'
                  type="text"
                  autoFocus
                  val={val.moneySenderMob}
                />
              </Form.Group>

              <Form.Group
                className="mb-3"
                controlId="exampleForm.ControlTextarea1"
              >
               <Form.Label>Remarks</Form.Label>
                <Form.Control
                  name='remarksAfterPayment'
                  type="text"
                  autoFocus
                  // value={val.remarksAfterApproved}
                  onChange={handlerChange}
                />
              </Form.Group>
            </Col>

            <Col xs={6} md={6}>              
            <Form.Group>      
            <Stack direction="horizontal" gap={3} >
                <Button variant="secondary" className="ms-auto" onClick={handleCloseAdd}>
                    Close
                </Button>
                <Button variant="primary" onClick={onSubmitForm}>Submit</Button>
            </Stack>   
              </Form.Group>
            </Col>
          </Row>
        </Form>
      </Container>
    </div>
  )
}

export default VerifyPaymentEditForm

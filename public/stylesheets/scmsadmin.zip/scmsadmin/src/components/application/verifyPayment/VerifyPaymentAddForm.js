import React from 'react'

function VerifyPaymentAddForm() {
  return (
    <div>
      VerifyPaymentAddForm
    </div>
  )
}

export default VerifyPaymentAddForm

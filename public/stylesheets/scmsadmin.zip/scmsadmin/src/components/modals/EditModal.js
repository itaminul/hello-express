import React, { useContext, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import ModalContext from '../../contexts/ModalContext';

function EditModal({ size, children }) {

    const { showEdit, handleShowEdit, handleCloseEdit } = useContext(ModalContext)

    return (
        <>
            <Button variant="primary" onClick={handleShowEdit}>
                Launch static backdrop modal
            </Button>

            <Modal
                size={size}
                show={showEdit}
                onHide={handleCloseEdit}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Header closeButton>
                    <Modal.Title>Edit</Modal.Title>
                </Modal.Header>
                <Modal.Body>

                    {children}

                </Modal.Body>
            </Modal>
        </>
    )
}

export default EditModal
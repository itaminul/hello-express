import React from 'react'
import TopNav from '../layout/navbar/TopNav'
import Sidebar from '../layout/sidebar/Sidebar'
import '../components/settings/Table.css'
import Dashboard from '../components/dashboard/Dashboard'

function DashboardPage() {
    return (
        <div>
            <Sidebar />
            <TopNav />
            <div className='content' >
                <Dashboard />
            </div>

        </div>
    )
}

export default DashboardPage
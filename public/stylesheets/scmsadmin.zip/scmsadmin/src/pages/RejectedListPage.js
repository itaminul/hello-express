import React from 'react'
import TopNav from '../layout/navbar/TopNav'
import Sidebar from '../layout/sidebar/Sidebar'
import '../components/settings/Table.css'
import RejectedListIndex from '../components/application/rejectedList/RejectedListIndex'

function NationalitiesSettingPage() {
    return (
        <div>
            <Sidebar />
            <TopNav />
            <div className='content' >
                <RejectedListIndex />
            </div>
        </div>
    )
}

export default NationalitiesSettingPage
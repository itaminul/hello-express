import React from 'react'
import TopNav from '../layout/navbar/TopNav'
import Sidebar from '../layout/sidebar/Sidebar'
import '../components/settings/Table.css'
import BloodGroupIndex from '../components/settings/blood-group/BloodGroupIndex'

function BloodGroupSettingPage() {
    return (
        <div>
            <Sidebar />
            <TopNav />
            <div className='content' >
                <BloodGroupIndex />
            </div>
        </div>
    )
}

export default BloodGroupSettingPage
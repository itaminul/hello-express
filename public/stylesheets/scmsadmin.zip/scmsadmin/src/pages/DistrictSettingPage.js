import React from 'react'
import TopNav from '../layout/navbar/TopNav'
import Sidebar from '../layout/sidebar/Sidebar'
import '../components/settings/Table.css'
import DistrictIndex from '../components/settings/district/DistrictIndex'

function DistrictSettingPage() {
    return (
        <div>
            <Sidebar />
            <TopNav />
            <div className='content' >
                <DistrictIndex />
            </div>
        </div>
    )
}

export default DistrictSettingPage
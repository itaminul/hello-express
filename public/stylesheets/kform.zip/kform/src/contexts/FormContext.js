import React, { useState, createContext, useEffect } from 'react'
import PersonalInfo from '../components/application/PersonalInfo';
import DGHS from '../components/application/DGHS';
import FamilyInfo from '../components/application/FamilyInfo';
import NameOfGuardian from '../components/application/NameOfGuardian';
import Result from '../components/application/Result';
import Photo from '../components/application/Photo';
import Payment from '../components/application/Payment';
import Preview from '../components/application/Preview';

var initialValues = {
    batchNo: "",
    courseName: "",
    rollNo: "",
    testScore: "",
    meritScore: "",
    session: "",
    quota: "",
    meritPosition: "",
    collegeCode: "",
    serialNumber: "",
    sponsorIncome: "",
    freedomFighterName: "",
    freedomFighterRelation: "",
    sponsorsIncome: "",
    sponsorsNonFixedAsst: "",
    sponsorsFixedAsst: "",
    fullName: "",
    gender: "",
    homeDistrict: "",
    nationality: "",
    mobileNo: "",
    email: "",
    banglaName: "",
    bloodGroup: "",
    passportNo: "",
    dateOfBirth: "",
    maritalStatus: "",
    nidNo: "",
    birthRegNo: "",
    fatherName: "",
    fatherOccupation: "",
    fatherDesignation: "",
    fatherOrganization: "",
    fatherMobileNo: "",
    fatherEmail: "",
    presentAddress: "",
    motherName: "",
    motherOccupation: "",
    motherDesignation: "",
    motherOrganization: "",
    motherMobile: "",
    motherEmail: "",
    permanentAddress: "",
    guardianName: "",
    guardianMobile: "",
    guardianDesignation: "",
    guardianAddress: "",
    guardianRelation: "",
    guardianOccupation: "",
    guardianEmail: "",
    guardianOrganizationAddress: "",
    mediumOfEducation: "",
    sscInstitution: "",
    sscBoard: "",
    sscSession: "",
    sscPassingYear: "",
    sscScienceSubjects: "",
    sscGPA: "",
    sscBiologyGrade: "",
    hscInstitution: "",
    hscBoard: "",
    hscSession: "",
    hscPassingYear: "",
    hscScienceSubjects: "",
    hscGPA: "",
    hscBiologyGrade: "",
    reference1: "",
    reference2: "",
    passportImage: "",
    paymentMethod: "",
    transId: "",
    senderNo: "",
    receiptNo: "",
    otp: "",
}

const Districts = [
    "Dhaka",
    "Rajshahi",
    "Khulna",
    "Barisal",
    "Sylhet",
]

const Nationalities = [
    "Bangladeshi",
    "Indian",
    "Pakistani",
    "American",
    "British",
]


const FormContext = createContext();

export const FormProvider = ({ children }) => {
    const [step, setStep] = useState(0);
    const [values, setValues] = useState(initialValues || null);

    const [quota, setQuota] = useState("general");

    const [mobile, setMobile] = useState(true);

    useEffect(() => {
        console.log(values);
    }, [values])

    const [imgData, setImgData] = useState(null);


    const titles = [
        '', '', '', '', '', '', ''
    ];

    function pageDisplay() {
        switch (step) {
            case 0:
                return <DGHS />
            case 1:
                return <PersonalInfo />
            case 2:
                return <FamilyInfo />
            case 3:
                return <NameOfGuardian />
            case 4:
                return <Result />
            case 5:
                return <Photo />
            case 6:
                return <Payment />
            case 7:
                return <Preview />
        }
    }


    const [fields, setFields] = useState();

    // const updateFields = (data) => {
    //     setFields(data);
    // }


    const onSubmit = (data) => {
        // console.log(values);
        setStep((currStep) => currStep + 1);

    }

    const onBack = () => {
        setStep((currStep) => currStep - 1);
    }


    const handleInputChange = e => {
        const { name, value } = e.target
        setValues({
            ...values,
            [name]: value
        })
        console.log(value);
    }

    const handleImage = (e) => {
        // setImgData(e.target.files[0]);

        const { name, value } = e.target;
        console.log(name);
        setImgData({
            ...imgData,
            [name]: e.target.files[0]
        })
        // console.log(imgData);
    }

    useEffect(() => {
        console.log(imgData);
    }, [imgData])


    return (
        <FormContext.Provider value={{
            step, setStep, pageDisplay, titles, onSubmit, onBack,
            fields, setFields, quota, setQuota,
            setValues, values, initialValues, handleInputChange, Districts, Nationalities,
            imgData, setImgData, handleImage, mobile, setMobile
        }}>
            {children}
        </FormContext.Provider>
    );
};

export default FormContext

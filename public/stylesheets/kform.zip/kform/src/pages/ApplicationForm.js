import React from 'react'
import AmsForm from '../components/application/AmsForm'
import { FormProvider } from '../contexts/FormContext'

function ApplicationForm() {
    return (
        <>
            <AmsForm />
        </>
    )
}

export default ApplicationForm
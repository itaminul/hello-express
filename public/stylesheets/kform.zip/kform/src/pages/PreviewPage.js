import { Button, CardActions } from '@mui/material';
import React, { useContext } from 'react'
import FormContext from '../contexts/FormContext';

import '../components/styles/style.css'

function PreviewPage() {

    const { values, onBack } = useContext(FormContext);

    function print() {
        window.print();
    }

    return (
        <>
            <div className='preview-container'>
                <div className='logo-title-image-container'>
                    <div className='logo-container'>
                        <img
                            src={`${process.env.PUBLIC_URL}/assets/images/kya logo.png`}
                            alt=""
                        />
                    </div>
                    <div className='title-container'>
                        <div className='title'>
                            Khwaja Yunus Ali Medical College
                        </div>
                        <div className='address'>
                            Enayetpur, P.S:- Enayetpur, Chauhali, Sirajgonj-6751.
                            <br />
                            Tel: + 8802588834371-9, fax: +880 2588834431
                        </div>

                        <div className='founder-name'>
                            (Founder : DR. M. M. AMJAD HUSSAIN)
                        </div>
                    </div>
                </div>



                <div className='form-name'>
                    Application Form for Medical College Admission
                    <div className='course-session-contianer'>
                        <div> Batch No: {values.batchNo}  </div>
                        <div> Course: {values.courseName}  </div>
                        <div> Session: {values.session} </div>
                    </div>
                </div>

                {/* <div className='section-name'>
                Please Type or print in block letter
            </div> */}

                <div className='section-name'>
                    1. Merit Position in the merit list in the Admission Test conducted by DGHS, Dhaka:
                </div>
                <div className='grid-2'>
                    <div className='subsection-name'>
                        Roll No: {values.rollNo}
                    </div>
                    <div className='subsection-name'>
                        Test Score: {values.testScore}
                    </div>
                    <div className='subsection-name'>
                        Merit Score: {values.meritScore}
                    </div>
                    <div className='subsection-name'>
                        College Code: {values.collegeCode}
                    </div>
                    <div className='subsection-name'>
                        Serial No: {values.collegeCode}
                    </div>
                    <div className='subsection-name'>
                        Quota: {values.serialNumber}
                    </div>
                </div>


                <div className='subsection-name'>
                    Sponsors' Annual Income (General Quota): {values.sponsorIncome}
                </div>

                <div className='grid-2'>
                    <div className='subsection-name'>
                        Name of Freedom Fighter (Freedom Fighter Quota): {values.freedomFighterName}
                    </div>
                    <div className='subsection-name'>
                        Relationship with Applicant (Freedom Fighter Quota): {values.freedomFighterName}
                    </div>
                </div>

                <div className='grid-2'>
                    <div className='subsection-name'>
                        Sponsors' Annual Income (Poor and Meritorious Quota): {values.sponsorsIncome}
                    </div>
                    <div className='subsection-name'>
                        Sponsors' Fixed Asst (Poor and Meritorious Quota): {values.sponsorsFixedAsst}
                    </div>
                    <div className='subsection-name'>
                        Sponsors' Non Fixed Asst (Poor and Meritorious Quota): {values.sponsorsNonFixedAsst}
                    </div>
                </div>

                <br />
                <br />


                <div className='section-name'>
                    2. Applicant's Name
                </div>
                <div className='subsection-name'>
                    English: {values.fullName}
                </div>
                <div className='subsection-name'>
                    Bangla:  {values.banglaName}
                </div>



                <div className='section-name'>
                    3. Applicant's Info:
                </div>
                <div className='grid-2'>
                    <div className='subsection-name'>
                        Gender:  {values.gender}
                    </div>
                    <div className='subsection-name'>
                        Date of Birth:  {values.dateOfBirth}
                    </div>
                    <div className='subsection-name'>
                        Blood Group: {values.bloodGroup}
                    </div>
                    <div className='subsection-name'>
                        Marital Status: {values.maritalStatus}
                    </div>
                    <div className='subsection-name'>
                        Home District: {values.homeDistrict}
                    </div>
                    <div className='subsection-name'>
                        Nationality: {values.nationality}
                    </div>
                    <div className='subsection-name'>
                        Applicant's NID No: {values.nidNo}
                    </div>
                    <div className='subsection-name'>
                        Applicant's Birth Reg No: {values.birthRegNo}
                    </div>
                    <div className='subsection-name'>
                        Applicant's Mobile No:  {values.mobileNo}
                    </div>
                    <div className='subsection-name'>
                        Applicant's Email Address: {values.email}
                    </div>
                    <div className='subsection-name'>
                        Applicant's Passport No: {values.passportNo}
                    </div>

                </div>

                <br />

                <div className='section-name'>
                    4. Father's Name:
                    <span className='subsection-name'>
                        {values.fatherName} &nbsp;
                    </span>
                </div>
                <div className='subsection-name'>
                    Occupation / Designation / Organization:
                    {values.fatherOccupation} / {values.fatherDesignation} / {values.fatherOrganization}
                </div>
                <div className='grid-2'>
                    <div className='subsection-name'>
                        Contact No: {values.fatherMobileNo}
                    </div>
                    <div className='subsection-name'>
                        Email Address: {values.fatherEmail}
                    </div>
                </div>

                <br />

                <div className='section-name'>
                    5. Mother's Name: &nbsp;
                    <span className='subsection-name'>
                        {values.motherName}
                    </span>
                </div>
                <div className='subsection-name'>
                    Occupation / Designation / Organization:
                    {values.motherOccupation} / {values.motherDesignation} / {values.motherOrganization}
                </div>
                <div className='grid-2'>
                    <div className='subsection-name'>
                        Contact No: {values.motherMobile}
                    </div>
                    <div className='subsection-name'>
                        Email Address:  {values.motherEmail}
                    </div>
                </div>

                <br />

                <div className='section-name'>
                    6. Present / Mailing Address:
                </div>
                <span className='subsection-name'>
                    {values.presentAddress}
                </span>

                <br />

                <div className='section-name'>
                    7. Permanent Address:
                </div>
                <span className='subsection-name'>
                    {values.permanentAddress}
                </span>

                <br />

                <div className='section-name'>
                    8. Name of Guardian: &nbsp;
                    <span className='subsection-name'>
                        {values.guardianName}
                    </span>
                </div>
                <div className='subsection-name'>
                    Relationship:  {values.guardianRelation}
                </div>
                <div className='subsection-name'>
                    Occupation / Designation / Organization:
                    {values.guardianOccupation} /  {values.guardianDesignation} / {values.guardianName}
                </div>
                <div className='subsection-name'>
                    Mobile No: {values.guardianMobile}
                </div>
                <div className='subsection-name'>
                    Email Address: {values.guardianEmail}
                </div>
                <div className='subsection-name'>
                    Postal Address: {values.guardianAddress}
                </div>
                <div className='subsection-name'>
                    Organization Address: {values.guardianOrganizationAddress}
                </div>

                <br />


                <div className='section-name'>
                    9. Details of Education:
                </div>
                <div className='section-name'>
                    Medium of Education: &nbsp;
                    <span className='subsection-name'>
                        {values.mediumOfEducation}
                    </span>
                </div>
                <div className='section-name'>
                    Results of Previous Examinations
                </div>
                <table className='result-table'>
                    <tr className='result-table-row'>
                        <th className='result-table-head'> Examination </th>
                        <th className='result-table-head'> Name of Educational Institute & Address </th>
                        <th className='result-table-head'> Board </th>
                        <th className='result-table-head'> Session </th>
                        <th className='result-table-head'> Year of Passing </th>
                        <th className='result-table-head'> Science Subjects </th>
                        <th className='result-table-head'> Total Grade Point Average (GPA) </th>
                        <th className='result-table-head'> Grade Point in Biology </th>
                    </tr>

                    <tr className='result-table-row'>
                        <td className='result-table-data'> S.S.C / Equivalent </td>
                        <td className='result-table-data'> {values.sscInstitution} </td>
                        <td className='result-table-data'> {values.sscBoard} </td>
                        <td className='result-table-data'> {values.sscSession} </td>
                        <td className='result-table-data'> {values.sscPassingYear} </td>
                        <td className='result-table-data'> {values.sscScienceSubjects} </td>
                        <td className='result-table-data'> {values.sscGPA} </td>
                        <td className='result-table-data'> {values.sscBiologyGrade} </td>
                    </tr>

                    <tr className='result-table-row'>
                        <td className='result-table-data'> H.S.C / Equivalent </td>
                        <td className='result-table-data'> {values.hscInstitution} </td>
                        <td className='result-table-data'> {values.hscBoard} </td>
                        <td className='result-table-data'> {values.hscSession} </td>
                        <td className='result-table-data'> {values.hscPassingYear} </td>
                        <td className='result-table-data'> {values.hscScienceSubjects} </td>
                        <td className='result-table-data'> {values.hscGPA} </td>
                        <td className='result-table-data'> {values.hscBiologyGrade} </td>
                    </tr>

                </table>

                <br />

                <div className='section-name'>
                    10.   Names and Addresses of Two Referees Resident
                    in your country who could testify to your
                    Character, academic background and capacity of
                    Further studies (Preferably from Head of Schools
                    / College)
                </div>
                <div className='grid-2'>

                    <div className='subsection-name reference'>
                        1. {values.reference1}
                    </div>
                    <div className='subsection-name reference'>
                        2. {values.reference2}
                    </div>

                </div>

                <br />

                <div className='section-name'>
                    11. Payment Method: &nbsp;
                    <span className='subsection-name'>
                        {values.paymentMethod}
                    </span>
                </div>
                <div className='grid-2'>
                    <div className='subsection-name'>
                        Transaction ID (Mobile Banking) :  {values.transId}
                    </div>
                    <div className='subsection-name'>
                        Sender no (Mobile Banking) : {values.senderNo}
                    </div>
                </div>
                <div className='grid-2'>
                    <div className='subsection-name'>
                        Receipt No (Cash) :  {values.receiptNo}
                    </div>
                    <div className='subsection-name'>
                        OTP (Cash) : {values.otp}
                    </div>
                </div>

                <br />

                <div className='section-name'>
                    Following must be attached with the application failing which the applicant will not be considered
                    for admission test:
                </div>

                <div className='subsection-name'>
                    <ol>
                        <li> Six recent passport size coloured photos attested by gazetted officer (Lab print) </li>
                        <li> Original Certificate / attested copies of S.S.C /O Level H.S.C / A Level marks sheet from the
                            respective examination board (Originals to be submitted during the time of admission)
                        </li>
                        <li> School & College leaving certificate/testimonial from the Head of the institute
                        </li>
                        <li> Nationality certificate / National ID Card/ (Photocopy)/ birth certificate from competent authority </li>
                        <li> Other than those documents listed above as per College Prospectus </li>
                        <li> Certificate of proof to be attached in favour of co-curriculum activities </li>
                        <li> Attested copies of SSC/O Level, HSC / A Level Examination Certificate / testimonial </li>
                        <li> Medical (MBBS) admission test admit card & copy of admission test result (colour print) </li>
                        <li> Admit card or Roll no. slip. of HSC / A Level Examination Certificate (Photocopy)
                        </li>
                    </ol>
                </div>

                <br />

                <div className='section-name'>
                    12. Declaration by the Candidate:
                </div>
                <div className='subsection-name'>
                    I <span className='section-name'>  </span> S/O  <span className='section-name'>  </span> do hereby declare that in event of my
                    admission into KYAMC, I will not participate or involve myself directly or indirectly in any political party,
                    organization, social or cultural or religious group, any student union, having affiliation with any political party
                    within KYAMC campus or outside the campus during my study life in KYAMC other than approved by college
                    authority.
                </div>

                <br />

                <div className='section-name'>
                    13. Declaration by Parent / Guardian:
                </div>
                <div className='subsection-name'>
                    I do hereby declare that in the event of my ward son <span className='section-name'>  </span> Being successful in
                    obtaining admission to the Medical College, we pledge that we shall make all arrangements for timely
                    payment of all dues, tuition fees and such other fees may be required to be paid during the period of his / her
                    studies at KYAMC I also agree to give an undertaking for good conduct of my Son/daughter / ward.
                    I solemnly declare that my yearly income is Tk. <span className='section-name'>  </span> Approximately and the source of my income is
                    salary/Business/Land properties etc.
                </div>

                <br />

                <div className='grid-2'>
                    <div className='subsection-name'>
                        Signature: Parent’s / Guardian
                    </div>
                    <div className='subsection-name'>
                        Signature of Applicant
                    </div>

                </div>

                <br />

                <div className='subsection-name'>
                    Note:
                </div>
                <div className='subsection-name'>
                    <ol>
                        <li> In the case of GEC (Advanced level) of the University of London, a certificate from the University
                            authority stating that the candidate has obtained the required grades to pursue studies in medicine. This
                            certificate should be from a University authority of the country where the candidate secured the
                            qualifying examination certificate. Candidate should obtain and submit equivalency test form competent
                            authority of Bangladesh. </li>
                        <li> Candidates should submit original certificate only. </li>
                        <li> The college authority do not provide any residential or travel facilities for interview / applicant. </li>
                        <li> A candidate once admitted and fails to attend classes within 15 days is liable to loose his / her seat. </li>
                        <li> In event of any student taking more than 5 (five) years to pass the MBBS Final Prof. Examination, the
                            student shall have to pay tuition fee and other applicable charges as regular student. </li>
                        <li> Applicant or representative is required to submit the application form in person. </li>
                        <li> No fees will be refunded after admission in college </li>
                    </ol>
                </div>

            </div>
            <div className='print-button' >
                <CardActions sx={{ justifyContent: "center" }}  >
                    <Button type="submit" variant="contained" onClick={print}
                        sx={{ m: 2 }} >Print</Button>
                </CardActions>

            </div>
        </>
    )
}

export default PreviewPage
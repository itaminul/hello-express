import React, { useContext } from 'react'
import {
    Button, Table, TableBody, TableCell, TableHead, TableRow, TextField, Typography,
    Grid, RadioGroup, FormLabel, FormControl, FormControlLabel, Radio
} from '@mui/material'
import FormContext from '../../contexts/FormContext';

function Result() {

    const { onSubmit, onBack, values, handleInputChange } = useContext(FormContext)

    return (
        <>
            <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                Details of Education
            </Typography>
            <form onSubmit={onSubmit}>

                <FormControl sx={{ m: 1 }}>
                    <FormLabel >Medium of Education :</FormLabel>
                    <RadioGroup
                        row
                        value={values.mediumOfEducation}
                        name="mediumOfEducation"
                        defaultValue="bangla"
                        onChange={handleInputChange}
                    >
                        <FormControlLabel value="Bangla" control={<Radio />} label="Bangla Medium" />
                        <FormControlLabel value="English" control={<Radio />} label="English Medium" />
                    </RadioGroup>
                </FormControl>

                <Table>
                    <TableHead sx={{ backgroundColor: "#FAEBD7" }}>
                        <TableRow >
                            <TableCell align="center">Examination</TableCell>
                            <TableCell align="center">Name of Educational Institute & Address</TableCell>
                            <TableCell align="center">Board</TableCell>
                            <TableCell align="center">Session</TableCell>
                            <TableCell align="center">Year of Passing</TableCell>
                            <TableCell align="center">Science Subjects</TableCell>
                            <TableCell align="center">Total Grade Point Average (GPA)</TableCell>
                            <TableCell align="center">Grade Point in Biology</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        <TableRow>
                            <TableCell sx={{ backgroundColor: "#E9ECEF" }} >S.S.C / Equivalent</TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    name='sscInstitution'
                                    value={values.sscInstitution}
                                    onChange={handleInputChange}
                                // required
                                // {...register('sscInstitution')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    name='sscBoard'
                                    value={values.sscBoard}
                                    onChange={handleInputChange}
                                // required
                                // {...register('sscBoard')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    name='sscSession'
                                    value={values.sscSession}
                                    onChange={handleInputChange}
                                // required
                                // required
                                // {...register('sscSession')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    type="number"
                                    name='sscPassingYear'
                                    value={values.sscPassingYear}
                                    onChange={handleInputChange}
                                // required
                                // {...register('sscPassingYear')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    name='sscScienceSubjects'
                                    value={values.sscScienceSubjects}
                                    onChange={handleInputChange}
                                // required
                                // {...register('sscScienceSubjects')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    type="number"
                                    name='sscGPA'
                                    value={values.sscGPA}
                                    onChange={handleInputChange}
                                // required
                                // {...register('sscGPA')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    type="number"
                                    name='sscBiologyGrade'
                                    value={values.sscBiologyGrade}
                                    onChange={handleInputChange}
                                // required
                                // {...register('sscBiologyGrade')}
                                />
                            </TableCell>
                        </TableRow>
                        <TableRow>
                            <TableCell sx={{ backgroundColor: "#E9ECEF" }} >H.S.C / Equivalent</TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    name='hscInstitution'
                                    value={values.hscInstitution}
                                    onChange={handleInputChange}
                                // required
                                // {...register('hscInstitution')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    name='hscBoard'
                                    value={values.hscBoard}
                                    onChange={handleInputChange}
                                // required
                                // {...register('hscBoard')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    name='hscSession'
                                    value={values.hscSession}
                                    onChange={handleInputChange}
                                // required
                                // {...register('hscSession')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    type="number"
                                    name='hscPassingYear'
                                    value={values.hscPassingYear}
                                    onChange={handleInputChange}
                                // required
                                // {...register('hscPassingYear')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    name='hscScienceSubjects'
                                    value={values.hscScienceSubjects}
                                    onChange={handleInputChange}
                                // required
                                // {...register('hscScienceSubjects')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    type="number"
                                    name='hscGPA'
                                    value={values.hscGPA}
                                    onChange={handleInputChange}
                                // required
                                // {...register('hscGPA')}
                                />
                            </TableCell>
                            <TableCell>
                                <TextField
                                    variant="outlined"
                                    fullWidth
                                    type="number"
                                    name='hscBiologyGrade'
                                    value={values.hscBiologyGrade}
                                    onChange={handleInputChange}
                                // required
                                // {...register('hscBiologyGrade')}
                                />
                            </TableCell>
                        </TableRow>
                    </TableBody>
                </Table>

                <Typography variant="h6" component="div" align='center'>
                    Name of address of two referees resident in your country who could testify to your character, academic background and capacity of further studies.
                    (Preferable from head of schools / college)
                </Typography>

                <Grid container spacing={4}
                    justifyContent="center"
                    alignItems="flex-start">

                    <Grid item xs={12} md={6} >
                        <TextField
                            label="Reference 01"
                            variant="outlined"
                            fullWidth
                            multiline rows={4}
                            sx={{ m: 1 }}
                            name='reference1'
                            value={values.reference1}
                            onChange={handleInputChange}
                        // required
                        // {...register('reference1')}
                        />
                    </Grid>

                    <Grid item xs={12} md={6} >
                        <TextField
                            label="Reference 02"
                            variant="outlined"
                            fullWidth
                            multiline rows={4}
                            sx={{ m: 1 }}
                            name='reference2'
                            value={values.reference2}
                            onChange={handleInputChange}
                        // {...register('reference2')}
                        />
                    </Grid>
                </Grid>

                <Button type='button' onClick={onBack}
                    variant="outlined" sx={{ m: 2 }}>Back</Button>

                <Button type="submit" variant="contained"
                    sx={{ m: 2 }}>Next</Button>

            </form>
        </>
    )
}

export default Result
import React, { useContext, useEffect, useState } from 'react'
import {
    Grid, TextField, Button, Typography, FormControl, FormLabel, RadioGroup,
    FormControlLabel, Radio
} from '@mui/material'
import FormContext from '../../contexts/FormContext';
import '../styles/style.css'

function Payment() {

    const { onSubmit, onBack, quota, values, handleInputChange, mobile, setMobile } = useContext(FormContext);

    return (
        <>
            <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                Payment Information
            </Typography>


            <form onSubmit={onSubmit}>

                {quota !== "poor" &&
                    <>
                        <FormControl sx={{ m: 1 }}>
                            <FormLabel > Payment Method :</FormLabel>
                            <RadioGroup
                                row
                                value={values.paymentMethod}
                                name="paymentMethod"
                                // defaultValue="mobileBanking"
                                onChange={handleInputChange}
                            >
                                <FormControlLabel value="mobileBanking" control={<Radio />} label="Mobile Banking"
                                    onClick={() => setMobile(true)} />
                                <FormControlLabel value="cash" control={<Radio />} label="Cash"
                                    onClick={() => setMobile(false)} />
                            </RadioGroup>
                        </FormControl>




                        {mobile ?

                            <>
                                <div className='image-container'>

                                    <img
                                        src={`${process.env.PUBLIC_URL}/assets/images/bkash.png`}
                                        alt=""
                                    />
                                    <img
                                        src={`${process.env.PUBLIC_URL}/assets/images/rocket.png`}
                                        alt=""
                                    />
                                    <img
                                        src={`${process.env.PUBLIC_URL}/assets/images/nagad.png`}
                                        alt=""
                                    />
                                    <img
                                        src={`${process.env.PUBLIC_URL}/assets/images/upay.png`}
                                        alt=""
                                    />
                                </div>

                                <Typography variant="h6" component="h6" align="center" sx={{ mb: 3 }}>
                                    The Merchant Number is <Typography variant="h5" component="h5" color="red" >  01789517561 </Typography>
                                </Typography>

                                <Typography variant="h6" component="h6" align="center" sx={{ mb: 3 }}>
                                    Application Fee <Typography variant="h5" component="h5" color="red" > Only 1200tk BDT </Typography>
                                </Typography>

                                <Grid container spacing={4}
                                    justifyContent="center"
                                    alignItems="flex-start">

                                    <Grid item xs={12} md={6} >
                                        <TextField
                                            label="Transaction ID"
                                            variant="outlined"
                                            fullWidth
                                            sx={{ m: 1 }}
                                            type="number"
                                            name='transId'
                                            value={values.transId}
                                            onChange={handleInputChange}
                                        // required
                                        // {...register('transId')}
                                        />
                                    </Grid>

                                    <Grid item xs={12} md={6} >
                                        <TextField
                                            label="Money Sender Mobile No"
                                            variant="outlined"
                                            fullWidth
                                            sx={{ m: 1 }}
                                            type="number"
                                            name='senderNo'
                                            value={values.senderNo}
                                            onChange={handleInputChange}
                                        // required
                                        // {...register('senderNo')} 
                                        />
                                    </Grid>
                                </Grid>

                            </>
                            :
                            <>
                                <Typography variant="h6" component="h6" align="center" sx={{ m: 3 }}>
                                    Kindly make sure you have paid valid amount with visible money receipt serial no.
                                </Typography>

                                <Typography variant="h6" component="h6" align="center" sx={{ mb: 3 }}>
                                    Application Fee <Typography variant="h5" component="h5" color="red" > Only 1200tk BDT </Typography>
                                </Typography>

                                <Grid container spacing={4}
                                    justifyContent="center"
                                    alignItems="flex-start">

                                    <Grid item xs={12} md={6} >
                                        <TextField
                                            label="Money Receipt Serial Number"
                                            variant="outlined"
                                            fullWidth
                                            sx={{ m: 1 }}
                                            type="number"
                                            name='receiptNo'
                                            value={values.receiptNo}
                                            onChange={handleInputChange}
                                        // required
                                        // {...register('receiptNo')}
                                        />
                                    </Grid>

                                    <Grid item xs={12} md={6} >
                                        <TextField
                                            label="OTP"
                                            variant="outlined"
                                            fullWidth
                                            sx={{ m: 1 }}
                                            type="number"
                                            name='otp'
                                            value={values.otp}
                                            onChange={handleInputChange}
                                        // required
                                        // {...register('givenAmount')}
                                        />
                                    </Grid>
                                </Grid>
                            </>

                        }

                    </>
                }

                {quota === "poor" &&
                    <>
                        <Typography variant="h6" component="h6" align="center" sx={{ m: 2 }}>
                            Payment isn't applicable for you. Please submit the form.
                        </Typography>
                    </>
                }

                <Button type='button' onClick={onBack}
                    variant="outlined" sx={{ m: 2 }}>Back</Button>

                <Button type="submit" variant="contained"
                    sx={{ m: 2 }}>Next</Button>
            </form >


        </>
    )
}
export default Payment;
import React, { useState, useContext } from 'react'
import Container from '@mui/material/Container'
import { Stepper, Step, StepLabel, Card, Button } from '@mui/material';
import FormContext from '../../contexts/FormContext'

function AmsForm() {

    const { step, setStep, pageDisplay, titles } = useContext(FormContext)

    return (
        <div>
            <Container maxWidth="fluid" sx={{ p: 2, mb: 2 }}>
                <Card variant="outlined" sx={{ p: 1 }}>
                    <Stepper activeStep={step} alternativeLabel>
                        {titles.map((label) => (
                            <Step key={label}>
                                <StepLabel>{label}</StepLabel>
                            </Step>
                        ))}
                    </Stepper>
                </Card>

                <Card variant="outlined" sx={{ p: 4, pt: 2, m: 2 }}>

                    <div>
                        {pageDisplay(step)}
                    </div>


                </Card>
            </Container>

        </div>
    )
}

export default AmsForm
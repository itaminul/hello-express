import React from 'react'
import { FaCheckCircle } from 'react-icons/fa'
import { Link } from 'react-router-dom'
import '../styles/style.css'

function SuccessModal() {
    return (
        <div className='modal-background'>
            <div className='modal-container'>
                <div className='check-icon'>
                    < FaCheckCircle />
                </div>
                <div className='thank-you-message'>
                    Thank you
                </div>
                <div className='success-message'>
                    The form was submitted successfully
                </div>
                <div className='preview-button'>
                    <Link to="/preview"> See Preview </Link>
                </div>
            </div>
        </div>
    )
}

export default SuccessModal
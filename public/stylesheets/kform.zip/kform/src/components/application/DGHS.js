import React, { useContext, useState, useEffect } from 'react'
import Grid from '@mui/material/Grid'
import { Button, FormControl, FormControlLabel, FormLabel, InputLabel, MenuItem, Radio, RadioGroup, Select, TextField, Typography } from '@mui/material'
import FormContext from '../../contexts/FormContext';

const getInitialState = () => {
    const value = "Orange";
    return value;
  };
function DGHS() {
    const { onSubmit, quota, setQuota, values, handleInputChange } = useContext(FormContext)

    const [batch, setBatch] = useState([]);
    useEffect(() => {
        fetch("http://localhost:4004/api/batch/getAll")
        .then(response => response.json())
        .then(data => setBatch(data))
    }, [])

    function handlerBatch(e) {
        setBatch(e.target.value)
    }

    return (
        <>
            <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                Directorate General of Health Services (DGHS)
            </Typography>

            <form onSubmit={onSubmit}>
                <Grid container spacing={4}
                    justifyContent="center"
                    alignItems="flex-start">
                    <Grid item xs={12} md={6} >
                        <FormControl fullWidth sx={{ m: 1 }}>
                            <InputLabel>Batch No</InputLabel>
                            <Select
                                name="batchNo"
                                value={values.batchNo}
                                label="Batch No"
                                onChange={handleInputChange}
                            >
                                 {batch.map((batchValue) => (
                                <MenuItem value={batchValue.batchesId}>{batchValue.batchesNo}</MenuItem>
                                ))}
                            </Select>
                        </FormControl>

                        <FormControl sx={{ m: 1 }}>
                            <FormLabel >Applying For</FormLabel>
                            <RadioGroup
                                row
                                value={values.courseName}
                                name="courseName"
                                defaultValue="MBBS"
                                onChange={handleInputChange}
                            >
                                <FormControlLabel value="MBBS" control={<Radio />} label="MBBS" />
                                <FormControlLabel value="BDS" control={<Radio />} label="BDS" />
                            </RadioGroup>
                        </FormControl>


                        <TextField id="outlined-basic"
                            label="Roll No"
                            variant="outlined"
                            name='rollNo'
                            value={values.rollNo}
                            onChange={handleInputChange}
                            fullWidth
                            sx={{ m: 1 }}
                        // required
                        // {...register('rollNo')}
                        />

                        <TextField id="outlined-basic"
                            label="Test Score"
                            variant="outlined"
                            name='testScore'
                            value={values.testScore}
                            onChange={handleInputChange}
                            fullWidth
                            sx={{ m: 1 }}
                            type="number"
                        // required
                        // {...register('testScore')}
                        />


                        <TextField id="outlined-basic"
                            label="Merit Score"
                            variant="outlined"
                            fullWidth
                            name='meritScore'
                            value={values.meritScore}
                            onChange={handleInputChange}
                            sx={{ m: 1 }}
                            type="number"
                        // required
                        // {...register('meritScore')}
                        />

                    </Grid>

                    <Grid item xs={12} md={6} >

                        <FormControl fullWidth sx={{ m: 1 }}>
                            <InputLabel>Session</InputLabel>
                            <Select
                                name="session"
                                value={values.session}
                                label="Session"
                                onChange={handleInputChange}
                            >
                                <MenuItem value={"2021-22"}>2021-22</MenuItem>
                                <MenuItem value={"2022-23"}>2022-23</MenuItem>
                                <MenuItem value={"2023-24"}>2023-24</MenuItem>
                            </Select>
                        </FormControl>

                        <FormControl sx={{ m: 1 }}>
                            <FormLabel>Quota</FormLabel>
                            <RadioGroup
                                row
                                value={values.quota}
                                name="quota"
                                defaultValue="general"
                                onChange={handleInputChange}
                            >
                                <FormControlLabel value="general" control={<Radio />}
                                    label="General" onClick={() => setQuota("general")} />
                                <FormControlLabel value="freedom" control={<Radio />}
                                    label="Freedom Fighter" onClick={() => setQuota("freedom")} />
                                <FormControlLabel value="poor" control={<Radio />}
                                    label="Poor & Meritorious" onClick={() => setQuota("poor")} />
                            </RadioGroup>
                        </FormControl>


                        <TextField id="outlined-basic"
                            label="Merit Position"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            type="number"
                            name='meritPosition'
                            value={values.meritPosition}
                            onChange={handleInputChange}
                        // required
                        />

                        <TextField id="outlined-basic"
                            label="College Code"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='collegeCode'
                            value={values.collegeCode}
                            onChange={handleInputChange}
                        // required
                        // {...register('collegeCode')}
                        />

                        <TextField id="outlined-basic"
                            label="Serial Number"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            type="number"
                            name='serialNumber'
                            value={values.serialNumber}
                            onChange={handleInputChange}
                        // required
                        // {...register('serialNumber')}
                        />

                    </Grid>

                </Grid>

                {quota === "general" &&
                    <TextField
                        label="Sponsors' Annual Income (Amount)"
                        variant="outlined"
                        fullWidth
                        sx={{ m: 1 }}
                        type="number"
                        name='sponsorIncome'
                        value={values.sponsorIncome}
                        onChange={handleInputChange}
                    // required
                    // {...register('sponsorsIncome')}
                    />
                }

                {quota === "freedom" &&
                    <Grid container spacing={4}
                        justifyContent="center"
                        alignItems="flex-start">

                        <Grid item xs={12} md={6} >
                            <TextField id="outlined-basic"
                                label="Name of the Freedom Fighter"
                                variant="outlined"
                                fullWidth
                                sx={{ m: 1 }}
                                name='freedomFighterName'
                                value={values.freedomFighterName}
                                onChange={handleInputChange}
                            // required
                            // {...register('freedomFighterName')}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} >
                            <TextField id="outlined-basic"
                                label="Relationship with Applicant"
                                variant="outlined"
                                fullWidth
                                sx={{ m: 1 }}
                                name='freedomFighterRelation'
                                value={values.freedomFighterName}
                                onChange={handleInputChange}
                            // required
                            // {...register('freedomFighterRelation')}
                            />
                        </Grid>
                    </Grid>

                }

                {quota === "poor" &&
                    <Grid container spacing={4}
                        justifyContent="center"
                        alignItems="flex-start">

                        <Grid item xs={12} md={6} >
                            <TextField id="outlined-basic"
                                label="Sponsors' Annual Income (Amount)"
                                variant="outlined"
                                fullWidth
                                sx={{ m: 1 }}
                                type="number"
                                name='sponsorsIncome'
                                value={values.sponsorsIncome}
                                onChange={handleInputChange}
                            // required
                            // {...register('sponsorsIncome')}
                            />

                            <TextField id="outlined-basic"
                                label="Sponsors' Non Fixed Asset (Amount)"
                                variant="outlined"
                                fullWidth
                                sx={{ m: 1 }}
                                name='sponsorsNonFixedAsst'
                                value={values.sponsorsNonFixedAsst}
                                onChange={handleInputChange}
                            // required
                            // {...register('sponsorsNonFixedAsst')}
                            />
                        </Grid>

                        <Grid item xs={12} md={6} >
                            <TextField id="outlined-basic"
                                label="Sponsors' Fixed Asset (Amount)"
                                variant="outlined"
                                fullWidth
                                sx={{ m: 1 }}
                                type="number"
                                name='sponsorsFixedAsst'
                                value={values.sponsorsFixedAsst}
                                onChange={handleInputChange}
                            // required
                            // {...register('sponsorsFixedAsst')}
                            />
                        </Grid>
                    </Grid>
                }

                <Button type="submit" variant="contained"
                    sx={{ m: 2 }}>Next</Button>
            </form>
        </>
    )
}

export default DGHS
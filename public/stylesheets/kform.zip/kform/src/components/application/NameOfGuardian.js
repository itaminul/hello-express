import React, { useContext } from 'react'
import { Button, FormControl, Grid, InputLabel, MenuItem, Select, TextField, Typography } from '@mui/material'
import FormContext from '../../contexts/FormContext';

function NameOfGuardian() {

    const { onSubmit, onBack, values, handleInputChange } = useContext(FormContext)

    return (
        <>
            <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                Guardians' Information
            </Typography>
            <form onSubmit={onSubmit}>
                <Grid container spacing={4}
                    justifyContent="center"
                    alignItems="flex-start">

                    <Grid item xs={12} md={6} >
                        <TextField id="outlined-basic"
                            label="Local Guardian's Name"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='guardianName'
                            value={values.guardianName}
                            onChange={handleInputChange}
                        // required
                        // {...register('guardianName')}
                        />

                        <TextField id="outlined-basic"
                            label="Guardian's Mobile No."
                            variant="outlined"
                            fullWidth
                            type="number"
                            sx={{ m: 1 }}
                            name='guardianMobile'
                            value={values.guardianMobile}
                            onChange={handleInputChange}
                        // required
                        // {...register('guardianMobile')}
                        />

                        <TextField id="outlined-basic"
                            label="Guardian's Designation"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='guardianDesignation'
                            value={values.guardianDesignation}
                            onChange={handleInputChange}
                        // required
                        // {...register('guardianDesignation')}
                        />

                        <TextField id="outlined-basic"
                            label="Guardian's Postal Address"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='guardianAddress'
                            value={values.guardianAddress}
                            onChange={handleInputChange}
                        // required
                        // {...register('guardianAddress')}
                        />
                    </Grid>

                    <Grid item xs={12} md={6} >

                        <FormControl fullWidth sx={{ m: 1 }}>
                            <InputLabel>Guardian Relation</InputLabel>
                            <Select
                                name="guardianRelation"
                                value={values.guardianRelation}
                                label="Guardian Relation"
                                onChange={handleInputChange}
                            >
                                <MenuItem value={"Father"}>Father</MenuItem>
                                <MenuItem value={"Mother"}>Mother</MenuItem>
                                <MenuItem value={"Husband"}>Husband</MenuItem>
                                <MenuItem value={"Wife"}>Wife</MenuItem>
                                <MenuItem value={"Brother"}>Brother</MenuItem>
                                <MenuItem value={"Sister"}>Sister</MenuItem>
                                <MenuItem value={"Uncle"}>Uncle</MenuItem>
                                <MenuItem value={"Aunt"}>Aunt</MenuItem>
                                <MenuItem value={"Cousin"}>Cousin</MenuItem>
                                <MenuItem value={"Grandfather"}>Grandfather</MenuItem>
                                <MenuItem value={"Grandmother"}>Grandmother</MenuItem>

                            </Select>
                        </FormControl>

                        <TextField id="outlined-basic"
                            label="Guardian's Occupation"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='guardianOccupation'
                            value={values.guardianOccupation}
                            onChange={handleInputChange}
                        // required
                        // {...register('guardianOccupation')}
                        />

                        <TextField id="outlined-basic"
                            label="Guardian's Email Address"
                            variant="outlined"
                            fullWidth
                            type="email"
                            sx={{ m: 1 }}
                            name='guardianEmail'
                            value={values.guardianEmail}
                            onChange={handleInputChange}
                        // required
                        // {...register('guardianEmail')}
                        />

                        <TextField id="outlined-basic"
                            label="Guardian's Organization Address"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='guardianOrganizationAddress'
                            value={values.guardianOrganizationAddress}
                            onChange={handleInputChange}
                        // required
                        // {...register('guardianOrganizationAddress')}
                        />


                    </Grid>
                </Grid>


                <Button type='button' onClick={onBack}
                    variant="outlined" sx={{ m: 2 }}>Back</Button>

                <Button type="submit" variant="contained"
                    sx={{ m: 2 }}>Next</Button>
            </form>
        </>
    )
}

export default NameOfGuardian
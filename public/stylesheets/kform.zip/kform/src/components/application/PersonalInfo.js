import React, { useContext } from 'react'
import Grid from '@mui/material/Grid'
import {
    TextField, FormControl, InputLabel, Select,
    MenuItem, Button, Typography, Autocomplete
} from '@mui/material'
import FormContext from '../../contexts/FormContext';
import '../styles/style.css'

function PersonalInfo() {

    const { onSubmit, onBack, Districts, Nationalities, setValues, values,
        handleInputChange } = useContext(FormContext)

    return (
        <div>
            <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                Personal Info
            </Typography>

            <form onSubmit={onSubmit}>
                <Grid container spacing={4}
                    justifyContent="center"
                    alignItems="flex-start">
                    <Grid item xs={12} md={4} >

                        <TextField id="outlined-basic"
                            label="Full Name"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            placeholder="Full Name"
                            name='fullName'
                            value={values.fullName}
                            onChange={handleInputChange}
                        // required
                        // {...register('fullName')}
                        />

                        <FormControl fullWidth sx={{ m: 1 }}>
                            <InputLabel>Gender</InputLabel>
                            <Select
                                name="gender"
                                value={values.gender}
                                label="Gender"
                                onChange={handleInputChange}
                            >
                                <MenuItem value={"male"}>Male</MenuItem>
                                <MenuItem value={"female"}>Female</MenuItem>
                            </Select>
                        </FormControl>

                        <Autocomplete fullWidth sx={{ m: 1 }}
                            disablePortal
                            id="combo-box-demo"
                            options={Districts}
                            name='homeDistrict'
                            value={values.homeDistrict}

                            onChange={(e, value) =>
                                setValues({ ...values, homeDistrict: value })}
                            renderInput={(params) => <TextField {...params} label="Home District" />}
                        />

                        <TextField id="outlined-basic"
                            label="Mobile No "
                            type="number"
                            variant="outlined"
                            fullWidth
                            // required
                            placeholder='01XXXXXXXXX'
                            sx={{ m: 1 }}
                            name='mobileNo'
                            value={values.mobileNo}
                            onChange={handleInputChange}
                        // {...register('mobileNo')} 
                        />

                        <TextField id="outlined-basic"
                            label="Email "
                            variant="outlined"
                            fullWidth
                            type="email"
                            // required
                            placeholder='user@mydomain.com'
                            sx={{ m: 1 }}
                            // {...register('email')}
                            name='email'
                            value={values.email}
                            onChange={handleInputChange}
                        />

                    </Grid>


                    <Grid item xs={12} md={4}>

                        <TextField id="outlined-basic"
                            label="নাম (বাংলা)"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            placeholder=" বাংলা নাম "
                            // required
                            // {...register('banglaName')}
                            name='banglaName'
                            value={values.banglaName}
                            onChange={handleInputChange}
                        />

                        <FormControl fullWidth sx={{ m: 1 }}>
                            <InputLabel>Blood Group</InputLabel>
                            <Select
                                name="bloodGroup"
                                value={values.bloodGroup}
                                label="Blood Group"
                                onChange={handleInputChange}
                            >
                                <MenuItem value={"O+"}> O+ </MenuItem>
                                <MenuItem value={"A+"}> A+ </MenuItem>
                                <MenuItem value={"B+"}> B+ </MenuItem>
                                <MenuItem value={"AB+"}> AB+ </MenuItem>
                                <MenuItem value={"O-"}> O- </MenuItem>
                                <MenuItem value={"A-"}> A- </MenuItem>
                                <MenuItem value={"B-"}> B- </MenuItem>
                                <MenuItem value={"AB-"}> AB- </MenuItem>

                            </Select>
                        </FormControl>

                        <Autocomplete fullWidth sx={{ m: 1 }}
                            disablePortal
                            options={Nationalities}
                            name='nationality'
                            value={values.nationality}
                            onChange={(e, value) =>
                                setValues({ ...values, nationality: value })}
                            renderInput={(params) => <TextField {...params} label="Nationality" />}
                        />

                        <TextField
                            label="Passport No.(If Any)"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='passportNo'
                            value={values.passportNo}
                            onChange={handleInputChange}
                        // {...register('passportNo')}
                        />

                    </Grid>

                    <Grid item xs={12} md={4}>

                        <TextField
                            id="date"
                            label="Date of Birth"
                            type="date"
                            fullWidth
                            sx={{ m: 1 }}
                            InputLabelProps={{
                                shrink: true,
                            }}
                            name='dateOfBirth'
                            value={values.dateOfBirth}
                            onChange={handleInputChange}
                        // {...register('dateOfBirth')}
                        />


                        <FormControl fullWidth sx={{ m: 1 }}>
                            <InputLabel>Marital Status</InputLabel>
                            <Select
                                name="maritalStatus"
                                value={values.maritalStatus}
                                label="Marital Status"
                                onChange={handleInputChange}
                            >
                                <MenuItem value={"Married"}> Married </MenuItem>
                                <MenuItem value={"Unmarried"}> Unmarried </MenuItem>

                            </Select>
                        </FormControl>

                        <TextField id="outlined-basic"
                            label="Applicants' NID Number"
                            type="number"
                            variant="outlined"
                            fullWidth
                            // required
                            placeholder=''
                            sx={{ m: 1 }}
                            name='nidNo'
                            value={values.nidNo}
                            onChange={handleInputChange}
                        // {...register('nidNo')}
                        />

                        <TextField id="outlined-basic"
                            label="Applicants' Birth Reg Number"
                            type="number"
                            variant="outlined"
                            fullWidth
                            // required
                            placeholder=''
                            sx={{ m: 1 }}
                            name='birthRegNo'
                            value={values.birthRegNo}
                            onChange={handleInputChange}
                        // {...register('birthRegNo')}
                        />

                    </Grid>

                </Grid>

                <Button type='button' onClick={onBack}
                    variant="outlined" sx={{ m: 2 }}>Back</Button>

                <Button type="submit" variant="contained"
                    sx={{ m: 2 }}>Next</Button>

            </form>

        </div >

    )
}

export default PersonalInfo


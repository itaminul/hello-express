import React, { useContext, useEffect, useState } from 'react'
import { Button, FormHelperText, Grid, Input, InputAdornment, InputLabel, Typography } from '@mui/material'
import FormContext from '../../contexts/FormContext';
import '../styles/style.css'

function Photo() {

    const { onSubmit, onBack, quota, imgData, setImageData, handleImage } = useContext(FormContext)
    const [preview, setPreview] = useState({})

    // useEffect(() => {
    //     const reader = new FileReader();
    //     reader.onloadend = () => {
    //         setPreview(preview.passportImage = reader.result)
    //         console.log(preview);
    //     }
    //     if (imgData)
    //         reader.readAsDataURL(imgData.passportImage);
    // }, [imgData])

    return (
        <>
            <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                Photo and Signature Upload
            </Typography>
            <form onSubmit={onSubmit}>
                <Grid container spacing={4}
                    justifyContent="center"
                    alignItems="flex-start">

                    <Grid item xs={12} md={6} >

                        <InputLabel required sx={{ mt: 1 }}>Applicant Passport Size Image :</InputLabel>

                        <Input
                            startAdornment={<InputAdornment position="start"></InputAdornment>}

                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='passportImage'
                            onChange={e => handleImage(e)}
                        // value={imgData}
                        // onChange={(e) => setValues({ ...values, passportImage: e.target.files[0].name })}


                        // {...register('passportImage')}
                        />

                        {/* <div className='upload-image-container'>
                            <img src={preview.passportImage} />
                        </div> */}

                        <InputLabel required sx={{ mt: 1 }}>Applicant Signature :</InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start"></InputAdornment>}
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='applicantSign'
                            onChange={e => handleImage(e)}
                        // {...register('applicantSign')}
                        />

                        <InputLabel required sx={{ mt: 1 }}>Admission Test Admit Card :</InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start"></InputAdornment>}
                            type="file"
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            name='admissionAdmitCard'
                            onChange={e => handleImage(e)}
                        // {...register('admissionAdmitCart')}
                        />

                        <InputLabel required sx={{ mt: 1 }}>Admission Test Result Attachment :</InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start"></InputAdornment>}
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='admissionResult'
                            onChange={e => handleImage(e)}
                        // {...register('admissionTestResultAttachment')}
                        />

                        <InputLabel required sx={{ mt: 1 }}>Applicant NID Attachment :</InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start"></InputAdornment>}
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='applicantNID'
                            onChange={e => handleImage(e)}
                        // {...register('applicantNIDAttachment')}
                        />

                        <InputLabel required sx={{ mt: 1 }}>Applicant Birth Certificate Attachment :</InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start"></InputAdornment>}
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='applicantBirthCertificate'
                            onChange={e => handleImage(e)}
                        // {...register('applicantBirthCertificate')}
                        />

                        <InputLabel required sx={{ mt: 1 }}>Parent/Guardian Signature :</InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start"></InputAdornment>}
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='guardianSign'
                            onChange={e => handleImage(e)}
                        // {...register('guardianSign')}
                        />

                        {quota === "poor" &&
                            <>
                                <InputLabel required sx={{ mt: 1 }}>DGHS Filled up Bangla Form Attachment :</InputLabel>
                                <Input
                                    startAdornment={<InputAdornment position="start"></InputAdornment>}
                                    fullWidth sx={{ m: 1 }}
                                    accept="image/*"
                                    type="file"
                                    name='DGHSForm'
                                    onChange={e => handleImage(e)}
                                // {...register('DGHSForm')}
                                />
                            </>
                        }
                    </Grid>

                    <Grid item xs={12} md={6} >

                        <InputLabel required sx={{ mt: 1 }}> SSC / O Level Examination Certificate : </InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start">  </InputAdornment>}
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='SSCCertificate'
                            onChange={e => handleImage(e)}
                        // {...register('sscCertificate')}
                        />

                        <InputLabel required sx={{ mt: 1 }}> SSC / O Level Examination Transcript : </InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start">  </InputAdornment>}
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='SSCTranscript'
                            onChange={e => handleImage(e)}
                        // {...register('sscTranscript')}
                        />

                        <InputLabel required sx={{ mt: 1 }}> SSC / O Level Examination Testimonial : </InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start">  </InputAdornment>}
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='SSCTestimonial'
                            onChange={e => handleImage(e)}
                        // {...register('sscTestimonial')}
                        />

                        <InputLabel required sx={{ mt: 1 }}> HSC / A Level Examination Certificate : </InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start">  </InputAdornment>}
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='hscCertificate'
                            onChange={e => handleImage(e)}
                        // {...register('hscCertificate')}
                        />

                        <InputLabel required sx={{ mt: 1 }}> HSC / A Level Examination Transcript : </InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start">  </InputAdornment>}
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='hscTranscript'
                            onChange={e => handleImage(e)}
                        // {...register('hscTranscript')}
                        />

                        <InputLabel required sx={{ mt: 1 }}> HSC / A Level Examination Testimonial : </InputLabel>
                        <Input
                            startAdornment={<InputAdornment position="start">  </InputAdornment>}
                            fullWidth sx={{ m: 1 }}
                            accept="image/*"
                            type="file"
                            name='hscTestimonial'
                            onChange={e => handleImage(e)}
                        // {...register('hscTestimonial')}
                        />

                        {quota !== "poor" &&

                            <>
                                <InputLabel required sx={{ mt: 1 }}>Original Money Receipt of Application :</InputLabel>
                                <Input
                                    startAdornment={<InputAdornment position="start"></InputAdornment>}
                                    fullWidth sx={{ m: 1 }}
                                    accept="image/*"
                                    type="file"
                                    name='moneyReceipt'
                                    onChange={e => handleImage(e)}
                                // {...register('moneyReceipt')}
                                />
                            </>
                        }

                        {quota === "poor" &&
                            <>
                                <InputLabel required sx={{ mt: 1 }}>300 taka Non Judicial Stamp Attachment :</InputLabel>
                                <Input
                                    startAdornment={<InputAdornment position="start"></InputAdornment>}
                                    fullWidth sx={{ m: 1 }}
                                    accept="image/*"
                                    type="file"
                                    name='judicialAttachment'
                                    onChange={e => handleImage(e)}
                                // {...register('judicialAttachment')}
                                />

                                <InputLabel required sx={{ mt: 1 }}>Certificate of Insolvency Attachment :</InputLabel>
                                <Input
                                    startAdornment={<InputAdornment position="start"></InputAdornment>}
                                    fullWidth sx={{ m: 1 }}
                                    accept="image/*"
                                    type="file"
                                    name='insolvencyCertificate'
                                    onChange={e => handleImage(e)}
                                // {...register('insolvencyCertificate')}
                                />

                            </>
                        }


                    </Grid>

                </Grid>

                <Button type='button' onClick={onBack}
                    variant="outlined" sx={{ m: 2 }}>Back</Button>

                <Button type="submit" variant="contained"
                    sx={{ m: 2 }}>Next</Button>
            </form>
        </>
    )
}

export default Photo
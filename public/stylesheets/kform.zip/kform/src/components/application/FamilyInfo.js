import React, { useContext, useState } from 'react'
import Grid from '@mui/material/Grid'
import { TextField, FormControlLabel, Button, Typography, FormGroup, Checkbox } from '@mui/material'
import FormContext from '../../contexts/FormContext';

function FamilyInfo() {
    const { onSubmit, onBack, setValues, values, handleInputChange } = useContext(FormContext)

    // const { register, handleSubmit } = useForm({
    //     defaultValues: {
    //         ...fields
    //     }
    // });

    const [checked, setChecked] = useState(false);

    const handleChecked = () => {
        setChecked(!checked);
        console.log(checked);
        {
            checked ? setValues({ ...values, permanentAddress: "" }) :
                setValues({ ...values, permanentAddress: values.presentAddress })
        }

    }
    return (
        <>
            <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                Parents' Information
            </Typography>
            <form onSubmit={onSubmit}>

                <Grid container spacing={4}
                    justifyContent="center"
                    alignItems="flex-start">

                    <Grid item xs={12} md={6} >

                        <TextField id="outlined-basic"
                            label="Father's Name"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='fatherName'
                            value={values.fatherName}
                            onChange={handleInputChange}
                        // required
                        // {...register('fatherName')}
                        />

                        <TextField id="outlined-basic"
                            label="Father's Occupation"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='fatherOccupation'
                            value={values.fatherOccupation}
                            onChange={handleInputChange}
                        // required
                        // {...register('fatherOccupation')}
                        />

                        <TextField id="outlined-basic"
                            label="Father's Designation"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='fatherDesignation'
                            value={values.fatherDesignation}
                            onChange={handleInputChange}
                        // {...register('fatherDesignation')}
                        />

                        <TextField id="outlined-basic"
                            label="Father's Organization"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='fatherOrganization'
                            value={values.fatherOrganization}
                            onChange={handleInputChange}
                        // {...register('fatherOrganization')} 
                        />

                        <TextField id="outlined-basic"
                            label="Father's Mobile No"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            type="number"
                            name='fatherMobileNo'
                            value={values.fatherMobileNo}
                            onChange={handleInputChange}
                        // required
                        // {...register('fatherMobile')}
                        />

                        <TextField id="outlined-basic"
                            label="Father's Email Address"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='fatherEmail'
                            value={values.fatherEmail}
                            onChange={handleInputChange}
                        // {...register('fatherEmail')}
                        />

                        <TextField id="outlined-basic"
                            label="Present Mailing Address"
                            variant="outlined"
                            fullWidth
                            multiline rows={3}
                            sx={{ m: 1 }}
                            name='presentAddress'
                            value={values.presentAddress}
                            onChange={handleInputChange}
                        // // required
                        // {...register('presentAddress')}
                        />

                        {/* <div className='container'>
                            <input type="checkbox" name="sameAddress" value="sameAddress" {...register('sameAddress')} onChange={handleChecked} />
                            <label for="sameAddress"> Both Adresses are same</label>
                        </div> */}

                        <FormGroup sx={{ m: 1 }}>
                            <FormControlLabel control={<Checkbox checked={checked} />} label="Both Are Same Adresses"
                                onClick={handleChecked} />
                        </FormGroup>


                    </Grid>

                    <Grid item xs={12} md={6} >

                        <TextField id="outlined-basic"
                            label="Mother's Name"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='motherName'
                            value={values.motherName}
                            onChange={handleInputChange}
                        // required
                        // {...register('motherName')}
                        />

                        <TextField id="outlined-basic"
                            label="Mother's Occupation (If Any)"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='motherOccupation'
                            value={values.motherOccupation}
                            onChange={handleInputChange}
                        // required
                        // {...register('motherOccupation')} 
                        />

                        <TextField id="outlined-basic"
                            label="Mother's Designation (If Any)"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='motherDesignation'
                            value={values.motherDesignation}
                            onChange={handleInputChange}
                        // {...register('motherDesignation')}
                        />

                        <TextField id="outlined-basic"
                            label="Mother's Organization (If Any)"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='motherOrganization'
                            value={values.motherOrganization}
                            onChange={handleInputChange}
                        // {...register('motherOrganization')}
                        />

                        <TextField id="outlined-basic"
                            label="Mother's Mobile No"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            type="number"
                            name='motherMobile'
                            value={values.motherMobile}
                            onChange={handleInputChange}
                        // {...register('motherOrganizat
                        // required
                        // {...register('motherMobile')}
                        />

                        <TextField id="outlined-basic"
                            label="Mother's Email Address (If Any)"
                            variant="outlined"
                            fullWidth
                            sx={{ m: 1 }}
                            name='motherEmail'
                            value={values.motherEmail}
                            onChange={handleInputChange}
                        // {...register('motherEmail')}
                        />


                        <TextField id="outlined-basic"
                            label="Permanent Address"
                            variant="outlined"
                            fullWidth
                            multiline rows={3}
                            sx={{ m: 1 }}
                            name='permanentAddress'
                            value={values.permanentAddress}
                            onChange={handleInputChange}
                            disabled={checked ? true : false}
                        // required
                        // {...register('permanentAddress')}
                        />
                    </Grid>

                </Grid>
                <Button type='button' onClick={onBack}
                    variant="outlined" sx={{ m: 2 }}>Back</Button>

                <Button type="submit" variant="contained"
                    sx={{ m: 2 }}>Next</Button>
            </form>
        </>
    )
}

export default FamilyInfo
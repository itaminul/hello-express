import ApplicationForm from "./pages/ApplicationForm";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import PreviewPage from "./pages/PreviewPage";
import { FormProvider } from "./contexts/FormContext";
import SuccessModal from "./components/application/SuccessModal";


function App() {
  return (
    <>
      <FormProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<ApplicationForm />}></Route>
            <Route path="/preview" element={<PreviewPage />}></Route>
            <Route path="/test" element={<SuccessModal />}></Route>

          </Routes>
        </BrowserRouter>
      </FormProvider>
    </>
  );
}

export default App;

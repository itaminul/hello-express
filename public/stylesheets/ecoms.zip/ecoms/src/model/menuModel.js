const mongoose = require('mongoose')
const menuSchama = new mongoose.Schema({
    menuName: {
        type: String,
        required: [true, 'Menu name must be full fill']
    },
    menuType: {
        type: Number,
        ref: "Like Top, Left, Right menu etc"
    },
    menuPosition: {
        type: Number
    },
    activeStatus: {
        type: Number,
        default: 1
    },
    orgId: {
        type: Number
    },
    companyId: {
        type: Number
    },
    entryDate: {
        type: Date,
        default: Date.now
    },
    entryBy: {
        type: Number
    }
})
module.exports = mongoose.model('Menu', menuSchama)
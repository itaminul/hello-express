const mongoose = require("mongoose");
const categorySchema = new mongoose.Schema({
  categoryId: {
    type: Number,
    required: true,
    unique: true,
  },
  menuId: {
    type: Number,
    unique: true,
  },
  categoryType: {
    type: Number,
  },
  categoryName: {
    type: String,
    required: true,
  },
  categoryDescription: {
    type: String,
  },
  categoryImage: {
    type: String,
  },
  orgId: {
    type: Number,
    default: 1,
  },
  companyId: {
    type: Number,
    default: 1,
  },
  categorySlNo: {
    type: Number,
  },
  activeStatus: {
    type: Number,
    default: 1,
  },
  createDate: {
    type: Date,
    default: Date.now,
  },
  createdBy: {
    type: Number,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
  updatedBy: {
    type: Number,
  },
});
module.exports = mongoose.model("Categories", categorySchema);

const mongoose = require("mongoose");
const productData = new mongoose.Schema({
  productId: {
    type: Number,
    required: true,
    unique: true,
  },
  categoryId: {
    type: Number,
    required: true,
  },
  subCategoryId: {
    type: Number,
  },
  categoryNameId: {
    type: Number,
    required: true,
  },
  productName: {
    type: String,
    required: true,
  },
  productDescription: {
    type: String,
  },
  image: {
    // data: Buffer,
    // contentType: String,
    type: String,
  },
  latestProduct: {
    type: Number,
    // default: 0,
  },
  productShow: {
    type: Number,
    // default: 1,
  },
  offer: {
    type: String,
  },
  specialDiscount: {
    type: String,
  },
  productSlNo: {
    type: Number,
  },
  productPrice: {
    type: String,
  },
  currentPrice: {
    type: String,
  },
  priceAfterOffer: {
    type: String,
  },
  activeStatus: {
    type: Number,
    // default: 1,
  },
  maufacturerBy: {
    type: Number
  },
  warenty: {
    type: String
  },
  orgId: {
    type: Number,
    // default: 1,
  },
  createDate: {
    type: Date,
    default: Date.now,
  },
  createdBy: {
    type: Number,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
  updatedBy: {
    type: Number,
  },
});
module.exports = mongoose.model("Products", productData);

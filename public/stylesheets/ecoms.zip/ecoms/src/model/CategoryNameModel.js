const mongoose = require('mongoose')
const CategoryNameAssignSechema = mongoose.Schema({
    categoryNameId: {
        type: Number,
        required: true,
    },
    categoryId: {
        type: Number,
        required: true,
    },
    subCategoryId: {
        type: Number
    },
    categoryName: {
        type: String,
        required: true,
    },
    description: {
        type: String,
    },
    categoryNameSl: {
      type: Number,
    },
    activeStatus:{
        type: Number,
        default: 1
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    createdBy: {
        type: Number,
    },
    updatedDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
    }
})

module.exports = mongoose.model('CategoryNameAssign', CategoryNameAssignSechema)
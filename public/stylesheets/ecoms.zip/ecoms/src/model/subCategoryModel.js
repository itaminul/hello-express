const mongoose = require("mongoose");
const subCategorySchema = new mongoose.Schema({
  subCateId: {
    type: Number,
    unique: true,
  },
  categoryId: {
    type: Number,
  },
  subCategoryName: {
    type: String,
    required: true,
  },
  subCategoryDescription: {
    type: String,
  },
  subcategoryStaus: {
    type: Number,
    default: 0,
  },
  orgId: {
    type: Number,
    default: 1,
  },
  companyId: {
    type: Number,
    default: 1,
  },
  categorySlNo: {
    type: Number,
  },
  activeStatus: {
    type: Number,
    default: 1,
  },
  createDate: {
    type: Date,
    default: Date.now,
  },
  createdBy: {
    type: Number,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
  updatedBy: {
    type: Number,
  },
});

module.exports = mongoose.model("Subcategories", subCategorySchema);

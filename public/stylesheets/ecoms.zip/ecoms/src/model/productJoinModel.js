const mongoose = require("mongoose");
Schema = mongoose.Schema;

const ProductsData = new mongoose.Schema({
  categoryId: Number,
});
const CategorysData = new mongoose.Schema({
  categoryId: Number,
});

const Categorys = new mongoose.model("categorys", CategorysData);
module.exports = { Productsall, Categorys };

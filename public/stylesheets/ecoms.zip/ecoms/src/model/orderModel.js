const mongoose = require('mongoose')
const order = new mongoose.Schema({
    productId: {
        type: Number,
        required: true
    },
    userId: {
        type: Number
    },
    orderQuantity: {
        type: Number
    },
    price: {
        type: String
    },
    orderShipedLocation: {
        type: String
    },
    orderStatus: {
        type: Number,
        default: 0
    },
    deliveryStatus: {
        type: Number,
        default: 0
    },
    activeStatus: {
        type: Number,
        default: 1
    },
    createdy: {
        type: Number
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    updatedBy: {
        type: Number,
        
    },
    updatedDate: {
        type: Date,
        default: Date.now
    }

})

module.exports = mongoose.model('Order', order);

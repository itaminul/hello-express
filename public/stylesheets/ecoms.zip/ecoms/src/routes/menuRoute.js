const express = require('express')
const router = express.Router()
const menuController = require('../controller/menuController')
router.get('/getAll', menuController.getAll)
router.post('/create', menuController.createMeun)
router.patch('update/:id', menuController.updateMenu)
router.delete('delete/:id', menuController.deleteMenu)
// console.log('route');
module.exports = router;

const express = require('express')
const router = express.Router()
const orderController = require("../controller/orderController")
const { route } = require('./userRoute')
// console.log('order route');
router.get('/getAll',orderController.getAll)
router.post('/create',orderController.create)
router.patch('/update/:id', orderController.update)
router.delete('/delete/:id', orderController.delete)
module.exports = router;
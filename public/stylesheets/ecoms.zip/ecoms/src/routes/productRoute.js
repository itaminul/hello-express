const express = require("express");
const router = express.Router();
const multer = require("multer");
const mongoose = require("mongoose");
const productController = require("../controller/productController");
router.get("/getAll", productController.getAll);
router.get("/getProdDetails", productController.getProductDetailsInformation);
router.get("/getProdDetailsByCategory/:id", productController.getProductDetailsInformationByCategory);
router.get("/productSearch/:keywords", productController.productSearch);
// router.post("/create", productController.create);
router.patch("/update/:id", productController.update);
router.delete("/delete/:id", productController.delete);

const DIR = "./public/";

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, DIR);
  },
  filename: (req, file, cb) => {
    const fileName = file.originalname.toLowerCase().split(" ").join("-");
    cb(null, +"-" + fileName);
  },
});

var upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype == "image/png" ||
      file.mimetype == "image/jpg" ||
      file.mimetype == "image/jpeg"
    ) {
      cb(null, true);
    } else {
      cb(null, false);
      return cb(new Error("Only .png, .jpg and .jpeg format allowed!"));
    }
  },
});

// User model
const productModel = require("../model/productModel");

router.post("/create", upload.single("image"), async (req, res, next) => {
  const url = req.protocol + "://" + req.get("host");

  if (
    !req.body.productId ||
    !req.body.categoryId ||
    !req.body.categoryNameId ||
    !req.body.productName
  ) {
    return res.status(422).json({
      error: "please filled properly",
    });
  }

  try {
    const idExist = await productModel.findOne({
      productId: req.body.productId,
    });
    if (idExist) {
      return res.status(409).json({ error: "productID already Exist" });
    } else {
      const result = new productModel({
        productId: req.body.productId,
        categoryId: req.body.categoryId,
        subCategoryId: req.body.subCategoryId,
        categoryNameId: req.body.categoryNameId,
        productName: req.body.productName,
        productDescription: req.body.productDescription,
        image: url + "/public/" + req.file.filename,
        latestProduct: req.body.latestProduct,
        productShow: req.body.productShow,
        offer: req.body.offer,
        specialDiscount: req.body.specialDiscount,
        productSlNo: req.body.productSlNo,
        productPrice: req.body.productPrice,
        currentPrice: req.body.currentPrice,
        priceAfterOffer: req.body.priceAfterOffer,
        activeStatus: req.body.activeStatus,
        maufacturerBy:req.body.maufacturerBy,
        warenty:req.body.warenty
      });
      console.log(result);
      await result.save();
      res.status(201).json({ message: "successful" });
    }
  } catch (error) {}
});

module.exports = router;

const express = require("express");
const router = express.Router();
const subCategoryController = require("../controller/subCategoryController");
router.get("/getAll", subCategoryController.getAll);
router.post("/create", subCategoryController.create);
router.patch("/update/:id", subCategoryController.update);
router.delete("/delete/:id", subCategoryController.delete);
module.exports = router;

const express = require("express");
const router = express.Router();
const multer = require("multer");
const mongoose = require("mongoose");
const categoryController = require("../controller/categoryController");
router.get("/getAll", categoryController.getAll);
router.get("/getCateSub", categoryController.getAllCategorySubcategory);
// router.post('/create', categoryController.create)
router.patch("/update/:id", categoryController.update);
router.delete("/delete/:id", categoryController.delete);

const DIR = "./public/";

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, DIR);
  },
  filename: (req, file, cb) => {
    const fileName = file.originalname.toLowerCase().split(" ").join("-");
    cb(null, +"-" + fileName);
  },
});

var upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype == "image/png" ||
      file.mimetype == "image/jpg" ||
      file.mimetype == "image/jpeg"
    ) {
      cb(null, true);
    } else {
      cb(null, false);
      return cb(new Error("Only .png, .jpg and .jpeg format allowed!"));
    }
  },
});

// User model
const categoryModel = require("../model/categoryModel");

router.post(
  "/create",
  upload.single("categoryImage"),
  async (req, res, next) => {
    const url = req.protocol + "://" + req.get("host");

    if (!req.body.categoryName) {
      return res.status(422).json({ error: "please filled properly" });
    }

    try {
      const idIsExist = await categoryModel.findOne({
        categoryId: req.body.categoryId,
      });
      const idExist = await categoryModel.findOne({ menuId: req.body.menuId });
      if (idIsExist) {
        return res.status(409).json({ error: "CategoryId already Exist" });
      } else if (idExist) {
        return res.status(408).json({ error: "menuId already Exist" });
      } else {
        const result = new categoryModel({
          categoryId: req.body.categoryId,
          menuId: req.body.menuId,
          categoryType: req.body.categoryType,
          categoryName: req.body.categoryName,
          categoryDescription: req.body.categoryDescription,
          categoryImage: url + "/public/" + req.file.filename,
          categorySlNo: req.body.categorySlNo,
          activeStatus: req.body.activeStatus,
        });
        await result.save();
        res.status(201).json({ message: "successful" });
      }
    } catch (error) {}
  }
);
module.exports = router;

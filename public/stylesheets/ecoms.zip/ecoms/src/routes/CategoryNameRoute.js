const express = require('express')
const router = express.Router()
const categoryNameController = require('../controller/CategoryNameController')
router.get('/getAll',categoryNameController.getAll)
router.post('/create',categoryNameController.create)
router.patch('/update/:id',categoryNameController.update)
router.delete('/delete/:id',categoryNameController.delete)
module.exports = router


const mongoose = require("mongoose");
const productModel = require("../model/productModel");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
//https://studio3t.com/knowledge-base/articles/mongodb-aggregation-framework/
//https://www.mongodb.com/community/forums/t/mongodb-filter-an-array-by-id-using-aggregate/114182
//https://thecodebarbarian.com/a-nodejs-perspective-on-mongodb-36-lookup-expr

exports.getProductDetailsInformation = (req, res) => {
  productModel
    .aggregate([
      {
        $lookup: {
          from: "categories",
          localField: "categoryId",
          foreignField: "categoryId",
          as: "categoryDetails",
        },
      },
      {
        $unwind: "$categoryDetails",
      },
      {
        $lookup: {
          from: "subcategories",
          localField: "subCategoryId",
          foreignField: "subCateId",
          as: "subCategoryDetails",
        },
      },
      {
        $unwind: "$subCategoryDetails",
      },
    ])
    .then((result) => {
      // console.log(result);
      res.send(result);
    })
    .catch((error) => {
      console.log(error);
    });
};


exports.getProductDetailsInformationByCategory = (req, res) => {
    const catId = req.params;
    const catIds = Number(catId.id);
  productModel
    .aggregate([
      { $match: {	"categoryId": { $in: [ catIds ] }}},      
      {
        $lookup: {
          from: "categories",
          localField: "categoryId",
          foreignField: "categoryId",
          as: "categoryDetails",
        },
      },
      {
        $unwind: "$categoryDetails",
       },
      { $project : { _id : 0, productName:1, productDescription:1, productPrice:1,currentPrice:1,priceAfterOffer:1,image:1,latestProduct:1,productShow:1,offer:1,specialDiscount:1, 'categoryDetails.categoryId' : 1, 'categoryDetails.categoryName' : 1 } },
    ])
    .then((result) => {
      // console.log(result);
      res.send(result);
    })
    .catch((error) => {
      console.log(error);
    });
};


exports.getAll = async (req, res) => {
  try {
    const products = await productModel.find();
    res.json(products);
  } catch (error) {
    res.status(400).json({
      status: "fail",
      message: error,
    });
  }
};
//SET STORAGE
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads");
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + "-" + Date.now());
  },
});
var upload = multer({ storage: storage });

//image upload by url

exports.create = async (req, res) => {
  const product = req.body;

  if (
    !product.productId ||
    !product.categoryId ||
    !product.categoryNameId ||
    !product.productName
  ) {
    return res.status(422).json({
      error: "please filled properly",
    });
  }

  try {
    const idExist = await productModel.findOne({
      productId: product.productId,
    });
    if (idExist) {
      return res.status(409).json({ error: "productID already Exist" });
    } else {
      const result = new productModel(product);
      await result.save();
      res.status(201).json({ message: "successful" });
    }
  } catch (error) {}
};


exports.productSearch = async(req, res) => {
  const search = req.params.keywords;
  productModel
    .aggregate([
      {
        "$match": {
            "productName": { "$regex": search, "$options": "i" }  
        }
      },
      // {
      //   $match: {
      //     "productName": {
      //       $regex : new RegExp(search, "i")
      //       // $regex: "search"
      //     }
      //   }
      // },
      // { $match: {	"productName": { $in: [ search ] }}},      
      {
        $lookup: {
          from: "categories",
          localField: "categoryId",
          foreignField: "categoryId",
          as: "categoryDetails",
        },
      },
      {
        $unwind: "$categoryDetails",
       },
      { $project : { _id : 0, productName:1, productDescription:1, productPrice:1,currentPrice:1,priceAfterOffer:1,image:1,latestProduct:1,productShow:1,offer:1,specialDiscount:1, 'categoryDetails.categoryId' : 1, 'categoryDetails.categoryName' : 1 } },
    ])
    .then((result) => {
      // console.log(result);
      res.send(result);
    })
    .catch((error) => {
      console.log(error);
    });

  // const search = req.params.keywords;
  // productModel.find( { "productName" : { $regex : new RegExp(search, "i") } },
  // function(err, data) {
  //   res.send(data)
  // }
  // ).select('productName'); 
}


//image upload by binary data in mongodb

// exports.create = async (req, res) => {
//   // console.log("body", req.body);
//   // console.log("files", req.files);
//   const productId = req.body.productId;
//   const categoryId = req.body.categoryId;
//   const subCategoryId = req.body.subCategoryId;
//   const categoryNameId = req.body.categoryNameId;
//   const productName = req.body.productName;
//   const productDescription = req.body.productDescription;
//   const pic = req.files.image;
//   const picData = pic.data;
//   const encodedPic = picData.toString("base64");
//   const imageBuffer = Buffer.from(encodedPic, "base64");
//   const latestProduct = req.body.latestProduct;
//   const productShow = req.body.productShow;
//   const offer = req.body.offer;
//   const specialDiscount = req.body.specialDiscount;
//   const productSlNo = req.body.productSlNo;
//   const activeStatus = req.body.activeStatus;
//   const orgId = req.body.orgId;
//   const createdBy = req.body.createdBy;
//   const updatedBy = req.body.updatedBy;

//   const product = {
//     productId,
//     categoryId,
//     subCategoryId,
//     categoryNameId,
//     productName,
//     productDescription,
//     image: imageBuffer,
//     latestProduct,
//     productShow,
//     offer,
//     specialDiscount,
//     productSlNo,
//     activeStatus,
//     orgId,
//     createdBy,
//     updatedBy,
//   };
//   console.log(product);
//   // const result = await doctorsCollection.insertOne(doctor);
//   // const result = new productModel({ product });
//   // console.log(result);

//   // const user = new usersModel({ name, phone, email, password });
//   //     await user.save();

//   if (!productId || !categoryId || !categoryNameId || !productName) {
//     return res.status(422).json({ error: "please filled properly" });
//   }

//   // try {
//   //   const userExist = await usersModel.findOne({ email: email });

//   //   if (userExist) {
//   //     return res.status(409).json({ error: "Email already Exist" });
//   //   } else {
//   //     const user = new usersModel({ name, phone, email, password });
//   //     await user.save();
//   //     res.status(201).json({ message: "successful" });
//   //   }

//   try {
//     const idExist = await productModel.findOne({ productId: productId });
//     if (idExist) {
//       return res.status(409).json({ error: "productID already Exist" });
//     } else {
//       const result = new productModel(product);
//       await result.save();
//       res.status(201).json({ message: "successful" });
//     }
//     // const result = new productModel(product);
//     // await result.save();
//     // res.status(201).json({ message: "successful" });

//     // const result = new productModel(product);
//     // await result.save();
//     // res.json(result);
//   } catch (error) {}
//   // await result.save();
// };

// (exports.create = upload.single("img")),
//   async (req, res) => {
//     const url = req.protocol + "://" + hostname + req.body.path;

//     const productData = new productModel({
//       productId: req.body.productId,
//       categoryId: req.body.categoryId,
//       subCategoryId: req.body.subCategoryId,
//       categoryNameId: req.body.categoryNameId,
//       productName: req.body.productName,
//       productDescription: req.body.productDescription,
//       img: url + "imgs/" + req.body.path,
//       offer: req.body.offer,
//       specialDiscount: req.body.specialDiscount,
//       productSlNo: req.body.productSlNo,
//     });
//     // console.log(productData);
//     try {
//       await productData.save();
//       res.status(200).json({ message: "Save Successfully" });
//     } catch (error) {
//       res.status(500).json({ error: "An error occured" });
//     }
//   };

exports.update = async (req, res) => {
  console.log("update");
};
exports.delete = async (req, res) => {
  console.log("delete");
};


const { Schema, default: mongoose } = require("mongoose");
const subCategoryModel = require("../model/subCategoryModel");
exports.getAll = async (req, res) => {
  try {
    const subCategoryData = await subCategoryModel.find();
    res.json(subCategoryData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.create = async (req, res) => {
  const subCategoryData = new subCategoryModel({
    subCateId: req.body.subCateId,
    categoryId: req.body.categoryId,
    subCategoryName: req.body.subCategoryName,
    subCategoryDescription: req.body.subCategoryDescription,
    subcategoryStaus: req.body.subcategoryStaus,
    orgId: req.body.orgId,
    categorySlNo: req.body.categorySlNo,
    activeStatus: req.body.activeStatus,
    createDate: req.body.createDate,
    createdBy: req.body.createdBy,
    updatedDate: req.body.updatedDate,
    updatedBy: req.body.updatedBy,
  });
  console.log(subCategoryData);
  try {
    await subCategoryData.save();
    res.status(200).json({ message: "Save successfully" });
  } catch (error) {
    res.status(500).json({ error: "An error occured" });
  }
};

exports.update = async (req, res) => {
  try {
    const subCategoryVaueById = await subCategoryModel.findByIdAndUpdate(
      { _id: req.params.id },
      {
        subCateId: req.body.subCateId,
        categoryId: req.body.categoryId,
        subCategoryName: req.body.subCategoryName,
        subCategoryDescription: req.body.subCategoryDescription,
        orgId: req.body.orgId,
        categorySlNo: req.body.categorySlNo,
        activeStatus: req.body.activeStatus,
        createDate: req.body.createDate,
        createdBy: req.body.createdBy,
        updatedDate: req.body.updatedDate,
        updatedBy: req.body.updatedBy,
      }
    );
    res.status(200).json({ message: "Update Successfully" });
  } catch (error) {
    res.status(500).json({ error: "An error occured" });
  }
};

exports.delete = async (req, res) => {
  try {
    const subCateDataById = await subCategoryModel.findByIdAndRemove({
      _id: req.params.id,
    });
    res.status(200).json({ message: "Delete Successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

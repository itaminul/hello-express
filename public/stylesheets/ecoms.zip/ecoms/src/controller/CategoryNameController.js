const mongoose = require("mongoose");
const categoryName = require("../model/CategoryNameModel");
exports.getAll = async (req, res) => {
  try {
    const saveData = await categoryName.find();
    res.json(saveData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.create = async (req, res) => {
  const categoryNameData = new categoryName({
    categoryNameId: req.body.categoryNameId,
    categoryId: req.body.categoryId,
    subCategoryId: req.body.subCategoryId,
    categoryName: req.body.categoryName,
    description: req.body.description,
    categoryNameSl: req.body.categoryNameSl,
    activeStatus: req.body.activeStatus,
    orgId: req.body.orgId,
  });
  console.log(categoryNameData);
  try {
    await categoryNameData.save();
    res.status(200).json({ message: "Data save successfully" });
  } catch (error) {
    res.status(500).json({ error: "And error occured" });
  }
};
exports.update = async (req, res) => {
  try {
    const update = await categoryName.findByIdAndUpdate(
      { _id: req.params.id },
      {
        categoryNameId: req.body.categoryNameId,
        categoryId: req.body.categoryId,
        subCategoryId: req.body.subCategoryId,
        categoryName: req.body.categoryName,
        description: req.body.description,
        categoryNameSl: req.body.categoryNameSl,
        activeStatus: req.body.activeStatus,
        orgId: req.body.orgId,
      }
    );
    res.status(200).json({ message: "Update successfully" });
  } catch (error) {
    res.status(500).json({ error: "An error occured" });
  }
};
exports.delete = async (req, res) => {
  try {
    await categoryName.findByIdAndRemove({ _id: req.params.id });
    res.status(200).json({ message: "Delete successfully" });
  } catch (error) {
    res.status(500).json({ error: "An error occured" });
  }
};


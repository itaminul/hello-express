const mongoose = require("mongoose");
const { findByIdAndRemove } = require("../model/orderModel");
console.log('Order name controller')
const orderModel = require('../model/orderModel');

exports.getAll = async (req, res) => {
        try {
            const result = await orderModel.find();
            res.json(result);
        } catch (error) {
           res.status(500).json({error: 'An error occured'})           
        }

}
exports.create = async (req, res) => {
    const orderData = new orderModel({
        productId: req.body.productId,
        userId: req.body.userId,
        orderQuantity: req.body.orderQuantity,
        price: req.body.price,
        orderShipedLocation: req.body.orderShipedLocation,
        orderStatus: req.body.orderStatus,
        deliveryStatus: req.body.deliveryStatus,
        createdy: req.body.createdy
    })
        try {
            await orderData.save();
            res.status(200).json({message: 'Data save successfully'})
        } catch (error) {
           res.status(500).json({error: 'An error occured'})           
        }

}

exports.update = async (req, res) => {
    try {
        const upDate = await orderModel.findByIdAndUpdate(
            {_id: req.params.id},
            {
                productId: req.body.productId,
                userId: req.body.userId,
                orderQuantity: req.body.orderQuantity,
                price: req.body.price,
                orderShipedLocation: req.body.orderShipedLocation,
                orderStatus: req.body.orderStatus,
                deliveryStatus: req.body.deliveryStatus,
                createdy: req.body.createdy
            }
        )
        res.status(200).json({message: 'Update Successfully'})
    } catch (error) {
        res.status(500).json({error: 'An error occured'})
        
    }
}

exports.delete = async(req, res) => {
    try {
        const orderDelete = await orderModel.findByIdAndRemove(
            {_id: req.params.id},

        )
        res.status(200).json({message: 'Data delete successfully'})
    } catch (error) {
        res.status(500).json({error: 'An Errord occured'})
        
    }
}
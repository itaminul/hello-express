const { json } = require("express/lib/response");
const categoryModel = require("../model/categoryModel");
const { param } = require("../routes/userRoute");

exports.getAll = async (req, res) => {
  try {
    const categoryData = await categoryModel.find();
    res.json(categoryData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//image upload by url

exports.create = async (req, res) => {
  const category = req.body;
  console.log(category);

  if (!category.categoryName) {
    return res.status(422).json({ error: "please filled properly" });
  }

  try {
    const idIsExist = await categoryModel.findOne({ menuId: category.menuId });
    if (idIsExist) {
      return res.status(409).json({ error: "menuId already Exist" });
    } else {
      const result = new categoryModel(category);
      await result.save();
      // console.log(result);
      res.status(201).json({ message: "successful" });
    }
  } catch (error) {}
};

//image upload by binary data in mongodb

// exports.create = async (req, res) => {
//   const categoryId = req.body.categoryId;
//   const menuId = req.body.menuId;
//   const categoryType = req.body.categoryType;
//   const categoryName = req.body.categoryName;
//   const categoryDescription = req.body.categoryDescription;
//   const pic = req.files.image;
//   const picData = pic.data;
//   const encodedPic = picData.toString("base64");
//   const imageBuffer = Buffer.from(encodedPic, "base64");
//   const orgId = req.body.orgId;
//   const companyId = req.body.companyId;
//   const categorySlNo = req.body.categorySlNo;
//   const activeStatus = req.body.activeStatus;
//   const createdBy = req.body.createdBy;
//   const updatedBy = req.body.updatedBy;

//   const categorie = {
//     categoryId,
//     menuId,
//     categoryType,
//     categoryName,
//     categoryDescription,
//     categoryImage: imageBuffer,
//     orgId,
//     companyId,
//     categorySlNo,
//     activeStatus,
//     createdBy,
//     updatedBy,
//   };
//   console.log(categorie);

//   if (!categoryName) {
//     return res.status(422).json({ error: "please filled properly" });
//   }

//   try {
//     const idIsExist = await categoryModel.findOne({ menuId: menuId });
//     if (idIsExist) {
//       return res.status(409).json({ error: "menuId already Exist" });
//     } else {
//       const result = new categoryModel(categorie);
//       await result.save();
//       // console.log(result);
//       res.status(201).json({ message: "successful" });
//     }
//   } catch (error) {}
// };

// exports.create = async (req, res) => {
//   const categoryData = new categoryModel({
//     menuId: req.body.menuId,
//     categoryName: req.body.categoryName,
//     categoryDescription: req.body.categoryDescription,
//     categorySlNo: req.body.categorySlNo,
//     categoryType: req.body.categoryType,
//   });
//   try {
//     await categoryData.save();
//     res.status(200).json({ message: "Save succfully" });
//   } catch (error) {
//     res.status(500).json({ error: "and error occured" });
//   }
// };

exports.update = async (req, res) => {
  try {
    const categoryData = await categoryModel.findOneAndUpdate(
      { _id: req.params.id },
      {
        menuId: req.body.menuId,
        categoryName: req.body.categoryName,
        categoryDescription: req.body.categoryDescription,
        categorySlNo: req.body.categorySlNo,
        categoryType: req.body.categoryType,
      }
    );
    res.status(200).json({ message: "update successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
exports.delete = async (req, res) => {
  try {
    const categoryData = await categoryModel.findByIdAndRemove({
      _id: req.params.id,
    });
    res.status(200).json({ message: "Delete successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getAllCategorySubcategory = async (req, res) => {
  categoryModel
    .aggregate([
      {
        $lookup: {
          from: "subcategories",
          localField: "categoryId",
          foreignField: "categoryId",
          as: "SubcategoryMenu",
        },
      },
    ])
    .then((result) => {
      // console.log(result);
      res.send(result);
    })
    .catch((error) => {
      console.log(error);
    });
};

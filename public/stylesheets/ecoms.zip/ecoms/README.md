npm i express-fileupload
e-commmerce server

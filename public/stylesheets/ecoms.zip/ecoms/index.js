const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
require("dotenv").config();
const cors = require("cors");
// import jsonwebtoken

const PORT = process.env.PORT || 4002;

const app = express();
app.use(cors());

mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("DB successfully connected new!");
  })
  .catch((err) => {
    console.error("Connection error", err);
  });

const jwt = require("jsonwebtoken");

jsonwebtoken = require("jsonwebtoken");

const userRoutes = require("./src/routes/userRoute");
const users = require("./src/routes/userRoute");
const menuRoutes = require("./src/routes/menuRoute");
const categoryRoutes = require("./src/routes/categoryRoute");
const subCategoryRoute = require("./src/routes/subCategoryRoute");
const categoryNameRoute = require("./src/routes/CategoryNameRoute");
const productRouter = require("./src/routes/productRoute");
const orderRouter = require("./src/routes/orderRoute");
const fileUpload = require("express-fileupload");

const { default: helmet } = require("helmet");
// const PORT = 4002;

app.use("/api/products", productRouter);
// app.use("/api/menu", menuRoutes);
app.use("/api/category", categoryRoutes);

// app.use("/api/categoryname", categoryNameRoute);
// app.use("/api/products", productRouter);
// app.use("/api/order", orderRouter);
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: false,
  })
);

app.use("/public", express.static("public"));

app.use(helmet());
app.use(fileUpload());

// DB connection
//mongodb+srv://<username>:<password>@invdb.odnqz.mongodb.net/?retryWrites=true&w=majority
//mongodb+srv://<username>:<password>@invdb.odnqz.mongodb.net/test
//mongodb://localhost:27017/inv_ecommerce
//mongodb+srv://invdb:invdb@invdb.odnqz.mongodb.net/?retryWrites=true&w=majority/inv_ecommerce

// mongoose.connect(`mongodb+srv://invdb:invdb@invdb.odnqz.mongodb.net/inv_ecommerce`)
// .then((_) => {
//   console.log('DB successfully connected!');
// })
// .catch((err) => {
//   console.error(err);
// });

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get("/test", function () {
  console.log("test");
});

app.get("/", (req, res) => {
  res.send("Hello World! ttt");
});

// Token Verification
app.use((req, res, next) => {
  if (
    req.headers &&
    req.headers.authorization &&
    req.headers.authorization.split(" ")[0] === "JWT"
  ) {
    jwt.verify(
      req.headers.authorization.split(" ")[1],
      "RESTfulAPIs",
      (err, decode) => {
        if (err) req.user = undefined;
        req.user = decode;
        next();
      }
    );
  } else {
    req.user = undefined;
    next();
  }
});

app.use("/api/auth", users);
app.use("/api/auth", userRoutes);
app.use("/api/menu", menuRoutes);
// app.use("/api/category", categoryRoutes);
app.use("/api/subCategory", subCategoryRoute);
app.use("/api/categoryname", categoryNameRoute);
// // app.use("/api/products", productRouter);
app.use("/api/order", orderRouter);
app.get("/ping", (req, res) => {
  return res.send({
    error: false,
    message: "Server is healthy",
  });
});
app.listen(PORT, () => {
  console.log(`serve running ${PORT}`);
});

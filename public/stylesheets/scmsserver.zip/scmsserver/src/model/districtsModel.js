const mongoose = require('mongoose')
const DistrictsSchema = new mongoose.Schema({
  districtId: {
    type: Number
  },
  districts: {
    type: String
  },
  districtsDescription: {
    type: String,
  },
  orgId: {
    type: Number,
    default: 1,
  },
  companyId: {
    type: Number,
    default: 1,
  },
  activeStatus: {
    type: Number,
    default: 1,
  },
  createDate: {
    type: Date,
    default: Date.now,
  },
  createdBy: {
    type: Number,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
  updatedBy: {
    type: Number,
  }
})
module.exports = mongoose.model('Districts', DistrictsSchema)
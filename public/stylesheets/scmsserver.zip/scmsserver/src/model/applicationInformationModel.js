const mongoose = require('mongoose')
const applicationInfo = new mongoose.Schema({
    applicationId: {
        type: Number,
        required: true
    },
    batchId: {
        type: Number,
    },
    sessionId: {
        type: Number
    },
    applicatonType: {
        type: Number
    },
    quata: {
        type: Number
    },
    freedomFighterName: {
        type: String
    },
    relationWithAppli: {
        type: String
    },
    sponsorsAnnualIncome: {
        type: Number
    },
    sponserFixedAsset: {
        type: Number
    },
    sponsorNonFixedAsset: {
        type: Number
    },
    rollNumber: {
        type: Number
    },
    testSchore: {
        type: String
    },
    meritSchore: {
        type: Number
    },
    merintPosition: {
        type: Number
    },
    collegeCode: {
        type: String
    },
    serialNumber: {
        type: Number
    },
    annualIncome: {
        type: Number
    },
    fullName: {
        type: String
    },
    fullNameBangla: {
        type: String
    },
    dateOfBirth: {
        type: Date
    },
    gender: {
        type: Number
    },
    bloodGroupId: {
        type: Number
    },
    maritialStatus: {
        type: Number
    },
    districtId: {
        type: Number
    },
    nationalityId: {
        type: Number
    },
    nidNumber: {
        type: Number
    },
    mobileNumber: {
        type: Number
    },
    passportNo: {
        type: String
    },
    appliBirthRegNumber: {
        type: String
    },
    email: {
        type: String
    },
    fathersName: {
        type: String
    },
    fathOccupation: {
        type: String
    },
    fathDesignation: {
        type: String
    },
    fathOrganization: {
        type: String
    },
    fathMobileNumber: {
        type: Number
    },
    fathEmail: {
        type: String
    },
    presentMailingAddress: {
        type: String
    },
    mothersName: {
        type: String
    },
    mothersOccupation: {
        type: String
    },
    mothersOrganization: {
        type: String
    },
    motherDesignation: {
        type: String
    },
    mothersMobileNumber: {
        type: Number
    },
    mothersEmail: {
        type: String
    },
    parmanentAddress: {
        type: String
    },
    localGuarName: {
        type: String
    },
    localGuarMobile: {
        type: Number
    },
    localGuarDesignation: {
        type: String
    },
    localGuarOrgName: {
        type: String
    },
    localGuarAddress: {
        type: String
    },
    localGuarRelation: {
        type: String
    },
    localGuarOccu: {
        type: String
    },
    localGuarEmail: {
        type: String
    },
    localGuarOrgAddress: {
        type: String
    },
    mediumEdu: {
        type: Number
    },
    referenceOne: {
        type: String
    },
    referenceTwo: {
        type: String
    },
    transationId: {
        type: String
    },
    moneySenderMob: {
        type: String
    },
    applicantImage: {
        type: String
    },
    applicantSignature: {
        type: String
    },
    admissionTestAdmit: {
        type: String
    },
    admissionTestResult: {
        type: String
    },
    applicationNid: {
        type: String
    },
    applicationBirtCerti: {
        type: String
    },
    parentSign: {
        type: String
    },
    sscOLavExamCerti: {
        type: String
    },
    sscOLavExamTran: {
        type: String
    },
    sscOLavExamTesti: {
        type: String
    },
    hscALavExamCerti: {
        type: String
    },
    hscALavExamTran: {
        type: String
    },
    hscALavExamTesti: {
        type: String
    },
    moneyReceipt: {
        type: String
    },
    judicialAttachment: {
        type: String
    },
    insolvencyCertificate: {
        type: String
    },
    DGHSForm: {
        type: String
    },
    appliPaymentStatus: {
      type: Number,
      default: 1
    },
    appliConfirmStatus: {
        type: Number,
        default: 1
    },
    remarksAfterPayment:{
        type: String,
    },
    remarksAfterApproved:{
        type: String,
    },
    orgId: {
      type: Number,
      default: 1,
    },
    companyId: {
      type: Number,
      default: 1,
    },
    activeStatus: {
      type: Number,
      default: 1,
    },
    createDate: {
      type: Date,
      default: Date.now,
    },
    createdBy: {
      type: Number,
    },
    updatedDate: {
      type: Date,
      default: Date.now,
    },
    updatedBy: {
      type: Number,
    }
})

module.exports = mongoose.model('Applications', applicationInfo)
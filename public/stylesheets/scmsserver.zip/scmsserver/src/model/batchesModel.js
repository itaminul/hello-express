const mongoose = require("mongoose");
const BatchSchema = new mongoose.Schema({
  batchId: {
    type: Number,
    required: true,
    unique: true
  },
  batchesNo: {
    type: String,
    unique: true,
  },
  batchDescription: {
    type: String,
  },
  orgId: {
    type: Number,
    default: 1,
  },
  companyId: {
    type: Number,
    default: 1,
  },
  activeStatus: {
    type: Number,
    default: 1,
  },
  createDate: {
    type: Date,
    default: Date.now,
  },
  createdBy: {
    type: Number,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
  updatedBy: {
    type: Number,
  },
});
module.exports = mongoose.model("Batches", BatchSchema);

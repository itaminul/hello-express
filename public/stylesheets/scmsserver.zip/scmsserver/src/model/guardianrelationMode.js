const mongoose = require('mongoose')
const GuardianRelationSchema = new mongoose.Schema({
    guardianrelationId: {
        type: Number
    },
    guardianRelation: {
        type: String
    },
  orgId: {
    type: Number,
    default: 1,
  },
  companyId: {
    type: Number,
    default: 1,
  },
  activeStatus: {
    type: Number,
    default: 1,
  },
  createDate: {
    type: Date,
    default: Date.now,
  },
  createdBy: {
    type: Number,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
  updatedBy: {
    type: Number,
  }
})
module.exports= mongoose.model('GuardianRelations', GuardianRelationSchema)
//28746
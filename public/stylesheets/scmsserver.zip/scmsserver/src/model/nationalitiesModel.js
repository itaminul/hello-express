const mongoose = require('mongoose')
const NationalitesSchema = new mongoose.Schema({
  nationalityId: {
    type: Number,
    required: true,
    unique: true
  },
  nationality: {
    type: String,
    unique: true,
  },
  nationalityDescription: {
    type: String,
  },
  orgId: {
    type: Number,
    default: 1,
  },
  companyId: {
    type: Number,
    default: 1,
  },
  activeStatus: {
    type: Number,
    default: 1,
  },
  createDate: {
    type: Date,
    default: Date.now,
  },
  createdBy: {
    type: Number,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
  updatedBy: {
    type: Number,
  }
})
module.exports = mongoose.model('Nationalites', NationalitesSchema)
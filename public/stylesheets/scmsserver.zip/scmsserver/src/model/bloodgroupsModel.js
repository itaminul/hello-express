const mongoose = require('mongoose')
const BloodgroupsSchema = new mongoose.Schema({
  bloodgroupId: {
    type: Number,
    required: true,
    unique: true
  },
  bloodgroup: {
    type: String,
    unique: true,
  },
  bloodgroupDescription: {
    type: String,
  },
  orgId: {
    type: Number,
    default: 1,
  },
  companyId: {
    type: Number,
    default: 1,
  },
  activeStatus: {
    type: Number,
    default: 1
  },
  createDate: {
    type: Date,
    default: Date.now,
  },
  createdBy: {
    type: Number,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
  updatedBy: {
    type: Number,
  }
})
module.exports = mongoose.model('Bloodgroups', BloodgroupsSchema)
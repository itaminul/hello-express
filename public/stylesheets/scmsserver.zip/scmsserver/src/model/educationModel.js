const mongoose = require('mongoose')
const educationInfo = new mongoose.Schema({
    applicantId: {
        type: String
    },
    mediumEducation: {
        type: Number
    },
    ssc: {
        type: String
    },
    sscInstitute: {
        type: String
    },
    sscBoard: {
        type: String
    },
    sscSession: {
        type: String
    },
    sscPassingYear: {
        type: String
    },
    sscScienceSubject: {
        type: String
    },
    sscTotalGradGPA: {
        type: String
    },
    sscGradPoinInBiology: {
        type: String
    },
    hsc: {
        type: String
    },
    hscInstitute: {
        type: String
    },
    hscBoard: {
        type: String
    },
    hscSession: {
        type: String
    },
    hscPassingYear: {
        type: String
    },
    hscScienceSubject: {
        type: String
    },
    hscTotalGradGPA: {
        type: String
    },
    hscGradPoinInBiology: {
        type: String
    },
    orgId: {
      type: Number,
      default: 1,
    },
    companyId: {
      type: Number,
      default: 1,
    },
    activeStatus: {
      type: Number,
      default: 1,
    },
    createDate: {
      type: Date,
      default: Date.now,
    },
    createdBy: {
      type: Number,
    },
    updatedDate: {
      type: Date,
      default: Date.now,
    },
    updatedBy: {
      type: Number,
    }
})

module.exports = mongoose.model('Educations', educationInfo)
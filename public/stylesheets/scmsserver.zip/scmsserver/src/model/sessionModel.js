const mongoose = require('mongoose')
const SessionSchema = new mongoose.Schema({
  sessionId: {
    type: Number,
    required: true,
    unique: true
  },
  session: {
    type: String,
    unique: true,
  },
  sessionDescription: {
    type: String,
  },
  orgId: {
    type: Number,
    default: 1,
  },
  companyId: {
    type: Number,
    default: 1,
  },
  activeStatus: {
    type: Number,
    default: 1,
  },
  createDate: {
    type: Date,
    default: Date.now,
  },
  createdBy: {
    type: Number,
  },
  updatedDate: {
    type: Date,
    default: Date.now,
  },
  updatedBy: {
    type: Number,
  }
})
module.exports = mongoose.model('Sessions', SessionSchema)
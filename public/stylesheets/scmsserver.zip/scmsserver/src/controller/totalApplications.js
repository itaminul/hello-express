const applicatonModel = require('../model/applicationInformationModel')

exports.getAll = async(req, res) => {
    try {
        const totalAppli = await applicatonModel.find({"appliPaymentStatus": { $in: 2}}).select("_id applicationId applicatonType fullName appliPaymentStatus collegeCode serialNumber rollNumber meritSchore merintPosition mobileNumber moneyReceipt moneySenderMob appliConfirmStatus").sort({ _id: -1})
        res.send(totalAppli);        
    } catch (error) {
        res.send(error)
        
    }
}
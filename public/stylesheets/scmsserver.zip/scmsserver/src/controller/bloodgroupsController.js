const BloodGroups = require('../model/bloodgroupsModel')
exports.getAll = async(req, res) => {
    try {
        const bloodGroupData = await BloodGroups.find().select('bloodgroupId bloodgroup activeStatus')
        res.send(bloodGroupData)        
    } catch (error) {
        res.send(error)
        
    }
}
exports.create = async(req, res) => {
    try {
        const bloodGroups  = await BloodGroups.create(req.body)
        res.send(bloodGroups)   
    } catch (error) {    
        res.send('not right')
    }
}
exports.update = async(req, res) => {
    try {  
        const id = req.params.id;
        const updateData = req.body;
        const options = { new: true}
        const result = await BloodGroups.findByIdAndUpdate(
            id, updateData, options
        )
        res.send(result)        
    } catch (error) {
        res.send(error)        
    }
}
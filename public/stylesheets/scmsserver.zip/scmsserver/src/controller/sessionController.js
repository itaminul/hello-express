const Session = require('../model/sessionModel')
exports.getAll = async(req, res) => {
    try {
        const sessions = await Session.find();
        res.send(sessions)
    } catch (error) {
        res.status(500).json({ message: error.message });
        
    }
}

exports.create = async(req, res) => {
    try {
        const session  = await Session.create(req.body)
        res.send(session)        
    } catch (error) {
        res.send(error)        
    }
}

exports.update = async(req, res) => {
    try {
        Session.findOneAndUpdate({
            _id:req.params.id
        },
        req.body,
        function(err, session){
            res.send(session)
        }
        )
    } catch (error) {
        
    }

}
exports.getMaxId = (req, res) => {
    Session.findOne().sort('-sessionId').exec(function(err, sess){
    res.json(sess.sessionId+1)
  })  
}


const applicationInformationModel = require ('../model/applicationInformationModel')
const educationInfo = require('../model/educationModel')
const multer = require('multer')

exports.getAll = async(req, res) => {    
    try {
        const data = await applicationInformationModel.find()
        res.send(data)     
        
    } catch (error) {
        res.send(error)        
    }
}

exports.getApprovedApplication = async(req, res) => {
    try {
        const data = await applicationInformationModel.find({"appliConfirmStatus": {$in:2}}).select("_id applicationId applicatonType fullName appliPaymentStatus collegeCode serialNumber rollNumber meritSchore merintPosition mobileNumber moneyReceipt moneySenderMob appliConfirmStatus remarksAfterApproved").sort({ _id: -1})
        res.send(data)
    } catch (error) {
        res.send(error)        
    }
}

exports.canceledApplication = async(req, res) => {
    try {
        const data = await applicationInformationModel.find({"appliConfirmStatus": {$in:4}}).select("_id applicationId applicatonType fullName appliPaymentStatus collegeCode serialNumber rollNumber meritSchore merintPosition mobileNumber moneyReceipt moneySenderMob appliConfirmStatus remarksAfterApproved").sort({ _id: -1})
        res.send(data)
    } catch (error) {
        res.send(error)        
    }
}


exports.create = async(req, res, file) => {   

    const url = '';

    let applicantInfo = new applicationInformationModel({
        applicationId: req.body.applicationId,
        batchId: req.body.batchId,
        sessionId: req.body.sessionId,
        applicatonType: req.body.applicatonType,
        quata: req.body.quata,
        freedomFighterName: req.body.freedomFighterName,
        relationWithAppli: req.body.relationWithAppli,
        sponsorsAnnualIncome: req.body.sponsorsAnnualIncome,
        sponserFixedAsset: req.body.sponserFixedAsset,
        sponsorNonFixedAsset: req.body.sponsorNonFixedAsset,
        rollNumber: req.body.rollNumber,
        testSchore: req.body.testSchore,
        meritSchore: req.body.meritSchore,
        merintPosition: req.body.merintPosition,
        collegeCode: req.body.collegeCode,
        serialNumber: req.body.serialNumber,
        annualIncome: req.body.annualIncome,
        fullName: req.body.fullName,
        fullNameBangla: req.body.fullNameBangla,
        dateOfBirth: req.body.dateOfBirth,
        gender: req.body.gender,
        bloodGroupId: req.body.bloodGroupId,
        maritialStatus: req.body.maritialStatus,
        districtId: req.body.districtId,
        nationalityId: req.body.nationalityId,
        nidNumber: req.body.nidNumber,
        mobileNumber: req.body.mobileNumber,
        passportNo: req.body.passportNo,
        appliBirthRegNumber: req.body.appliBirthRegNumber,
        email: req.body.email,
        fathersName: req.body.fathersName,
        fathOccupation: req.body.fathOccupation,
        fathDesignation: req.body.fathDesignation,
        fathOrganization: req.body.fathOrganization,
        fathMobileNumber: req.body.fathMobileNumber,
        fathEmail: req.body.fathEmail,
        presentMailingAddress: req.body.presentMailingAddress,
        mothersName: req.body.mothersName,
        mothersOccupation: req.body.mothersOccupation,
        mothersOrganization: req.body.mothersOrganization,
        motherDesignation: req.body.motherDesignation,
        mothersMobileNumber: req.body.mothersMobileNumber,
        mothersEmail: req.body.mothersEmail,
        parmanentAddress: req.body.parmanentAddress,
        localGuarName: req.body.localGuarName,
        localGuarMobile: req.body.localGuarMobile,
        localGuarOrgName: req.body.localGuarOrgName,
        localGuarDesignation: req.body.localGuarDesignation,
        localGuarAddress: req.body.localGuarAddress,
        localGuarRelation: req.body.localGuarRelation,
        localGuarOccu: req.body.localGuarOccu,
        localGuarEmail: req.body.localGuarEmail,
        localGuarOrgAddress: req.body.localGuarOrgAddress,
        mediumEdu: req.body.mediumEdu,
        referenceOne: req.body.referenceOne,
        referenceTwo: req.body.referenceTwo,
        moneySenderMob: req.body.moneySenderMob,
        applicantImage: req.body.applicantImage,
        applicantSignature: req.body.applicantSignature,
        admissionTestAdmit: req.body.admissionTestAdmit,
        admissionTestResult: req.body.admissionTestResult,
        applicationNid: req.body.applicationNid,
        applicationBirtCerti: req.body.applicationBirtCerti,
        parentSign: req.body.parentSign,        

        sscOLavExamCerti: req.files.sscOLavExamCerti[0].path,
        sscOLavExamTran:  req.files.sscOLavExamTran[0].path,
        sscOLavExamTesti: req.files.sscOLavExamTesti[0].path,
        hscALavExamCerti: req.files.hscALavExamCerti[0].path,
        hscALavExamTran: req.files.hscALavExamTran[0].path,
        hscALavExamTesti: req.files.hscALavExamTesti[0].path,
        judicialAttachment: req.files.judicialAttachment[0].path,
        insolvencyCertificate: req.files.insolvencyCertificate[0].path,
        DGHSForm: req.body.DGHSForm,
        appliPaymentStatus: req.body.appliPaymentStatus,
        appliConfirmStatus: req.body.appliConfirmStatus,
        remarksAfterApproved: req.body.remarksAfterApproved      

    })

    let ssceduInfo = new educationInfo({
        applicantId: req.body.applicantId,
        mediumEducation: req.body.mediumEducation,
        ssc: req.body.ssc,
        sscInstitute: req.body.sscInstitute,
        sscBoard: req.body.sscBoard,
        sscSession: req.body.sscSession,
        sscPassingYear: req.body.sscPassingYear,
        sscScienceSubject: req.body.sscScienceSubject,
        sscTotalGradGPA: req.body.sscTotalGradGPA,
        sscGradPoinInBiology: req.body.sscGradPoinInBiology,
        orgId: req.body.orgId,
        companyId: req.body.companyId    

    })
    let hsceduInfo = new educationInfo({
        applicantId: req.body.applicantId,
        hsc: req.body.hsc,
        hscInstitute: req.body.hscInstitute,
        hscBoard: req.body.hscBoard,
        hscSession: req.body.hscSession,
        hscPassingYear: req.body.hscPassingYear,
        hscScienceSubject: req.body.hscScienceSubject,
        hscTotalGradGPA: req.body.hscTotalGradGPA,
        hscGradPoinInBiology: req.body.hscGradPoinInBiology,
        orgId: req.body.orgId,
        companyId: req.body.companyId 
    })

    try {
       const infos = await applicantInfo.save();
       const ssceduInfos = await ssceduInfo.save()
       const hsceduInfos = await hsceduInfo.save()
        res.send('success');
        
    } catch (error) {
        res.send(error)
        
    }

}

exports.maxid = async(req, res) => {    
    applicationInformationModel.findOne().sort('-applicationId').exec(function(err, item) {
        // item.itemId is the max value
            // console.log(item.batchId+1)
            res.json(item.applicationId+1)

    });

   applicationInformationModel.find().select('applicationId').sort('-applicationId').limit(1).exec((err, val) => {
        // item.itemId is the max value
        if(err) {
    
        }else{
           // res.send(val);
    
        }
        // let maxI = item.applicantId;
        //return json(maxI+1);
        
    });

}
// exports.createMultiple = async(req, res) => {
//     const body = req.body;
//     console.log(body);
  
//     let items = req.body.map(item => {
//       return {
//         orderid: item.id,
//         ordername: item.name,
//         orderdescription: item.description,
//         orderquantity: item.quantity,
//         ordertotalprice: item.totalPrice
//       };
//     });
  
//     Orders.insertMany(items)
//       .then(() => {
//         console.log("Orders Added!");
//         res.status(200).json("Order Added!");
//       })
//       .catch(err => res.status(400).json("Error: " + err));
//   };


const DistrictsModel = require('../model/districtsModel')

exports.getAll = async(req, res) => {
    try {
        const getALlData= await DistrictsModel.find()
        res.send(getALlData)        
    } catch (error) {
        res.send(error)        
    }
}
exports.create = async(req, res) => {
    try {
        console.log('access in the try')
        console.log(req.body)
        const disdata  = await DistrictsModel.create(req.body)
        //res.send("request received");
       // next(); // this will give you the above exception 
        res.send(disdata)        
        return
        // res.status(200).json({message: 'success'})
    } catch (error) {
        res.send(error)        
    }
}
exports.update = async(req, res) => {
    try {
        DistrictsModel.findOneAndUpdate({
            _id:req.params.id
        },
        req.body,
        function(err, distict){
            res.send(distict)
        }
        )
    } catch (error) {
        
    }

}

exports.getMaxDistrictId = (req, res) => {
        DistrictsModel.findOne().sort('-districtId').exec(function(err, item) {
            res.json(item.districtId+1)

    });
}

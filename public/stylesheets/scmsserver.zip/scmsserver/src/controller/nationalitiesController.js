const { findOne } = require('../model/nationalitiesModel')
const Nationalities = require('../model/nationalitiesModel')

exports.getAll = async(req, res) => {
    try {
        const nations = await Nationalities.find()
        res.send(nations)        
    } catch (error) {
        res.send(error)        
    }
}

exports.create = async(req, res) => {
    try {
        const nationalityData  = await Nationalities.create(req.body)
        res.send(nationalityData)        
    } catch (error) {
        res.send(error)        
    }
}

exports.update = async(req, res) => {
    try {
        Nationalities.findOneAndUpdate({
            _id: req.params.id
        },
        req.body,{new: true},
        function(err, nation){
            res.send(nation)
        }
        )    
    } catch (error) {
        res.send(error)        
    }
}

exports.getMaxId = (req, res) => {
    Nationalities.findOne().sort('-nationalityId').exec(function(error, nation) {
        res.json(nation.nationalityId+1)
     })
}

const applicationModel = require('../model/applicationInformationModel')

exports.getAll = async(req, res) => {
    try {
        const paymentVer = await applicationModel.find().select("_id applicationId applicatonType fullName appliPaymentStatus collegeCode serialNumber rollNumber meritSchore merintPosition mobileNumber moneyReceipt moneySenderMob appliPaymentStatus remarksAfterPayment").sort({ _id: -1});
        res.send(paymentVer)
    } catch (error) {
        res.send(error)
        
    }
}
exports.update = async(req, res) => {
    try {
        const id = req.params.id;
        const updateData = req.body;
        const options = { new: true}
        const result = await applicationModel.findByIdAndUpdate(
            id, updateData, options
        )
        res.send(result)
        
    } catch (error) {
        res.send(error)
        
    }

}
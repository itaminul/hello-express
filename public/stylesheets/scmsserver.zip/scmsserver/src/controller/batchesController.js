const { json } = require("express/lib/response");
const Batches = require("../model/batchesModel");

exports.getAll = async (req, res) => {
  try {
    const categoryData = await Batches.find();
    res.json(categoryData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.create = async (req, res) => {

  try {
    console.log('access in the try')
    console.log(req.body)
    const disdata  = await Batches.create(req.body)
    //res.send("request received");
   // next(); // this will give you the above exception 
    res.send(disdata)        
    return
    // res.status(200).json({message: 'success'})
} catch (error) {
    res.send(error)        
}

};

exports.update = async (req, res) => {
  try {
    const categoryData = await Batches.findOneAndUpdate(
      { _id: req.params.id },
      {       
        batchesNo: req.body.batchesNo,
        batchDescription: req.body.batchDescription,
        activeStatus: req.body.activeStatus
      }
    );
    res.status(200).json({ message: "update successfully" });
    return
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.delete = async (req, res) => {
  try {
    const categoryData = await Batches.findByIdAndRemove({
      _id: req.params.id,
    });
    res.status(200).json({ message: "Delete successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.maxBatchId = async(req, res) => {
    Batches.findOne().sort('-batchId').exec(function(err, batch){
    res.json(batch.batchId+1)
  })  
}

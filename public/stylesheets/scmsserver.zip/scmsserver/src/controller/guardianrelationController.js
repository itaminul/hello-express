const GuardianRelation = require('../model/guardianrelationMode')

exports.create = async(req, res) => {
    try {
        const guardianData = await GuardianRelation.create(req.body)
        res.send(guardianData)
    } catch (error) {
        res.send(error)
        
    }
}
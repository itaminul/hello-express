const express = require('express')
const router = express.Router()
const GuardianRelationController = require('../controller/guardianrelationController')
router.post('/create', GuardianRelationController.create)
module.exports= router
const experss = require('express')
const router = experss.Router() 
const path = require('path');
const {v4 : uuidv4} = require('uuid')
const fs = require('fs'); // Added to create directories
var multer = require('multer');
const applicationController = require('../controller/applicationInformationController')

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
     fs.mkdir('./uploads/application',(err)=>{
        cb(null, './uploads/application');
     });
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname+"-"+uuidv4()+path.extname(file.originalname));
  }
})
var upload = multer({ storage: storage});
router.get('/getAll', applicationController.getAll)
router.get('/getApprovedApplication', applicationController.getApprovedApplication)
router.get('/getCanceledApplication', applicationController.canceledApplication)
// router.post('/create', upload.single('file'), applicationController.create)
router.post('/create', 
upload.fields([
  { name: "sscOLavExamCerti", maxCount: 10 },
  { name: "sscOLavExamTran", maxCount: 10 },
  { name: "sscOLavExamTesti", maxCount: 10},
  { name: "hscALavExamCerti", maxCount: 10},
  { name: "hscALavExamTran", maxCount: 10},
  { name: "hscALavExamTesti", maxCount: 10},
  { name: "judicialAttachment", maxCount: 10},
  { name: "insolvencyCertificate", maxCount: 10}
]),
 applicationController.create)
router.get('/maxid', applicationController.maxid)
module.exports = router

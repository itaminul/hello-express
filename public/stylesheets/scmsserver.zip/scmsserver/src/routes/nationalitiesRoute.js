const experss = require('express')
const router = experss.Router();
const NationalityCOntroller = require('../controller/nationalitiesController')
router.get('/getAll', NationalityCOntroller.getAll)
router.get('/maxId', NationalityCOntroller.getMaxId)
router.post('/create', NationalityCOntroller.create)
router.patch('/update/:id', NationalityCOntroller.update)
module.exports = router;
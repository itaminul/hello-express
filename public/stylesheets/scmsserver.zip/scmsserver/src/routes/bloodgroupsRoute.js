const experss = require('express')
const router = experss.Router();
const BloodgroupsController = require('../controller/bloodgroupsController')
router.get('/getAll', BloodgroupsController.getAll )
router.post('/create', BloodgroupsController.create)
router.patch('/update/:id', BloodgroupsController.update)
module.exports = router;
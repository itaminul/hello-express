const experss = require('express')
const router = experss.Router();
const Districtsntroller = require('../controller/districtsController')
router.get('/getAll', Districtsntroller.getAll)
router.post('/create', Districtsntroller.create)
router.get('/maxId', Districtsntroller.getMaxDistrictId)
router.patch('/update/:id', Districtsntroller.update)
module.exports = router;
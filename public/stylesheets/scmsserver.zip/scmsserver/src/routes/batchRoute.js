const express = require('express')
const router = express.Router();
const batchController = require('../controller/batchesController')
router.get('/getAll',batchController.getAll)
router.post('/create', batchController.create)
router.get('/maxId', batchController.maxBatchId)
router.patch('/update/:id', batchController.update)
router.delete('/delete/:id', batchController.delete)
module.exports = router;
const express = require('express')
const router = express.Router()
const verifyPaymentController = require('../controller/verifyPaymentController')
router.get('/getAll', verifyPaymentController.getAll)
router.patch('/update/:id', verifyPaymentController.update)
module.exports = router
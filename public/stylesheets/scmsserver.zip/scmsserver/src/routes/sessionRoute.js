const experss = require('express')
const router = experss.Router();
const SessionCOntroller = require('../controller/sessionController')
router.get('/getAll', SessionCOntroller.getAll)
router.get('/maxId', SessionCOntroller.getMaxId)
router.post('/create', SessionCOntroller.create)
router.patch('/update/:id', SessionCOntroller.update)
module.exports = router;
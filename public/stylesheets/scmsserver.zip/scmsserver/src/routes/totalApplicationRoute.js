const express = require('express')
const router = express.Router()
const totalApplications = require('../controller/totalApplications')
router.get('/getAll', totalApplications.getAll )
module.exports= router
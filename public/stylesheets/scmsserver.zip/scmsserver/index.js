const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
require("dotenv").config();
const cors = require("cors");
// import jsonwebtoken

const jwt = require("jsonwebtoken");

jsonwebtoken = require("jsonwebtoken");


const batchRoutes = require("./src/routes/batchRoute");
const sessionRoute = require("./src/routes/sessionRoute")
const bloodgroupRoute = require('./src/routes/bloodgroupsRoute')
const guardianRelationRoute = require('./src/routes/guardianrelationRoute')
const nationalitiesRotes = require('./src/routes/nationalitiesRoute')
const districtsRoutes = require('./src/routes/districtsRoute')
const applicationRoutes = require('./src/routes/applicationInformationRoute')
const verifyPaymentRoutes = require('./src/routes/verifyPaymentRoute')
const totalApplicationsRoutes = require('./src/routes/totalApplicationRoute')
const { default: helmet } = require("helmet");
// const PORT = 4002;
const app = express();
const PORT = process.env.PORT || 4004;

app.use(express.json());
app.use(cors());
app.use(helmet());
// app.use(fileUpload());
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("DB successfully connected new!");
  })
  .catch((err) => {
    console.error("Connection error", err);
  });

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get("/test", function () {
  console.log("test");
});

app.get("/", (req, res) => {
  res.send("Hello World! ttt");
});

// Token Verification
app.use((req, res, next) => {
  if (
    req.headers &&
    req.headers.authorization &&
    req.headers.authorization.split(" ")[0] === "JWT"
  ) {
    jwt.verify(
      req.headers.authorization.split(" ")[1],
      "RESTfulAPIs",
      (err, decode) => {
        if (err) req.user = undefined;
        req.user = decode;
        next();
      }
    );
  } else {
    req.user = undefined;
    next();
  }
});


app.use("/api/batch", batchRoutes);
app.use("/api/session", sessionRoute);
app.use('/api/bloodgroup', bloodgroupRoute)
app.use('/api/guarRelation', guardianRelationRoute)
app.use('/api/nationality', nationalitiesRotes)
app.use('/api/districts', districtsRoutes)
app.use('/api/application', applicationRoutes)
app.use('/api/verifypayment', verifyPaymentRoutes)
app.use('/api/totalApplication', totalApplicationsRoutes)

app.get("/ping", (req, res) => {
  return res.send({
    error: false,
    message: "Server is healthy",
  });
});
app.listen(PORT, () => {
  console.log(`serve running ${PORT}`);
});
